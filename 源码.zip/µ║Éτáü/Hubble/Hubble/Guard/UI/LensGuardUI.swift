//
//  LensGuardUI.swift
//  Alamofire
//
//  Created by hazhu1 on 2023/4/22.
//

import Foundation

extension UILabel {
    func guardTruncation() -> UILabel {
        return self
    }
}
