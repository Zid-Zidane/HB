//
//  HubbleTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/1.
//

import XCTest
@testable import Hubble

final class HubbleTests: XCTestCase {

    override func setUpWithError() throws {
        HubbleManager.shared.show()
    }
    
    override func tearDownWithError() throws {
        HubbleManager.shared.close()
    }
    
    func testgetFormattedMapString() throws {
        let result = Tools.getFormattedMapString(["key": "vale"])
        XCTAssert(result.contains("key"))
        XCTAssert(result.contains("vale"))
    }
    
    func testgetBasicAppInfo() throws {
        let result = Tools.getBasicAppInfo()
        XCTAssert(result.keys.contains("Version"))
        XCTAssert(result.keys.contains("Name"))
    }
    
    func testgetBasicDeviceInfo() throws {
        let result = Tools.getBasicDeviceInfo()
        XCTAssert(result.keys.contains("LateralResolution"))
        XCTAssert(result.keys.contains("VerticalResolution"))
        XCTAssert(result.keys.contains("DeviceName"))
        XCTAssert(result.keys.contains("SystemName"))
        XCTAssert(result.keys.contains("SystemVersion"))
        XCTAssert(result.keys.contains("DeviceModel"))
        XCTAssert(result.keys.contains("isSimulator"))
    }
    
    func testgetBasicDeviceInfoString() throws {
        let result = Tools.getBasicDeviceInfoString()
        XCTAssert(result.contains("Resolution"))
        XCTAssert(result.contains("DeviceName"))
        XCTAssert(result.contains("SystemName"))
        XCTAssert(result.contains("SystemVersion"))
        XCTAssert(result.contains("DeviceModel"))
    }
    
    func testgetBasicAppInfoString() throws {
        let result = Tools.getBasicAppInfoString()
        XCTAssert(result.contains("Version"))
        XCTAssert(result.contains("Name"))
    }
    
    func testthumbnailedImage() throws {
        let image = UIImage(systemName: "square.and.arrow.up")
        let imageData = image?.jpegData(compressionQuality: 0.2)
        let result = Tools.thumbnailedImage(maxPixelDimension: 17, fromImageData: imageData as NSData?)
        XCTAssert(result != nil)
    }
    
    func testconvertCookiesToString() throws {
        var cookieProperty =  [HTTPCookiePropertyKey : Any]()
        cookieProperty[HTTPCookiePropertyKey.name] = "key"
        cookieProperty[HTTPCookiePropertyKey.value] = "value"
        cookieProperty[HTTPCookiePropertyKey.domain] = "domain"
        cookieProperty[HTTPCookiePropertyKey.originURL] = "originURL"
        cookieProperty[HTTPCookiePropertyKey.path] = "path"
        let cookie = HTTPCookie(properties: cookieProperty)
        if let cookie = cookie {
            let result = Tools.convertCookiesToString([cookie])
            XCTAssert(result.contains("key"))
            XCTAssert(result.contains("value"))
        } else {
            XCTFail()
        }
    }
    
    func testconvertMapToFormatString() throws {
        let result = Tools.convertMapToFormatString(["key": "value"])
        if let result = result {
            XCTAssert(result.contains("key"))
            XCTAssert(result.contains("value"))
        } else {
            XCTFail()
        }
    }
    
    func testdecodeBase64() throws {
        let data = "key".data(using: .utf8)
        if let data = data,
           let result = Tools.decodeBase64(data) {
            XCTAssert(result.contains("key"))
            XCTAssert(result.contains("value"))
        }
    }
    
    func testisValidJSONData() throws {
        let data = try JSONSerialization.data(withJSONObject: ["key": "value"])
        XCTAssert(Tools.isValidJSONData(data))
    }
    
    func testgetPrettyJSONString() throws {
        let data = try JSONSerialization.data(withJSONObject: ["key": "value"])
        let result = Tools.getPrettyJSONString(data)
        if let result = result {
            XCTAssert(result.contains("key"))
            XCTAssert(result.contains("value"))
        } else {
            XCTFail()
        }
    }
    
    func testgetPlistString() throws {
        // Map
        guard let url = Bundle(for: Self.self).url(forResource: "map", withExtension: "plist") else { return }
        guard let data = try? Data(contentsOf: url) else { return }
        var result = Tools.getPlistString(data)
        if let result = result {
            XCTAssert(result.contains("NSAppTransportSecurity"))
        } else {
            XCTFail()
        }
        
        // List
        guard let url = Bundle(for: Self.self).url(forResource: "list", withExtension: "plist") else { return }
        guard let data = try? Data(contentsOf: url) else { return }
        result = Tools.getPlistString(data)
        if let result = result {
            XCTAssert(result.contains("NSAppTransportSecurity"))
        } else {
            XCTFail()
        }
    }
    func testinterceptionDecimal() throws {
        let result = Tools.interceptionDecimal(float: 0.1234, base: 2)
        XCTAssert(result == "0.12")
    }
    
    func testgetCellHeight() throws {
        let target = "test"
        let sizeLimit = CGSize(width: CGFloat.infinity, height: .greatestFiniteMagnitude)
        let boundingRect = target.boundingRect(with: sizeLimit, options: .usesLineFragmentOrigin, context: nil)
        
        let result = Tools.getCellHeight(target, width: CGFloat.infinity)
        XCTAssert(result == ceil(boundingRect.height))
    }
    
    func testscreenWidth() throws {
        let targetWindow = UIApplication.shared.windows.first {
            return $0 is EnvModePeep
        }
        let targetWindowWidth = targetWindow?.bounds.size.width
        
        let result = Tools.screenWidth()
        XCTAssert(result == targetWindowWidth)
    }
    
    func testscreenHeight() throws {
        let targetWindow = UIApplication.shared.windows.first {
            return $0 is EnvModePeep
        }
        let targetWindowHeight = targetWindow?.bounds.size.height
        
        let result = Tools.screenHeight()
        XCTAssert(result == targetWindowHeight)
    }
    
    func testcurrentWindow() throws {
        let result = Tools.currentWindow()
        guard let result = result else { return }
        XCTAssert(result is EnvModePeep)
    }
    
    func teststringByEscapingHTMLEntitiesInString() throws {
        guard let url = Bundle(for: Self.self).url(forResource: "html", withExtension: "html") else { return }
        let data = try Data(contentsOf: url)
        guard let htmlString = String(data: data, encoding: .utf8) else { return }
        let result = Tools.stringByEscapingHTMLEntitiesInString(htmlString)
        XCTAssert(result.contains("body"))
    }
    
    func testhtmlEncodedString() throws {
        guard let url = Bundle(for: Self.self).url(forResource: "html", withExtension: "html") else { return }
        let data = try Data(contentsOf: url)
        guard let htmlString = String(data: data, encoding: .utf8) else { return }
        let result = Tools.htmlEncodedString(htmlString)
        if let result = result {
            XCTAssert(result.contains("body"))
        } else {
            XCTFail()
        }
    }
    
    func testsplitString() throws {
        let target = "key:value"
        let component = ":"
        let result = Tools.splitString(target, component: component)
        XCTAssert(result.contains("key"))
        XCTAssert(result.contains("value"))
        XCTAssert(!result.contains(":"))
    }
    func testgetAPPInfo() throws {
        let result = Tools.getAPPInfo()
        XCTAssert(result.isEmpty.hashValue == Bundle.main.infoDictionary?.isEmpty.hashValue)
    }
    
    func testgetAPPVersion() throws {
        let target = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
        let result = Tools.getAPPVersion()
        XCTAssert(result == target ?? "")
    }
    
    func testgetAPPName() throws {
        let target = Bundle.main.infoDictionary?["CFBundleDisplayName"] as? String
        let result = Tools.getAPPName()
        XCTAssert(result == target ?? "")
    }
    
    func testgetDeviceName() throws {
        let target = UIDevice.current.name
        let result = Tools.getDeviceName()
        XCTAssert(result == target)
    }
    
    func testgetDeviceSystemName() throws {
        let target = UIDevice.current.systemName
        let result = Tools.getDeviceSystemName()
        XCTAssert(result == target)
    }
    
    func testgetDeviceSystemVersion() throws {
        let target = UIDevice.current.systemVersion
        let result = Tools.getDeviceSystemVersion()
        XCTAssert(result == target)
    }
    
    func testgetDeviceModel() throws {
        let target = UIDevice.current.model
        let result = Tools.getDeviceModel()
        XCTAssert(result == target)
    }
    
    func testgetLateralResolution() throws {
        let target = String(Int(UIScreen.main.bounds.size.width * UIScreen.main.scale))
        let result = Tools.getLateralResolution()
        XCTAssert(result == target)
    }
    func testgetVerticalResolution() throws {
        let target = String(Int(UIScreen.main.bounds.size.height * UIScreen.main.scale))
        let result = Tools.getVerticalResolution()
        XCTAssert(result == target)
    }
    
    func testisSimulator() throws {
        var target = false
#if targetEnvironment(simulator)
        target = true
#else
        target = false
#endif
        
        let result = Tools.isSimulator()
        XCTAssert(result == target)
    }
    
    func testgetJailBroken() throws {
        let target = Tools.jailbreakFileExists() || Tools.sandboxBreached() || Tools.evidenceOfSymbolLinking()
        let result = Tools.getJailBroken()
        XCTAssert(result == target)
    }
    
    func testevidenceOfSymbolLinking() throws {
        var s = stat()
        guard lstat("/Applications", &s) == 0 else { return }
        let target = (s.st_mode & S_IFLNK == S_IFLNK)
        let result = Tools.evidenceOfSymbolLinking()
        XCTAssert(result == target)
    }
    
    func testsandboxBreached() throws {
        var target = false
        if (try? " ".write(
            toFile: "/private/jailbreak.txt",
            atomically: true, encoding: .utf8)) != nil {
            target = true
        }
        let result = Tools.sandboxBreached()
        XCTAssert(result == target)
    }
    
    func testjailbreakFileExists() throws {
        let jailbreakFilePaths = [
            "/Applications/Cydia.app",
            "/Library/MobileSubstrate/MobileSubstrate.dylib",
            "/bin/bash",
            "/usr/sbin/sshd",
            "/etc/apt",
            "/private/var/lib/apt/"
        ]
        let fileManager = FileManager.default
        let target = jailbreakFilePaths.contains { path in
            if fileManager.fileExists(atPath: path) {
                return true
            }
            if let file = fopen(path, "r") {
                fclose(file)
                return true
            }
            return false
        }
        
        
        let result = Tools.jailbreakFileExists()
        XCTAssert(result == target)
    }
    
    
    
    
    func testisNotEmptyforce() throws {
        let result = ["key"].isNotEmpty
        XCTAssert(result == true)
    }
    
    func testisNotEmptyoptional() throws {
        let result = ["key"].isNotEmpty
        XCTAssert(result == true)
    }
    
    func testorforce() throws {
        let target: String? = nil
        let result = target.or("key")
        XCTAssert(result == "key")
    }
    
    func testoroptional() throws {
        let target: String? = nil
        let result = target.or(target)
        XCTAssert(result == nil)
    }
    
    func testorZero() throws {
        let target: Int? = nil
        let result = target.orZero
        XCTAssert(result == 0)
    }
    
    func testorFalse() throws {
        let target: Bool? = false
        let result = target.orFalse
        XCTAssert(result == false)
    }
    
    func testorTrue() throws {
        let target: Bool? = nil
        let result = target.orTrue
        XCTAssert(result == true)
    }
    
    func testorEmpty() throws {
        let target: String? = nil
        let result = target.orEmpty
        XCTAssert(result == "")
    }

    func testparentViewController() {
        let vc = UIViewController()
        XCTAssert(vc.view.parentViewController == vc)
    }
    func testwidth() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.width == 1)
        
        view.width = 2
        XCTAssert(view.width == 2)
    }
    func testheight() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.height == 1)
        
        view.height = 2
        XCTAssert(view.height == 2)
    }
    func testsize() {
        let origin: CGPoint = .init(x: 1, y: 1)
        let size: CGSize = .init(width: 1, height: 1)
        let view = UIView(frame: .init(origin: origin, size: size))
        XCTAssert(view.size == size)
        
        let target = CGSize(width: 2, height: 2)
        view.size = target
        XCTAssert(view.size == target)
    }
    func testorigin() {
        let origin: CGPoint = .init(x: 1, y: 1)
        let size: CGSize = .init(width: 1, height: 1)
        let view = UIView(frame: .init(origin: origin, size: size))
        XCTAssert(view.origin == origin)
        
        let target = CGPoint(x: 2, y: 2)
        view.origin = target
        XCTAssert(view.origin == target)
    }
    func testx() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.x == 1)
        
        view.x = 2
        XCTAssert(view.x == 2)
    }
    func testy() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.y == 1)
        
        view.y = 2
        XCTAssert(view.y == 2)
    }
    func testcenterX() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.centerX == 1.5)
        
        view.centerX = 2
        XCTAssert(view.centerX == 2)
    }
    func testcenterY() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.centerY == 1.5)
        
        view.centerY = 2
        XCTAssert(view.centerY == 2)
    }
    func testleft() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.left == 1)
        
        view.left = 2
        XCTAssert(view.left == 2)
    }
    func testright() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.right == 2)
        
        view.right = 3
        XCTAssert(view.right == 3)
    }
    func testtop() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.top == 1)
        
        view.top = 2
        XCTAssert(view.top == 2)
    }
    func testbottom() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        XCTAssert(view.bottom == 2)
        
        view.bottom = 3
        XCTAssert(view.bottom == 3)
    }
    func testcornerRadius() {
        let view = UIView(frame: .init(x: 1, y: 1, width: 1, height: 1))
        view.cornerRadius = 2
        XCTAssert(view.cornerRadius == 2)
        
        view.cornerRadius = 2
        XCTAssert(view.cornerRadius == 2)
    }
    func testclassName() {
        XCTAssert(UIView.className == "UIView")
    }
    func testib_borderColor() {
        let view = UIView()
        let targetColor = UIColor.red
        view.ib_borderColor = targetColor
        if let color = view.layer.borderColor {
            XCTAssert(color == targetColor.cgColor)
        } else {
            XCTFail()
        }

        if let color = view.ib_borderColor {
            XCTAssert(color.cgColor == targetColor.cgColor)
        } else {
            XCTFail()
        }
    }
    func testib_borderWidth() {
        let view = UIView()
        let targetWidth: CGFloat = 1.0
        view.ib_borderWidth = targetWidth
        XCTAssert(view.layer.borderWidth == targetWidth)
        
        XCTAssert(view.ib_borderWidth == targetWidth)
    }
    func testib_cornerRadius() {
        let view = UIView()
        let targetRadius: CGFloat = 1.0
        view.ib_cornerRadius = targetRadius
        XCTAssert(view.layer.cornerRadius == targetRadius)
        
        XCTAssert(view.ib_cornerRadius == targetRadius)
    }
    func testcou_screenWidth() {
        let result = UIScreen.cou_screenWidth
        XCTAssert(result == UIScreen.main.bounds.size.width)
    }
    func testcou_screenHeight() {
        let result = UIScreen.cou_screenHeight
        XCTAssert(result == UIScreen.main.bounds.size.height)
    }
    func testmainWidth() {
        let result = UIScreen.mainWidth
        XCTAssert(result == UIScreen.main.bounds.size.width)
    }
    func testmainHeight() {
        let result = UIScreen.mainHeight
        XCTAssert(result == UIScreen.main.bounds.size.height)
    }
    
    // Enums
    func testLensPageStructInit() {
        let type = "key"
        let result = LensPageStruct(type)
        XCTAssert(result.type == type)
    }
    func testLensDetailPageContentTypeHeight() {
        let target = 10.0
        var result = LensDetailPageContentType.text("", target)
        XCTAssert(result.height() == target)
        
        result = LensDetailPageContentType.none
        XCTAssert(result.height() == 0.0)
        
        let image = UIImage()
        result = LensDetailPageContentType.image(image)
        XCTAssert(result.height() == 0.0)
    }
    func testLensDetailPageContentTypeneedsDisplayWK() {
        let target = 10.0
        var result = LensDetailPageContentType.text("", target)
        XCTAssert(result.needsDisplayWK() == false)
        
        result = LensDetailPageContentType.text("", 1000)
        XCTAssert(result.needsDisplayWK() == true)
    }
    func testLensResourcesimage() {
        let targetName = "scope"
        let result = LensResources.image(targetName)
        let target = UIImage(systemName: targetName)
        if #available(iOS 13, *) {
            XCTAssert(result == target)
        }
    }
    
    // OCTools
    func testgetNetworkObserverEnabled() throws {
        // give
        OCTools.setNetworkObserverEnabled(true)
        // when
        // then
        XCTAssert(OCTools.getNetworkObserverEnabled() == true)
    }
    func testsetNetworkObserverEnabled() throws {
        OCTools.setNetworkObserverEnabled(true)
        XCTAssert(OCTools.getNetworkObserverEnabled() == true)
    }
    func testthumbnailedImageWithMaxPixelDimension() throws {
        let target: Int = 10
        if let image = UIImage(systemName: "scope"),
           let data = image.jpegData(compressionQuality: 0.2) {
            let result = OCTools.thumbnailedImage(withMaxPixelDimension: target, fromImageData: data)
            XCTAssert(result.size.width <= CGFloat(target))
            XCTAssert(result.size.height <= CGFloat(target))
        } else {
            // Try to change image
        }
    }
    func testappKeyWindow() throws {
        HubbleManager.shared.show()
        OCTools.appKeyWindow()
        XCTAssert(EnvModePeep.shared.isHidden == false)
    }
    func testallWindows() throws {
        let result = OCTools.allWindows()
        XCTAssert(result.count > 0)
    }
    func testdescriptionForView() throws {
        let target = "text"
        let label = UILabel(frame: .zero)
        label.text = target
        label.accessibilityLabel = target
        let result = OCTools.description(for: label, includingFrame: true, accessory: true)
        XCTAssert(result.contains(target))
    }
    func testviewControllerForView() throws {
        // give
        let viewcontroller = UIViewController()
        // when
        // then
        let result = OCTools.viewController(for: viewcontroller.view)
        XCTAssert(result == viewcontroller)
    }
    func testrandomColorForObject() throws {
        XCTAssert(OCTools.randomColor(for: "").getHue(nil, saturation: nil, brightness: nil, alpha: nil) == true)
    }
    func testLensGetAllSubclasses() throws {
        let result = LensGetAllSubclasses(LensBasePageModel.self, false)
//        XCTAssert(result.contains(LensPageAlertModel.self))
    }
    
    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }

}
