//
//  HubbleManagerTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/1.
//

import XCTest
@testable import Hubble

final class HubbleManagerTests: XCTestCase {

    override func setUpWithError() throws {
        HubbleManager.shared.show()
    }
    
    override func tearDownWithError() throws {
        HubbleManager.shared.close()
    }

    func testshared() {
        let target = HubbleManager.shared
        let result = HubbleManager.shared
        XCTAssert(result === target)
    }
    func testdebugHandler() {
        let target: BlankHandler? = {}
        HubbleManager.shared.debugHandler = target
        let result = HubbleManager.shared.debugHandler
        XCTAssert(result != nil)
    }
    func testlensData() {
        let target = ["version": "1"]
        HubbleManager.shared.lensData = target
        let result = HubbleManager.shared.lensData
        if let version = result?.keys.first {
            XCTAssert(version.contains("version"))
        } else {
            XCTFail()
        }
        
        if let value = result?.values.first {
            XCTAssert(value.contains("1"))
        } else {
            XCTFail()
        }
        
    }
    func testfactoryMap() {
        let target = LensBaseModelFactory()
        let title = "key"
        target.title = title
        HubbleManager.shared.regist([target])
        let result = HubbleManager.shared.factoryMap
        XCTAssert(result[title] == target)
    }
    func testregist() {
        let target = LensBaseModelFactory()
        let title = "key"
        target.title = title
        HubbleManager.shared.regist([target])
        let result = HubbleManager.shared.factoryMap
        XCTAssert(result[title] == target)
    }
    func testlogFactory() {
        let target = LensBaseModelFactory()
        let title = "key"
        target.title = title
        HubbleManager.shared.regist([target])
        let result = HubbleManager.logFactory(title)
        XCTAssert(result == target)
    }
    func testshow() {
        let target = ["version": "1"]
        HubbleManager.shared.show(target)
        let result = HubbleManager.shared.lensData
        if let result = result {
            XCTAssert(result == target)
        } else {
            XCTFail()
        }
    }
    func testfold() {
        HubbleManager.shared.show()
        HubbleManager.shared.fold()
        XCTAssert(EnvModePeep.peepView.isHidden == false)
    }
    func testsetAvalible() {
        let target = true
        HubbleManager.shared.setAvalible(target)
        let result = HubbleManager.shared.avalible()
        XCTAssert(result == target)
    }
    func testsetLensData() {
        let target = ["version": "1"]
        HubbleManager.shared.setLensData(target)
        let result = HubbleManager.shared.lensData
        if let result = result {
            XCTAssert(result == target)
        } else {
            XCTFail()
        }
    }
    

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
