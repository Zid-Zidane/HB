//
//  HubbleInspectViewTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/2.
//

import XCTest
@testable import Hubble

final class HubbleInspectViewTests: XCTestCase {

    var viewInspectorVC: LensViewInspectorViewController = LensViewInspectorViewController()
    
    override func setUpWithError() throws {
        viewInspectorVC = LensViewInspectorViewController()
    }

    override func tearDownWithError() throws {
        
    }
    
    func testupdateStat() throws {
        let targe: LensInspectorMode = .default
        viewInspectorVC.updateState(targe)
        if let value = viewInspectorVC.value(forKey: "currentMode") as? UInt,
        let result = LensInspectorMode(rawValue: value) {
            XCTAssertEqual(targe, result)
        } else {
            XCTFail()
        }
    }
    func testshouldReceiveTouchAtWindowPoin() throws {
        var point = CGPoint(x: 50, y: 150)
        var result = viewInspectorVC.shouldReceiveTouch(atWindowPoint: point)
        XCTAssertEqual(result, false)
        
        viewInspectorVC.updateState(.select)
        point = CGPoint(x: 3000, y: 0)
        result = viewInspectorVC.shouldReceiveTouch(atWindowPoint: point)
        XCTAssertEqual(result, true)
    }
    func testwantsWindowToBecomeKe() throws {
        XCTAssertEqual(false, viewInspectorVC.wantsWindowToBecomeKey())
    }


    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
