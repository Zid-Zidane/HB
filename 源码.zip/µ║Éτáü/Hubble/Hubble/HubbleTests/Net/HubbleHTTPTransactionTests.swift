//
//  HubbleHTTPTransactionTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/2.
//

import XCTest
@testable import Hubble

final class HubbleHTTPTransactionTests: XCTestCase {

    var transaction: LensHTTPTransaction = LensHTTPTransaction(requestID: "", request: nil, task: URLSessionTask(), response: nil)
    let requestID = "requestID"
    let urlString = "https://www.baidu.com"
    let mimeType = "txt"
    let expectedContentLength = 100
    let textEncodingName = "textEncodingName"
    
    let textUrl = "https://filesamples.com/samples/document/txt/sample3.txt"
    let emptyUrl = "https://example.com/example"
    
    override func setUpWithError() throws {
        if let url = URL(string: urlString) {
            transaction = LensHTTPTransaction(requestID: requestID, request: URLRequest(url: url), task: URLSessionTask(), response: HTTPURLResponse(url: url , mimeType: mimeType, expectedContentLength: expectedContentLength, textEncodingName: textEncodingName))
        }
        
        let expectation_ = expectation(description: "HubbleMITMRecordTests_")
        DispatchQueue.global().asyncAfter(deadline: .now() + 1) {
            expectation_.fulfill()
        }
        waitForExpectations(timeout: 2)
        LensNetworkObserver.load()
    }

    override func tearDownWithError() throws {
        purge()
    }

    func teststate() throws {
        let targt: LensNetworkTransactionState = .lensNetworkTransactionStateFailed
        transaction.state = targt
        let result = transaction.state
        XCTAssert(result == targt)
    }
    
    func testinit() throws {
        XCTAssert(transaction.requestID == requestID)
    }
    
    func testmainMessage() throws {
        requestText()
        
        let expectation = expectation(description: "HubbleMITMRecordTests")
        DispatchQueue.global().asyncAfter(deadline: .now() + 1) {
            expectation.fulfill()
        }
        waitForExpectations(timeout: 2)
        
        if let transaction = LensNetworkRecorder.defaultRecord.orderedHttpTransactions.first {
            let result = transaction.mainMessage()
            XCTAssert(result.contains("GET"))
            XCTAssert(result.contains(textUrl))
        } else {
            XCTFail()
        }
    }
    
    func testsubMessage() throws {
        requestText()
        
        let expectation = expectation(description: "HubbleMITMRecordTests")
        DispatchQueue.global().asyncAfter(deadline: .now() + 1) {
            expectation.fulfill()
        }
        waitForExpectations(timeout: 2)
        if let transaction = LensNetworkRecorder.defaultRecord.orderedHttpTransactions.first {
            let result = transaction.subMessage()
            XCTAssert(result.contains(transaction.requestID))
        } else {
            XCTFail()
        }
        
        purge()
        
        request(emptyUrl)
        let expectation2 = self.expectation(description: "HubbleMITMRecordTests2")
        DispatchQueue.global().asyncAfter(deadline: .now() + 1) {
            expectation2.fulfill()
        }
        waitForExpectations(timeout: 2)
        if let transaction = LensNetworkRecorder.defaultRecord.orderedHttpTransactions.first {
            let result = transaction.subMessage()
            XCTAssert(result.contains(transaction.requestID))
        } else {
            XCTFail()
        }

        XCTAssert(transaction.contentMessage() == "")
    }
    
    func testdetailProtocol() throws {
        let result = transaction.detailProtocol()
        XCTAssert(result.count == 4)
    }
    
    func testoverViewHTTP() throws {
        let target = "overview"
        let result = transaction.overViewHTTP()
        XCTAssert(result.title == target)
    }
    
    func testrequestHTTP() throws {
        let target = "request"
        let result = transaction.requestHTTP()
        XCTAssert(result.title == target)
    }
    
    func testresponseHTTP() throws {
        requestText()
        
        let expectation = expectation(description: "HubbleMITMRecordTests")
        DispatchQueue.global().asyncAfter(deadline: .now() + 2) {
            expectation.fulfill()
        }
        waitForExpectations(timeout: 3)
        let target = "response"
        if let result = transaction.responseHTTP() {
            XCTAssert(result.title == target)
        } else {
            // check network or request url
        }
    }
    
    func testwaterfallHTTP() throws {
        let result = transaction.waterfallHTTP()
        XCTAssertNil(result)
    }
    
    func testgetBody() throws {
        
    }
    
    func testgetDetailContentText() throws {
        let target = "target"
        let result = transaction.getDetailContentText(target)
        if case let .text( content,  _) = result {
            XCTAssert(target == content)
        } else {
            XCTFail()
        }
    }
    
    func testoverViewHTTPInformatins() throws {
        let result = transaction.overViewHTTPInformatins()
        XCTAssert(result.keys.contains("Url"))
        XCTAssert(result.keys.contains("Host"))
        XCTAssert(result.keys.contains("Method"))
        XCTAssert(result.keys.contains("Response Code"))
        XCTAssert(result.keys.contains("Bytes Received"))
        XCTAssert(result.keys.contains("Duration"))
    }
    
    func testrequestHTTPInformatins() throws {
        let result = transaction.requestHTTPInformatins()
        XCTAssert(result.keys.contains("Url"))
        XCTAssert(result.keys.contains("Path"))
        XCTAssert(result.keys.contains("Query"))
        XCTAssert(result.keys.contains("Cookie"))
        XCTAssert(result.keys.contains("Body"))
        XCTAssert(result.keys.contains("Header"))
    }
    
    func testresponseHTTPInformatins() throws {
        let result = transaction.responseHTTPInformatins()
        XCTAssert(result.keys.contains("Staus Code"))
        XCTAssert(result.keys.contains("Cookie"))
        XCTAssert(result.keys.contains("Header"))
        XCTAssert(result.keys.contains("MimeType"))
        XCTAssert(result.keys.contains("Body"))
    }
    
    func request(_ url: String) {
        access(url)
    }
    
    func requestText() {
        access(textUrl)
    }

    func requestImage() {
        let image = "https://ts1.cn.mm.bing.net/th?id=OIP-C.2bJ9_f9aKoGCME7ZIff-ZwHaJ4&w=154&h=206&c=8&rs=1&qlt=90&o=6&dpr=2&pid=3.1&rm=2"
        access(image)
    }
    
    func access(_ url: String) {
        if let url = URL(string: url) {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            URLSession(configuration: configuration).dataTask(with: URLRequest(url: url)) { _, _, _ in
                
            }.resume()
        }
    }
    
    func download() {
        let imageUrl = "https://ts1.cn.mm.bing.net/th?id=OIP-C.2bJ9_f9aKoGCME7ZIff-ZwHaJ4&w=154&h=206&c=8&rs=1&qlt=90&o=6&dpr=2&pid=3.1&rm=2"
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        if let url = URL(string: imageUrl) {
            URLSession(configuration: configuration).dataTask(with: URLRequest(url: url)) { url, response, error in
                
            }.resume()
        }
    }
    
    func errorRequest() {
        let imageUrl = "https://ts1.cn.mm.bing.net/th?id=123"
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        if let url = URL(string: imageUrl) {
            URLSession(configuration: configuration).dataTask(with: URLRequest(url: url)) { url, response, error in
                
            }.resume()
        }
    }
    
    
    func purge() {
        LensNetworkRecorder.defaultRecord.enableHostBlackList = false
        LensNetworkRecorder.defaultRecord.enableHostWhiteList = false
        LensNetworkRecorder.defaultRecord.hostBlackList = []
        LensNetworkRecorder.defaultRecord.hostWhiteList = []
        LensNetworkRecorder.defaultRecord.orderedHttpTransactions = []
        LensNetworkRecorder.defaultRecord.requestIDsToTransactions = [:]
        LensNetworkRecorder.defaultRecord.restCache.removeAllObjects()

    }
    
    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
