//
//  HubbleMITMRecordTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/1.
//

import XCTest
@testable import Hubble

final class HubbleMITMRecordTests: XCTestCase {
    
    let host = "www.xxx.com"
    lazy var targetUrl: String = {
        "https://"+self.host
    }()
    
    override func setUpWithError() throws {
        let expectation_ = expectation(description: "HubbleMITMRecordTests_")
        DispatchQueue.global().asyncAfter(deadline: .now() + 1) {
            expectation_.fulfill()
        }
        waitForExpectations(timeout: 2)
        LensNetworkObserver.load()
    }

    override func tearDownWithError() throws {
        LensNetworkRecorder.defaultRecord.enableHostBlackList = false
        LensNetworkRecorder.defaultRecord.enableHostWhiteList = false
        LensNetworkRecorder.defaultRecord.hostBlackList = []
        LensNetworkRecorder.defaultRecord.hostWhiteList = []
        LensNetworkRecorder.defaultRecord.orderedHttpTransactions = []
        LensNetworkRecorder.defaultRecord.requestIDsToTransactions = [:]
        LensNetworkRecorder.defaultRecord.restCache.removeAllObjects()
    }

    func testdefaultRecord() {
        let target = LensNetworkRecorder.defaultRecord
        let result = LensNetworkRecorder.defaultRecord
        XCTAssert(target === result)
    }
    func testenableHostBlackList() {
        let target = true
        LensNetworkRecorder.defaultRecord.enableHostBlackList = target
        let result = LensNetworkRecorder.defaultRecord.enableHostBlackList
        XCTAssert(target == result)
    }
    func testenableHostWhiteList() {
        let target = true
        LensNetworkRecorder.defaultRecord.enableHostWhiteList = target
        let result = LensNetworkRecorder.defaultRecord.enableHostWhiteList
        XCTAssert(target == result)
    }
    func testhostBlackList() {
        let target = [
            host
        ]
        LensNetworkRecorder.defaultRecord.enableHostBlackList = true
        LensNetworkRecorder.defaultRecord.hostBlackList = target
        let result = LensNetworkRecorder.defaultRecord.hostBlackList
        XCTAssert(target == result)
        if let url = URL(string: targetUrl) {
            LensNetworkRecorder.defaultRecord.recordRequestWillBeSent(requestID: "", request: URLRequest(url: url), task: URLSessionTask(), redirectResponse: nil)
            XCTAssert(LensNetworkRecorder.defaultRecord.orderedHttpTransactions.count == 0)
        } else {
            // This is not error, upi should replace targetUrl
        }
    }
    func testwhiteList() {
        let expectation1 = expectation(description: "HubbleMITMRecordTests")
        let expectation2 = expectation(description: "HubbleMITMRecordTests")
        
        let target = [
            host
        ]
        LensNetworkRecorder.defaultRecord.enableHostBlackList = false
        LensNetworkRecorder.defaultRecord.enableHostWhiteList = true
        LensNetworkRecorder.defaultRecord.hostWhiteList = target
        let result = LensNetworkRecorder.defaultRecord.hostWhiteList
        XCTAssert(target == result)
        if let url = URL(string: self.targetUrl) {
            LensNetworkRecorder.defaultRecord.recordRequestWillBeSent(requestID: "", request: URLRequest(url: url), task: URLSessionTask(), redirectResponse: nil)
            DispatchQueue.global().asyncAfter(deadline: .now() + 2) {
                expectation1.fulfill()
            }
            
            wait(for: [expectation1], timeout: 3)
            XCTAssert(LensNetworkRecorder.defaultRecord.orderedHttpTransactions.count == 1)
            
            
            LensNetworkRecorder.defaultRecord.recordRequestWillBeSent(requestID: "", request: URLRequest(url: url), task: URLSessionTask(), redirectResponse: URLResponse())
            DispatchQueue.global().asyncAfter(deadline: .now() + 2) {
                expectation2.fulfill()
            }

            wait(for: [expectation2], timeout: 3)
            let target = LensNetworkRecorder.defaultRecord.requestIDsToTransactions
            XCTAssert(target.count > 0)
        } else {
            // This is not error, upi should replace targetUrl
        }
    }
    func testrestCache() {
        let expectation = expectation(description: "HubbleMITMRecordTests")
        let key = "123"
        let value = "123"
        if let data = value.data(using: .utf8) as NSData?,
           let url = URL(string: self.targetUrl) {
            LensNetworkRecorder.defaultRecord.recordRequestWillBeSent(requestID: key, request: URLRequest(url: url), task: URLSessionTask(), redirectResponse: nil)
            LensNetworkRecorder.defaultRecord.recordLoadingFinished(requestID: key, responseBody: data)
            let result = LensNetworkRecorder.defaultRecord.restCache
            DispatchQueue.global().asyncAfter(deadline: .now() + 2) {
                expectation.fulfill()
            }
            wait(for: [expectation], timeout: 3)
            XCTAssertNotNil(result.object(forKey: key as NSString))
        } else {
            // This is not error, just try replace value
        }
    }
    func testgetResponseBody() {
        LensNetworkRecorder.defaultRecord.orderedHttpTransactions = []
        let expectation2 = expectation(description: "HubbleMITMRecordTests2")

        requestImage()
        
        DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
            expectation2.fulfill()
        }
        wait(for: [expectation2], timeout: 10)
        let transaction = LensNetworkRecorder.defaultRecord.orderedHttpTransactions.first
        if let transaction = transaction {
            let result = LensNetworkRecorder.defaultRecord.getResponseBody(transaction: transaction)
            // MARK: - ⚠️⚠️Make Sure Net Work Is Reachable, Lose Net Work Also Fail -
            XCTAssertNotNil(result)
        } else {
            XCTFail()
        }
    }
    func testrecordResponse() {
        download()
        
        let expectation1 = expectation(description: "HubbleMITMRecordTests")
        DispatchQueue.global().asyncAfter(deadline: .now() + 3) {
            expectation1.fulfill()
        }
        wait(for: [expectation1], timeout: 10)
        if let transaction = LensNetworkRecorder.defaultRecord.orderedHttpTransactions.first {
            LensNetworkRecorder.defaultRecord.recordResponse(requestID: transaction.requestID, response: URLResponse())
            // MARK: - ⚠️⚠️Make Sure Net Work Is Reachable, Lose Net Work Also Fail -
            XCTAssertNotNil(transaction.response)
        } else {
            // Check network or request url
        }
    }
    func testrecordLoadingFailed() {
        let expectation1 = expectation(description: "HubbleMITMRecordTests")
        let expectation2 = expectation(description: "HubbleMITMRecordTests2")
        
        requestImage()
        DispatchQueue.global().asyncAfter(deadline: .now() + 3) {
            expectation1.fulfill()
        }
        wait(for: [expectation1], timeout: 5)
        if let transaction = LensNetworkRecorder.defaultRecord.orderedHttpTransactions.first {
            LensNetworkRecorder.defaultRecord.recordLoadingFailed(requestID: transaction.requestID, error: NSError(domain: "error", code: -1))
            DispatchQueue.global().asyncAfter(deadline: .now() + 2) {
                expectation2.fulfill()
            }
            waitForExpectations(timeout: 10)
            XCTAssertNotNil(transaction.error)
        } else {
            // This is not error, request faild, try check your net or replace url
        }
    }
    
    func requestImage() {
        let image = "https://ts1.cn.mm.bing.net/th?id=OIP-C.2bJ9_f9aKoGCME7ZIff-ZwHaJ4&w=154&h=206&c=8&rs=1&qlt=90&o=6&dpr=2&pid=3.1&rm=2"
        access(image)
    }
    
    func access(_ url: String) {
        if let url = URL(string: url) {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            URLSession(configuration: configuration).dataTask(with: URLRequest(url: url)) { _, _, _ in
                
            }.resume()
        }
    }
    
    func download() {
        let imageUrl = "https://ts1.cn.mm.bing.net/th?id=OIP-C.2bJ9_f9aKoGCME7ZIff-ZwHaJ4&w=154&h=206&c=8&rs=1&qlt=90&o=6&dpr=2&pid=3.1&rm=2"
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        if let url = URL(string: imageUrl) {
            URLSession(configuration: configuration).dataTask(with: URLRequest(url: url)) { url, response, error in
                
            }.resume()
        }
    }
    
    func errorRequest() {
        let imageUrl = "https://ts1.cn.mm.bing.net/th?id=123"
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        if let url = URL(string: imageUrl) {
            URLSession(configuration: configuration).dataTask(with: URLRequest(url: url)) { url, response, error in
                
            }.resume()
        }
    }
    
    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
