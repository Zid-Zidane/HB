//
//  HubbleLensManagerTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/2.
//

import XCTest
@testable import Hubble

final class HubbleLensManagerTests: XCTestCase {

    override func setUpWithError() throws {
        EnvModePeep.show()
    }

    override func tearDownWithError() throws {
        EnvModePeep.hide()
    }

    func testshared() throws {
        let target = EnvModePeep.shared
        let result = EnvModePeep.shared
        XCTAssert(target === result)
    }
    func testinfoPage() throws {
        let result = EnvModePeep.shared.infoPage
        XCTAssert(result is UINavigationController)
    }
    func testkNavBarHeight() throws {
        let target = 64.0
        let result = EnvModePeep.shared.kNavBarHeight(nil)
        XCTAssert(target == result)
    }
    func testgetPostStatus() throws {
        let target = UserDefaults.standard.bool(forKey: "EnvModePeepStatusKey")
        let result = EnvModePeep.getPostStatus()
        XCTAssert(target == result)
    }
    func testsetCurrentStatus() throws {
        let target = false
        EnvModePeep.setCurrentStatus(target)
        let result = EnvModePeep.getPostStatus()
        XCTAssert(target == result)
    }
    func testdoClose() throws {
        EnvModePeep.shared.doClose()
        let expectation1 = expectation(description: "HubbleMITMRecordTests")
        DispatchQueue.global().asyncAfter(deadline: .now() + 1) {
            expectation1.fulfill()
        }
        wait(for: [expectation1], timeout: 10)
        let result = EnvModePeep.shared.isHidden
        XCTAssert(true == result)
    }
    func testsetMovingDirectionWithBtnX() throws {
        EnvModePeep.shared.centerX = 300
        var origin = CGPoint(x: 1.0, y: 1.0)
        EnvModePeep.shared.setMovingDirectionWithBtnX(btnX: origin.x, btnY: origin.y)
        var target = CGPoint(x: UIScreen.cou_screenWidth - EnvModePeep.Constants.peepLength, y: origin.y)
        XCTAssert(EnvModePeep.shared.frame.origin == target)
        
        EnvModePeep.shared.centerX = 0
        origin = CGPoint(x: 300.0, y: 1.0)
        EnvModePeep.shared.setMovingDirectionWithBtnX(btnX: origin.x, btnY: origin.y)
        target = CGPoint(x:0, y: origin.y)
        XCTAssert(EnvModePeep.shared.frame.origin == target)
    }
    func testshow() throws {
        EnvModePeep.show()
        XCTAssert(EnvModePeep.getPostStatus() == true)
    }
    func testhide() throws {
        EnvModePeep.hide()
        XCTAssert(EnvModePeep.shared.isHidden)
    }
    func testchangeContentView() throws {
        EnvModePeep.shared.changeContentView(true)
        XCTAssert(EnvModePeep.shared.rootViewController is UIViewController)
        
        EnvModePeep.shared.changeContentView(false)
        XCTAssert(EnvModePeep.shared.rootViewController is UINavigationController)
    }
    
    
    
    
    func testEnvModePeepViewshare() throws {
        let target = EnvModePeepView.share
        let result = EnvModePeepView.share
        XCTAssert(target === result)
    }
    func teststackView() throws {
        let result = EnvModePeepView.share.stackView
        XCTAssert(result.axis == .vertical)
    }
    func testbackgroundLayer() throws {
        let result = EnvModePeepView.share.backgroundLayer
        XCTAssert(result.borderWidth == 0.5)
        XCTAssert(result.frame == CGRect(x: 0, y: 0, width: EnvModePeep.Constants.peepLength, height: EnvModePeep.Constants.peepLength))
    }
    func testnormalColor() throws {
        let result = EnvModePeepView.share.normalColor
        XCTAssert(result == UIColor.brown.withAlphaComponent(0.3))
    }
    func testabnormalColor() throws {
        let result = EnvModePeepView.share.abnormalColor
        XCTAssert(result == UIColor.systemRed)
    }
    func testreceiveAlert() throws {
        EnvModePeepView.share.receiveAlert()
        let result = EnvModePeepView.share.backgroundLayer
        XCTAssert(result.backgroundColor == UIColor.systemRed.cgColor)
    }
    func testonLongPress() throws {
        EnvModePeepView.share.onLongPress()
        XCTAssert(EnvModePeep.shared.rootViewController is UINavigationController)
    }
    func testshowLensData() throws {
        let key = "key"
        let value = "value"
        EnvModePeepView.share.showLensData([key: value])
        let result = EnvModePeepView.share.stackView.subviews.first
        if let label = result as? UILabel {
            XCTAssert(label.text == key+": "+value)
        } else {
            XCTFail()
        }
    }
    func testattributeContent() throws {
        let string = "value"
        let textFontAttributes = [
            NSAttributedString.Key.strokeColor: UIColor.blue,
            NSAttributedString.Key.foregroundColor: UIColor.systemRed,
            NSAttributedString.Key.strokeWidth: -3.0,
            NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 30)]
        as [NSAttributedString.Key: Any]
        let target = NSMutableAttributedString(string: string, attributes: textFontAttributes)
        let result = EnvModePeepView.share.attributeContent(string)
        XCTAssert(result == target)
    }
    func testshowInfomationView() throws {
        EnvModePeep.shared.showInfomationView()
        XCTAssert(EnvModePeep.Constants.peepLength == EnvModePeep.Constants.peepLengthLarge)
    }
    func testexpand() throws {
        EnvModePeep.shared.expand()
        XCTAssert(EnvModePeep.Constants.peepLength == EnvModePeep.Constants.peepLengthLarge)
    }
    func testfold() throws {
        EnvModePeep.shared.fold()
        XCTAssert(EnvModePeep.shared.width == 50)
        XCTAssert(EnvModePeep.shared.height == 50)
    }
    func testreplaceInformationView() throws {
        EnvModePeep.shared.replaceInformationView()
        XCTAssert(EnvModePeep.shared.rootViewController is UINavigationController)
    }
    
    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
