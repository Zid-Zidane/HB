//
//  HubbleInforPageVCTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/2.
//

import XCTest
@testable import Hubble

final class HubbleInforPageVCTests: XCTestCase {

    override func setUpWithError() throws {
        // remove business factory
        LensInformationPageViewController.shared.dataModels.removeAll()
        LensInformationPageViewController.shared.makeSections()
    }

    override func tearDownWithError() throws {
        
    }

    func testmakeSections() throws {
        LensInformationPageViewController.shared.dataModels.removeAll()
        let factory = LensBaseModelFactory()
        HubbleManager.shared.regist([factory])
        LensInformationPageViewController.shared.makeSections()
        let result = LensInformationPageViewController.shared.dataModels
        XCTAssertEqual(result.count, 5)
        
        if let pageModel = result.first as? LensPageMetaModel,
        let count = pageModel.allFLHandlers?.count {
            XCTAssert(count >= 3)
        } else {
            XCTFail()
        }
    }
    func testupdateNavigationBar() throws {
        let key = LensPageStruct("")
        let value = LensBasePageModel(type: LensPageStruct(""), title: "", selected: false, toolItems: [.close, .locate, .debug, .fold, .now])
        let factory = LensBaseModelFactory()
        factory.pageModels = [key: value]
        HubbleManager.shared.regist([factory])
        LensInformationPageViewController.shared.makeSections()
        LensInformationPageViewController.shared.makeUI()
    }
    func testcurrentSelectedPageModel() throws {
        let target = LensBasePageModel(type: LensPageStruct(""), title: "", selected: true, toolItems: [.now])
        LensInformationPageViewController.shared.dataModels = [target]
        let result = LensInformationPageViewController.shared.currentSelectedPageModel()
        XCTAssert(result === target)
    }
    func testupdateNowButton() throws {
        let target = LensBasePageModel(type: LensPageStruct(""), title: "", selected: true, toolItems: [.now])
        LensInformationPageViewController.shared.dataModels = [target]
        
        let bar = UIBarButtonItem()
        LensInformationPageViewController.shared.updateNowButton(bar)
        let result = bar.image
        XCTAssert(result === LensResources.nowUnselectedIcon)
    }
    func testonSegmentAction() throws {
        LensInformationPageViewController.shared.segment.selectedSegmentIndex = 0
        let target = LensBasePageModel(type: LensPageStruct(""), title: "", selected: true, toolItems: [.close, .locate, .debug, .fold, .now])
        LensInformationPageViewController.shared.dataModels = [target]
        
        LensInformationPageViewController.shared.viewDidLoad()
        LensInformationPageViewController.shared.onSegmentAction()
        if let result = LensViewInspectorManager.shared().value(forKey: "explorerWindow") as? UIWindow {
            XCTAssert(result.isHidden == true)
        } else {
            XCTFail()
        }
    }
    func testcloseButtonClicked() throws {
        // given
        HubbleManager.shared.show()
        // when
        LensInformationPageViewController.shared.closeButtonClicked()
        // then
        if let window = LensViewInspectorManager.shared().value(forKey: "explorerWindow") as? UIWindow {
            XCTAssert(window.isHidden == true)
        } else {
            XCTFail()
        }
    }
    func testlocateButtonClicked() throws {
        // given
        HubbleManager.shared.show()

        // when
        LensInformationPageViewController.shared.locateButtonClicked()
        // then
        if let window = LensViewInspectorManager.shared().value(forKey: "explorerWindow") as? UIWindow {
            
            XCTAssert(window.isHidden == true)
            
        } else {
            XCTFail()
        }
    }
    func testfoldButtonClicked() throws {
        // given
        HubbleManager.shared.show()
        // when
        LensInformationPageViewController.shared.foldButtonClicked()
        // then
    }
    func testdebugButtonClicked() throws {
        // given
        HubbleManager.shared.show()
        // when
        LensInformationPageViewController.shared.debugButtonClicked()
        // then
//        XCTAssert(Tools.currentWindow() == true)
    }
    func testnowButtonClicked() throws {
        // given
        HubbleManager.shared.show()
        // when
        let barItem = UIBarButtonItem(image: LensResources.nowUnselectedIcon, style: .done, target: self, action: nil)
        LensInformationPageViewController.shared.nowButtonClicked(barItem)
        // then
//        XCTAssert(Tools.currentWindow() == true)
    }
    func testcelldequeue() throws {
        // given
        LensInformationPageViewController.shared.viewDidLoad()
        if let pageModel = LensInformationPageViewController.shared.dataModels.first {
            pageModel.selected = true
        }
        // when
        let cell = LensInformationPageViewController.shared.tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId)
        // then
        if let cell = cell as? LensInformationCell {
            XCTAssertNotNil(cell)
        } else {
            XCTFail()
        }
        LensInformationPageViewController.shared.tableView.selectRow(at: IndexPath(row: 0, section: 0), animated: false, scrollPosition: .none)
    }
    
    func testFeedCell() throws {
        // given
        LensInformationPageViewController.shared.viewDidLoad()
        if let pageModel = LensInformationPageViewController.shared.dataModels.first {
            pageModel.selected = true
        }
        
        // when
        var model = LensBaseModel(titles: [""], time: NSDate(), titleText: "", subtitleText: "", contentText: "", isExpanded: true, cellIdentity: Const.LensInformationCellId, accessoryInfo: .none, actionType: .expandable(true), needsAlert: true, leadingImage: UIImage(systemName: "scope"), detailPageContent : .text("", 20), cellHeight: 20)
        if let cell = LensInformationPageViewController.shared.tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId) as? LensInformationCell {
            cell.feed(model)
            // then
            XCTAssert(cell.subTitleLabel.isHidden == true)
            XCTAssert(cell.contentLabel.isHidden == false)
        } else {
            XCTFail()
        }
        
        // when
        model = LensBaseModel(titles: [""], time: NSDate(), titleText: "", subtitleText: "", contentText: "", isExpanded: true, cellIdentity: Const.LensInformationCellId, accessoryInfo: .none, actionType: .plate, needsAlert: true, leadingImage: UIImage(systemName: "scope"), detailPageContent: .text("", 20), cellHeight: 20)
        if let cell = LensInformationPageViewController.shared.tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId) as? LensInformationCell {
            cell.feed(model)
            // then
            XCTAssert(cell.subTitleLabel.isHidden == false)
            XCTAssert(cell.contentLabel.isHidden == true)
        } else {
            XCTFail()
        }
        
        // when
        model = LensBaseModel(titles: [""], time: NSDate(), titleText: "", subtitleText: "", contentText: "", isExpanded: true, cellIdentity: Const.LensInformationCellId, accessoryInfo: .none, actionType: .detailable(true), needsAlert: true, leadingImage: UIImage(systemName: "scope"), detailPageContent: LensDetailPageContentType.none, cellHeight: 20)
        if let cell = LensInformationPageViewController.shared.tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId) as? LensInformationCell {
            cell.feed(model)
            // then
            XCTAssert(cell.detailImageView.image == LensResources.cellDetailDetailableIcon)
        } else {
            XCTFail()
        }
        
        // when
        model = LensBaseModel(titles: [""], time: NSDate(), titleText: "", subtitleText: "", contentText: "", isExpanded: true, cellIdentity: Const.LensInformationCellId, accessoryInfo: .accessory((LensResources.cellDetailDetailableIcon, .red), ("", .red)), actionType: .detailable(true), needsAlert: true, leadingImage: UIImage(systemName: "scope"), detailPageContent: .image(LensResources.cellDetailDetailableIcon), cellHeight: 20)
        if let cell = LensInformationPageViewController.shared.tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId) as? LensInformationCell {
            cell.feed(model)
            // then
            XCTAssert(cell.detailImageView.image == LensResources.cellDetailDetailableIcon)
        } else {
            XCTFail()
        }
    }


    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
