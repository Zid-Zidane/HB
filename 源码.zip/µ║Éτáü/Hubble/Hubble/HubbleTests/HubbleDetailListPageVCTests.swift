//
//  HubbleDetailListPageVCTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/2.
//

import XCTest
@testable import Hubble

final class HubbleDetailListPageVCTests: XCTestCase {

    var vc = LensDetailListPageViewController()
    override func setUpWithError() throws {
        vc = LensDetailListPageViewController()
        vc.dataModels.removeAll()
    }

    override func tearDownWithError() throws {
    }

    func testrefreshPageModel() throws {
        // give
        let target = "title"
        let model = LensBasePageModel(type: LensPageStruct(target), title: target, selected: true, toolItems: [])
        // when
        vc.refreshPageModel([model])
        // then
        XCTAssert(vc.dataModels.count > 0)
    }
    func testshareButtonClicked() throws {
        // give
        let target = "title"
        let model = LensBasePageModel(type: LensPageStruct(target), title: target, selected: true, toolItems: [])
        // when
        vc.viewDidLoad()
        _ = vc.refreshPageModel([model])
        vc.shareButtonClicked()
        // then
//        XCTAssert(vc.presentedViewController is UIActivityViewController)
    }
    func testonSegmentAction() throws {
        // give
        let target = "title"
        let model = LensBasePageModel(type: LensPageStruct(target), title: target, selected: true, toolItems: [])
        _ = vc.refreshPageModel([model])
        // when
        vc.viewDidLoad()
        vc.onSegmentAction()
        // then
        XCTAssert(vc.dataModels.last?.selected == true)
    }
    func testcellForRowAt() throws {
        // give
        let target = "title"
        let model = LensBasePageModel(type: LensPageStruct(target), title: target, selected: true, toolItems: [])
        _ = vc.refreshPageModel([model])
        // when
        vc.viewDidLoad()
        if let cell = vc.tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId) {
            // then
            XCTAssert(cell is LensInformationCell)
        } else {
            XCTFail()
        }
    }
    func testdidSelectRowAt() throws {
        // give
        let target = "title"
        let model = LensBasePageModel(type: LensPageStruct(target), title: target, selected: true, toolItems: [])
        _ = vc.refreshPageModel([model])
        vc.viewDidLoad()
        // when
        vc.tableView.selectRow(at: IndexPath(row: 0, section: 0), animated: false, scrollPosition: .none)
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
