//
//  HubblePageAlertModelTests.swift
//  HubbleTests
//
//  Created by hazhu1 on 2023/5/1.
//

import XCTest
@testable import Hubble

final class HubblePageAlertModelTests: XCTestCase {
    
    override func setUpWithError() throws {

    }
    
    override func tearDownWithError() throws {

    }
 
    func testinit() {
        let target = LensPageAlertModel.shared
        let result = LensPageAlertModel.shared
        XCTAssert(target === result)
    }
    func testappendAlertItem() {
        let target: LensModelProtocol? = LensBaseModel(titles: [], time: nil, titleText: nil, subtitleText: nil, contentText: nil, isExpanded: false, cellIdentity: "", accessoryInfo: .none, actionType: .plate, needsAlert: false, leadingImage: nil, detailPageContent: nil, cellHeight: nil)
        if let target = target {
            LensPageAlertModel.shared.appendAlertItem(target)
            if let cellModels = LensPageAlertModel.shared.sectionItems.first?.cellModels,
            let result = cellModels.last{
                XCTAssert(result === target)
            } else {
                XCTFail()
            }
        } else {
            XCTFail()
        }
    }
    
}
