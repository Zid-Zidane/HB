//
//  HubbleManager.swift
//  demo
//
//  Created by hazhu1 on 2023/4/6.
//

import Foundation

public class HubbleManager {
    public static let shared = HubbleManager()
    private init() {}
    
    var debugHandler: BlankHandler? = nil
    internal var lensData: [String: String]? = [:]
    var factoryMap: [String: LensBaseModelFactory] = [:]
    public var viewPageNameHanler: (()->String)?
    public var currentViewPageHanler: (()->UIViewController?)?
    
    // MARK: - Public -
    
    public func regist(_ factories: [LensBaseModelFactory]) {
        var _factories = factories
        for factory in _factories {
            guard let pageModel = factory.pageModel(factory.title, visible: factory.visible) else { return }
            LensManager.shared.append(pageModel)
            self.factoryMap[factory.title] = factory
            do {
                try LensBaseModelFactory.defaultFactory.regist(type: LensPageStruct(factory.title), factory: factory, pageModel: pageModel)
            } catch {}
        }
    }
    
    public static func logFactory(_ type: String) -> LensBaseModelFactory? {
        guard let factory = Self.shared.factoryMap[type] else { return nil }
        return factory
    }
    
    public func show(_ lensData: [String: String]? = nil, _ metaData: [String: String]? = nil) {
        setLensData(lensData)
        setMetaData(metaData)
        EnvModePeep.show()
    }
    
    public func fold() {
        EnvModePeep.shared.changeContentView(true)
    }

    public func close() {
        EnvModePeep.hide()
    }
    
    public func avalible() -> Bool {
        return EnvModePeep.getPostStatus()
    }
    
    public func setAvalible(_ status: Bool) {
        EnvModePeep.setCurrentStatus(status)
    }
    
    public func isShown() -> Bool {
        return !EnvModePeep.shared.isHidden
    }
    
    public func setLensData(_ lensData: [String: String]?) {
        self.lensData = lensData
        LensPageMetaModel.shared.setMetaData(lensData)
    }
    
    public func setMetaData(_ metaData: [String: String]?) {
        LensPageMetaModel.shared.setMetaData(metaData)
    }
    
    @discardableResult
    public func generateWithError(_ model: LensModelProtocol?) -> Self {
        return self
    }
    
    @discardableResult
    public func then() -> Self {
        return self
    }
    
    public var alert: Self {
        return self
    }
    
    public var upload: Self {
        return self
    }

    @discardableResult
    public static func businessGuard(_ scope: String) -> HubbleManager {
        return HubbleManager.shared
    }
    
    public static func basicInfoString() -> String {
        let lensData = HubbleManager.shared.lensData?.description ?? ""
        let basicData = LensGroupMetaModel.shared.basicInfo()
        return lensData + "\n" + basicData
    }
    
}
