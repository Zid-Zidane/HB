//
//  EnvModePeepView.swift
//  Eats
//
//  Created by hazhu1 on 2022/7/11.
//  Copyright © 2022. All rights reserved.
//

import UIKit

@objc public class EnvModePeep: UIWindow {

    // MARK: new
    @objc public static var shared = EnvModePeep()
    lazy var infoPage: UIViewController = {
        let page = LensManager.lensInfoMainPage {
            EnvModePeep.hide()
        } foldHandler: {
            self.changeContentView(true)
        } debugHandler: {
            HubbleManager.shared.debugHandler?()
        }
        return page
    }()
    // MARK: new
    
    enum Constants {
        static var peepLength = 50.0
        static var peepLengthSmall = 50.0
        static var peepLengthLarge = 300.0
    }
    
    static let envModePeepStatusKey = "EnvModePeepStatusKey"
    
//    static var peepWindow = EnvModePeep()
    static var peepView = EnvModePeepView.share
    
    var _touchPoint: CGPoint?
    var _touchBtnX: CGFloat?
    var _touchBtnY: CGFloat?
    
    func kNavBarHeight(_ view: UIViewController? = nil) -> CGFloat {
//        return UIApplication.shared.activeKeyWindow?.rootViewController?.navigationController?.navigationBar.frame.size.height ?? 64
        return 64
    }
    
    static func getPostStatus() -> Bool {
        return UserDefaults.standard.bool(forKey: envModePeepStatusKey)
    }
    
    static func setCurrentStatus(_ status: Bool) {
        UserDefaults.standard.setValue(status, forKey: envModePeepStatusKey)
    }
    
    @objc
    func doClose() {
        EnvModePeep.hide()
    }
    
    // MARK: - TouchEvent -
    
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        if let touch = touches.first {
            _touchPoint = touch.location(in: self)
            
            _touchBtnX = self.frame.origin.x
            _touchBtnY = self.frame.origin.y
        }
    }
    
    open override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        let currentPosition = touch.location(in: self)
        
        let offsetX = currentPosition.x - (_touchPoint?.x ?? 0.0)
        let offsetY = currentPosition.y - (_touchPoint?.y ?? 0.0)
        
        let centerX = self.centerX + offsetX
        var centerY = self.centerY + offsetY
        self.center = CGPoint(x: centerX, y: centerY)
        
        let btnX = self.frame.origin.x
        let btnY = self.frame.origin.y
        let btnW = self.frame.size.width
        let btnH = self.frame.size.height
        
        if btnX > UIScreen.cou_screenWidth {
            let centerX = UIScreen.cou_screenWidth - btnW / 2
            self.center = CGPoint(x: centerX, y: centerY)
        } else if btnX < 0 {
            let centerX = btnW / 2
            self.center = CGPoint(x: centerX, y: centerY)
        }
        
        let defaultNaviHeight = kNavBarHeight()
        let judgeSuperViewHeight = UIScreen.cou_screenHeight - defaultNaviHeight
        
        if btnY <= 0 {
            centerY = btnH * 0.7
            self.center = CGPoint(x: centerX, y: centerY)
        } else if btnY > judgeSuperViewHeight {
            let y = UIScreen.cou_screenHeight - btnH / 2
            self.center = CGPoint(x: btnX, y: y)
        }
    }
    
    open override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let btnY = self.frame.origin.y
        let btnX = self.frame.origin.x
        let minDistance = 2.0

        let isOverX: Bool = fabs(btnX - _touchBtnX.orZero) > minDistance
        let isOverY: Bool = fabs(btnY - _touchBtnY.orZero) > minDistance
        
        if isOverX || isOverY {
            self.touchesCancelled(touches, with: event)
        } else {
            super.touchesEnded(touches, with: event)
            showInfomationView()
        }
        
        self.setMovingDirectionWithBtnX(btnX: btnX, btnY: btnY)
        
    }
    
    func setMovingDirectionWithBtnX(btnX: CGFloat, btnY: CGFloat) {
        if self.centerX >= UIScreen.cou_screenWidth / 2 {
            UIView.animate(withDuration: 0.25, delay: 0.25, options: .curveEaseInOut) {
                let btnX = UIScreen.cou_screenWidth - Constants.peepLength
                self.frame = CGRect(x: btnX, y: btnY, width: Constants.peepLength, height: Constants.peepLength)
            }
        } else {
            UIView.animate(withDuration: 0.25, delay: 0.25, options: .curveEaseInOut) {
                let btnX = 0.0
                let size = CGSize(width: Constants.peepLength, height: Constants.peepLength)
                self.frame = CGRect(x: btnX, y: btnY, width: Constants.peepLength, height: Constants.peepLength)
                EnvModePeep.peepView.size = size
            }
        }
    }
    
    // MARK: - Public -
    static func show() {
        DispatchQueue._once(token: "com.eats.EnvModePeep") {
            shared = EnvModePeep(frame: CGRect(x: 0, y: 200, width: Constants.peepLength, height: Constants.peepLength))
            peepView = EnvModePeepView.share
            shared.addSubview(peepView)
            let viewController = UIViewController()
            viewController.view.backgroundColor = .clear
            viewController.view.isUserInteractionEnabled = false
            shared.rootViewController = viewController
            shared.makeKeyAndVisible()
            shared.windowLevel = UIWindow.Level.alert - 1
            
            HubbleManager.shared.regist([LensViewGuardLogFactory.shared])
        }
        
        shared.isHidden = false
        EnvModePeep.setCurrentStatus(true)
        peepView.showLensData(HubbleManager.shared.lensData)
    }
    
    static func hide() {
        shared.isHidden = true
        EnvModePeep.setCurrentStatus(false)
        EnvModePeep.shared.changeContentView(true)
        LensWindowGuard.shared.stop()
    }
    
    func changeContentView(_ showPeepView: Bool) {
        if showPeepView {
            EnvModePeep.peepView.isHidden = false
            let viewController = UIViewController()
            viewController.view.backgroundColor = .clear
            viewController.view.isUserInteractionEnabled = false
            self.rootViewController = viewController
            Constants.peepLength = Constants.peepLengthSmall
            self.bounds = CGRect(origin: .zero, size: CGSize(width: Constants.peepLengthSmall, height: Constants.peepLengthSmall))
        } else {
            EnvModePeep.peepView.isHidden = true
            self.rootViewController = infoPage
            Constants.peepLength = Constants.peepLengthLarge
            self.bounds = CGRect(origin: .zero, size: CGSize(width: Constants.peepLengthLarge, height: Constants.peepLengthLarge))
        }
        var frame = self.frame
        frame.origin.x = 0
        self.frame = frame
    }
    
}

class EnvModePeepView: UIView {
    
    static let share = EnvModePeepView()
    lazy var stackView: UIStackView = {
        let stack = UIStackView(frame: self.bounds)
        stack.axis = .vertical
        stack.distribution = .fillProportionally
        self.addSubview(stack)
        return stack
    }()
    var backgroundLayer = CALayer()
    let normalColor = UIColor.brown.withAlphaComponent(0.3)
    let abnormalColor = UIColor.systemRed
    
    private init() {
        super.init(frame: CGRect(x: 0, y: 0, width: EnvModePeep.Constants.peepLength, height: EnvModePeep.Constants.peepLength))

        backgroundLayer.frame = CGRect(x: 0, y: 0, width: EnvModePeep.Constants.peepLength, height: EnvModePeep.Constants.peepLength)
        backgroundLayer.backgroundColor = UIColor.brown.withAlphaComponent(0.3).cgColor
        backgroundLayer.borderWidth = 0.5
        backgroundLayer.borderColor = UIColor.green.withAlphaComponent(0.8).cgColor
        self.layer.addSublayer(backgroundLayer)
        
        let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(onLongPress))
        self.isUserInteractionEnabled = true
        self.addGestureRecognizer(longGesture)
        
        NotificationCenter.default.addObserver(self, selector: #selector(receiveAlert), name: .kLensAlertNotification, object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc
    func receiveAlert() {
        backgroundLayer.backgroundColor = abnormalColor.cgColor
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.backgroundLayer.backgroundColor = self.normalColor.cgColor
        }
    }
    
    @objc
    func onLongPress() {
        if let window = self.superview as? EnvModePeep {
            window.replaceInformationView()
        }
    }
    
    func showLensData(_ lensData: [String: String]?) {
        guard let lensData = lensData else { return }
        
        for item in stackView.subviews {
            item.removeFromSuperview()
        }
        
        for (key, value) in lensData {
            let label = UILabel(frame: self.bounds)
            label.adjustsFontSizeToFitWidth = true
            label.minimumScaleFactor = 0.2
            stackView.addArrangedSubview(label)
            label.attributedText = self.attributeContent("\(key): \(value)")
        }
    }
    
    func attributeContent(_ str: String) -> NSMutableAttributedString {
        let textFontAttributes = [
            NSAttributedString.Key.strokeColor: UIColor.blue,
            NSAttributedString.Key.foregroundColor: UIColor.systemRed,
            NSAttributedString.Key.strokeWidth: -3.0,
            NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 30)]
        as [NSAttributedString.Key: Any]
        
        let mutableString = NSMutableAttributedString(string: str, attributes: textFontAttributes)
        return mutableString
    }
}

/// New method here
extension EnvModePeep {
    /// 显示更多信息
    func showInfomationView() {
        expand()
    }
    
    func expand() {
        Constants.peepLength = Constants.peepLengthLarge
    }
    
    func fold() {
        self.width = 50
        self.height = 50
    }
    
    func replaceInformationView() {
        changeContentView(false)
    }
}
