//
//  LensBasePageModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/10.
//

import Foundation

class LensBasePageModel: LensPageModelProtocol {
    var visible: Bool = true
    var type: LensPageStruct = LensPageStruct("business")
    
    var title: String = ""
    
    var selected: Bool = false
    
    var now: Bool = false
    
    var sectionItems: [LensGroupModelProtocol] = []
    
    var toolItems: [LensToolItemType] = []
    
    var reload: BlankHandler?
    
    var scrollToBottom: PageModelHandler?
    
    var allFLHandlers: [String : Any]?
    
    init(type: LensPageStruct, title: String, selected: Bool, toolItems: [LensToolItemType], visible: Bool = true) {
        self.type = type
        self.title = title
        self.visible = visible
        self.selected = selected
        self.toolItems = toolItems
    }
    
}


class LensBasePageMITMModel: LensPageModelMITMProtocol {
    var visible: Bool = true
    var type: LensPageStruct = LensPageStruct("business")
    
    var title: String = ""
    
    var selected: Bool = false
    
    var now: Bool = false
    
    var sectionItems: [LensGroupModelProtocol] = []
    
    var toolItems: [LensToolItemType] = []
    
    var reload: BlankHandler?
    
    var scrollToBottom: PageModelHandler?
    
    var updateMITM: MITMModelHandler?
    
    var allFLHandlers: [String : Any]?
    
    init(type: LensPageStruct, title: String, selected: Bool, toolItems: [LensToolItemType]) {
        self.type = type
        self.title = title
        self.selected = selected
        self.toolItems = toolItems
    }
    
}
