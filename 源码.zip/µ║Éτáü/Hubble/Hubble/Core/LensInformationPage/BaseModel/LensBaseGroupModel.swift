//
//  LensBaseGroupModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/9.
//

import Foundation

class LensBaseGroupModel: LensGroupModelProtocol {
    var section: LensModelProtocol?
    
    var cellModels: [LensModelProtocol?] = []
    
    var priproty: Int = 0

    init(section: LensModelProtocol? = nil, cellModels: [LensModelProtocol?], priproty: Int) {
        self.section = section
        self.cellModels = cellModels
        self.priproty = priproty
    }
    
    func append(_ item: LensModelProtocol) {
        cellModels.append(item)
    }
    
}
