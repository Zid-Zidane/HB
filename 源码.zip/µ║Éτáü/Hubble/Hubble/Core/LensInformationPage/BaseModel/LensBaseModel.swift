//
//  LensBaseModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/3.
//

import UIKit

class LensBaseModel: LensModelProtocol {
    var titles: [String?]
    var time: NSDate?
    var detaiImage: UIImage?
    var titleText: String?
    var subtitleText: String?
    var contentText: String?
    var isExpanded: Bool
    var cellIdentity: String = ""
    var accessoryInfo: LensCellAccessoryInfo
    var actionType: LensCellActionType
    var needsAlert: Bool = false
    var _leadingImage: UIImage?
    var detailPageContent: LensDetailPageContentType?
    var cellHeight: CGFloat?
    var leadingImage: UIImage? {
        get {
            if let model = self as? LensModelMITMProtocol {
                return model.transaction.thumbnail
            } else {
                return _leadingImage
            }
        }
        set {
            _leadingImage = newValue
        }
    }
    
    init(titles: [String?] = [],
         time: NSDate? = nil,
         detaiImage: UIImage? = nil,
         titleText: String? = nil,
         subtitleText: String? = nil,
         contentText: String? = nil,
         isExpanded: Bool = false,
         cellIdentity: String,
         accessoryInfo: LensCellAccessoryInfo = .none,
         actionType: LensCellActionType = .plate,
         needsAlert: Bool = false,
         leadingImage: UIImage? = nil,
         detailPageContent: LensDetailPageContentType? = nil,
         cellHeight: CGFloat? = nil) {
        self.titles = titles
        self.titleText = titleText
        self.detaiImage = detaiImage
        self.subtitleText = subtitleText
        self.contentText = contentText
        self.isExpanded = isExpanded
        self.cellIdentity = cellIdentity
        self.accessoryInfo = accessoryInfo
        self.actionType = actionType
        self.needsAlert = needsAlert
        self.leadingImage = leadingImage
        self.detailPageContent = detailPageContent
        self.cellHeight = cellHeight
    }
     
}


class LensBaseModelMITM: LensModelMITMProtocol {
    
    var transaction: MITMTransaction
    var titles: [String?]
    var time: NSDate?
    var detaiImage: UIImage?
    var titleText: String?
    var subtitleText: String?
    var contentText: String?
    var isExpanded: Bool
    var cellIdentity: String
    var accessoryInfo: LensCellAccessoryInfo
    var needsAlert: Bool
    var actionType: LensCellActionType
    var updateMITM: MITMModelHandler?
    var leadingImage: UIImage?
    var onClickeHandler: FromViewControllerHandler?
    var detailPageContent: LensDetailPageContentType?
    var cellHeight: CGFloat?
    
    init(transaction: MITMTransaction,
         titles: [String?],
         time: NSDate? = nil,
         detaiImage: UIImage? = nil,
         titleText: String? = nil,
         subtitleText: String? = nil,
         contentText: String? = nil,
         isExpanded: Bool,
         cellIdentity: String,
         accessoryInfo: LensCellAccessoryInfo,
         needsAlert: Bool,
         actionType: LensCellActionType,
         leadingImage: UIImage? = nil,
         onClickeHandler: FromViewControllerHandler? = nil,
         detailPageContent: LensDetailPageContentType? = nil,
         cellHeight: CGFloat? = nil) {
        self.transaction = transaction
        self.titles = titles
        self.detaiImage = detaiImage
        self.time = time
        self.titleText = titleText
        self.subtitleText = subtitleText
        self.contentText = contentText
        self.isExpanded = isExpanded
        self.cellIdentity = cellIdentity
        self.accessoryInfo = accessoryInfo
        self.needsAlert = needsAlert
        self.actionType = actionType
        self.leadingImage = leadingImage
        self.onClickeHandler = onClickeHandler
        self.detailPageContent = detailPageContent
        self.cellHeight = cellHeight
        
        self.transaction.onRefreshHandler = {
            self.updateByTransaction()
        }
        self.transaction.onStateChangeHandler = {
            if $0.state == .lensNetworkTransactionStateFailed {
                DispatchQueue.main.async(execute: {
                    LensPageAlertModel.shared.appendAlertItem(self)
                })
            }
        }
    }
    
    func updateByTransaction() {
        titleText = transaction.mainMessage()
        subtitleText = transaction.subMessage()
        contentText = transaction.contentMessage()
        leadingImage = transaction.thumbnail
    }
    
}
