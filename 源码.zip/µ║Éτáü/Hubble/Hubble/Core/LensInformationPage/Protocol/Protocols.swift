//
//  Protocols.swift
//  demo
//
//  Created by hazhu1 on 2023/4/3.
//

import UIKit

// MARK: - View -
protocol LensInformationCellProtocol: LensExpandableCellProtocol, LensCellFeedProtocol {}

protocol LensExpandableCellProtocol where Self: UITableViewCell {
    func fold()
    func expand()
    func onClick(_ handler: BlankHandler?)
}

protocol LensCellFeedProtocol: LensViewFeedProtocol where Self: UITableViewCell {}

protocol LensViewFeedProtocol: UIView {
    func feed(_ model: LensModelProtocol)
}



// MARK: - Model -
public protocol LensPageModelProtocol: AnyObject {
    var visible: Bool { get }           // visible in tab
    var title: String { get }                   // page segment title
    var now: Bool { get set }                   // keep with newest data when refresh feed list, default is false,
    var selected: Bool { get set }
    var type: LensPageStruct { get }
    var reload: BlankHandler? { get set }
    var toolItems: [LensToolItemType] { get }
    var allFLHandlers: [String: Any]? { get set }
    var scrollToBottom: PageModelHandler? { get set }
    var sectionItems: [LensGroupModelProtocol] { get set }
    func append(_ item: LensModelProtocol, handler: ((LensModelProtocol) -> Void)?)
}

public protocol LensGroupModelProtocol: AnyObject {
    var priproty: Int { get }
    var section: LensModelProtocol? { get }
    var cellModels: [LensModelProtocol?] { set get }
    
    func append(_ item: LensModelProtocol)
}

public protocol LensModelProtocol: AnyObject {
    
    /// ↓↓↓ for carousel
    var titles: [String?] { get }
    
    // ↓↓↓ for single cell
    var needsAlert: Bool { get }                                // If true then will appear in warning tab
    var time: NSDate? { get set }
    var detaiImage: UIImage? { get }
    var isExpanded: Bool { get set }                            // Allows To Expand
    var cellIdentity: String { get }
    var cellHeight: CGFloat? { get }
    var leadingImage: UIImage? { get }
    var titleText: String? { get set }
    var contentText: String? { get set }
    var subtitleText: String? { get set }
    var actionType: LensCellActionType { get }
    var accessoryInfo: LensCellAccessoryInfo { get }
    var detailPageContent: LensDetailPageContentType? { get }   // Used In Detail Page Only And Priority Is Higher Than ContentText
}

// MARK:  - MITM Model Protocol -
protocol LensPageModelMITMProtocol: LensPageModelProtocol {
    var updateMITM: MITMModelHandler? { get }
}

protocol LensModelMITMProtocol: LensModelProtocol {
    var transaction: MITMTransaction { get }
    var onClickeHandler: ((UIViewController)->Void)? { get }
}
    
// MARK:  - Alert Model Protocol -

extension LensPageModelProtocol {
    func setAllFLHandlers(_ handlers: [String: Any]) -> LensPageModelProtocol{
        self.allFLHandlers = handlers
        reload = allFLHandlers?[LensFeedListActionHanderName.reloadHandler.rawValue] as? BlankHandler
        scrollToBottom = allFLHandlers?[LensFeedListActionHanderName.scrollToBottomHandler.rawValue] as? PageModelHandler
        return self
    }
    func append(_ item: LensModelProtocol, handler: ((LensModelProtocol) -> Void)? = nil) {
        if item.needsAlert {
            LensPageAlertModel.shared.appendAlertItem(item)
        } else {
            // 1. add normal item
            if handler == nil {
                if self.sectionItems.count == 0 {
                    self.sectionItems.append(LensBaseGroupModel(cellModels: [], priproty: 0))
                }
                self.sectionItems.first?.cellModels.append(item)
            } else {
                handler?(item)
            }
        }
        if LensInformationPageViewController.shared.viewIfLoaded?.window != nil {
            // 2. refresh table view
            if self.selected {
                self.reload?()
                // 3. scroll to bottom
                if self.now {
                    self.scrollToBottom?(self)
                }
            }
        }
    }
    
}

// MARK:  - Model Generator -
public protocol LensPageGeneratorProtocol: AnyObject {
    var title: String { get set }
    func generate(type: LensPageStruct!, groupName: String?, title: String, subTitle: String, contentText: String, snapshot: UIImage?, needsAlert: Bool, expandable: Bool) throws -> LensModelProtocol?
    func update(type: LensPageStruct!, model: LensModelProtocol) throws
    func generateThenUpdate(type: String!, groupName: String?, title: String, subTitle: String, contentText: String, snapshot: UIImage?, needsAlert: Bool) throws
}
