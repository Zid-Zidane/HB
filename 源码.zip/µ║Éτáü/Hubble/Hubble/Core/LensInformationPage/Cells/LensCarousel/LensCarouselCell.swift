//
//  LensCarouselCell.swift
//  demo
//
//  Created by hazhu1 on 2023/4/3.
//

import UIKit

class LensCarouselCell: UICollectionViewCell {
    
    var textLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        makeUI()
    }
    
    func makeUI() {
        self.backgroundColor = .systemGray
        
        self.addSubview(textLabel)
        
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            textLabel.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            textLabel.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            textLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            textLabel.topAnchor.constraint(equalTo: self.topAnchor)
        ])
                 
        textLabel.adjustsFontSizeToFitWidth = true
    }
    
    func setContent(_ text: String) {
        textLabel.text = text
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
//    override func layoutSubviews() {
//        super.layoutSubviews()
//        textLabel.frame = self.bounds
//    }
    
}
