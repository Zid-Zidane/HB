//
//  LensCarousel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/3.
//

import UIKit

/// View hierarchy
/// - tableView
///     - LensCarousel
///         - LensCarouselCell  LensCarouselCell  LensCarouselCell  LensCarouselCell
///     - other cells

class LensCarousel: UITableViewHeaderFooterView, LensViewFeedProtocol {

    var dataSource: [String?] = []
    var collectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewLayout())
    var loaded = false
    
//    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
//        super.init(style: style, reuseIdentifier: reuseIdentifier)
//        makeUI()
//    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        makeUI()
    }
    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        makeUI()
//    }
     
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func makeUI() {
//        self.contentView.addSubview(collectionView)
        self.addSubview(collectionView)
        
//        collectionView.collectionViewLayout = layout
        
        let flowLayout =  UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .horizontal
        collectionView.collectionViewLayout = flowLayout
        
        collectionView.register(LensCarouselCell.self, forCellWithReuseIdentifier: Const.LensCarouselCellId)
            
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            collectionView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            collectionView.topAnchor.constraint(equalTo: self.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            collectionView.trailingAnchor.constraint(equalTo: self.trailingAnchor)
        ])
        
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    func feed(_ model: LensModelProtocol) {
        defer {
//            if loaded == false {
                collectionView.reloadData()
//            }
            loaded = true
        }
        dataSource = model.titles
    }
    
    /// MARK: Tools
    var layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.sectionInset = .zero
        layout.minimumLineSpacing = 2
        var itemSize: CGSize = CGSize(width: 60, height: 44)
//        if #available(iOS 10.0, *) {
//            itemSize = UICollectionViewFlowLayout.automaticSize
//        }
        layout.itemSize = itemSize
        layout.estimatedItemSize = itemSize
        return layout
    }()
    
}

extension LensCarousel: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Const.LensCarouselCellId, for: indexPath) as? LensCarouselCell else {
            return UICollectionViewCell(frame: .zero)
        }
        
        let text = dataSource[indexPath.row]
        cell.setContent(text ?? "")
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
}
