//
//  LensInformationCell.swift
//  demo
//
//  Created by hazhu1 on 2023/4/3.
//

import UIKit

class LensInformationCell: UITableViewCell {
    
    @IBOutlet weak var leadingImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var detailImageView: UIImageView!
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var contentImageView: UIImageView!
    @IBOutlet weak var accessoryLabel: UILabel!
    @IBOutlet weak var accessoryImageView: UIImageView!
    
    var model: LensModelProtocol?
    
    enum Const {
        static let LensInformationCellId = "LensInformationCellId"
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

}

extension LensInformationCell: LensInformationCellProtocol {
    func expand() {
        model?.isExpanded = true
        updateUI()
    }
    
    func fold() {
        model?.isExpanded = false
        updateUI()
    }
    
    func onClick(_ handler: BlankHandler?) {
        switch model?.actionType {
        case .plate:
            break
        case .expandable(let allow):
            guard allow else { return }
            (model?.isExpanded ?? false) ? fold() : expand()
        case .detailable(let allow):
            guard allow else { return }
            handler?()
        default:
            break
        }
    }
    
    func feed(_ model: LensModelProtocol) {
        self.model = model
        self.titleLabel.text = model.titleText
        self.subTitleLabel.text = model.subtitleText
        self.contentLabel.text = model.contentText
        updateUI()
    }
    
    func updateUI() {
        let contentHandler: () -> Void = {
            self.titleLabel.isHighlighted = self.model?.titleText == nil
            
            if let detailPageContent = self.model?.detailPageContent {
                switch detailPageContent {
                case .text(let content, _):
                    self.contentLabel.text = detailPageContent.needsDisplayWK() ? "Tap To View" : content
                    self.contentImageView.isHidden = true
                    self.contentLabel.isHidden = false
                case .image(let content):
                    self.contentImageView.image = content
                    self.contentImageView.isHidden = false
                    self.contentLabel.isHidden = true
                case .none:
                    self.contentLabel.text = self.model?.contentText
                    self.contentImageView.isHidden = true
                    self.contentLabel.isHidden = false
                }
            }
        }
        let leadingHandler: () -> Void = {
            self.leadingImageView.isHidden = self.model?.leadingImage == nil
            self.leadingImageView.image = self.model?.leadingImage
        }
        let accessoryHandler: () -> Void = {
            if case .accessory((let image, let imageColor), (let text, let textColor)) = self.model?.accessoryInfo {
                self.accessoryLabel.isHidden = false
                self.accessoryImageView.isHidden = false
                self.accessoryLabel.text = text
                self.accessoryLabel.textColor = textColor
                self.accessoryImageView.image = image
                self.accessoryImageView.tintColor = imageColor
            } else {
                self.accessoryLabel.isHidden = true
                self.accessoryImageView.isHidden = true
            }
        }
        let foldHandler: () -> Void = {
            self.detailImageView.image = LensResources.cellDetailFoldIcon
            self.detailImageView.tintColor = .systemBlue
            self.subTitleLabel.isHidden = false
            self.contentLabel.isHidden = true
        }
        let expandHandler: (Bool) -> Void = { allow in
            self.detailImageView.isHidden = !(self.model?.isExpanded ?? false)
            if self.model?.isExpanded ?? false {
                self.detailImageView.image = LensResources.cellDetailExpandIcon
                self.detailImageView.tintColor = .systemPink
                self.subTitleLabel.isHidden = true
                self.contentLabel.isHidden = false
            } else {
                foldHandler()
            }
        }
        let actionTypeDetailHandler: (Bool) -> Void = { allow in
            self.detailImageView.isHidden = !allow
            self.detailImageView.image = LensResources.cellDetailDetailableIcon
            self.detailImageView.tintColor = .systemGreen
            self.subTitleLabel.isHidden = false
            if let isExpanded = self.model?.isExpanded {
                self.contentLabel.isHidden = !isExpanded
            }
        }
        let actionTypePlateHandler: () -> Void = {
            self.detailImageView.isHidden = true
            self.contentLabel.isHidden = true
            foldHandler()
            self.detailImageView.image = LensResources.cellDetailPlateIcon
            self.detailImageView.tintColor = .systemYellow
        }
        
        contentHandler()
        leadingHandler()
        accessoryHandler()
        switch model?.actionType {
        case .expandable(let allow):
            expandHandler(allow)
        case .detailable(let allow):
            actionTypeDetailHandler(allow)
        default:
            actionTypePlateHandler()
        }
    }
    
}
