//
//  LensInformationPageViewController.swift
//  demo
//
//  Created by hazhu1 on 2023/4/3.
//

import UIKit

class LensInformationPageViewController: UIViewController {
    var closeHandler: BlankHandler?
    var locateHandler: BlankHandler?
    var foldHandler: BlankHandler?
    var debugHandler: BlankHandler?
    var dataModels = [LensPageModelProtocol]()
    var tableView: UITableView = UITableView(frame: .zero, style: .grouped)
    var segment: UISegmentedControl = UISegmentedControl(frame: .zero)
    
    static let shared = LensInformationPageViewController()
    private override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    internal required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func viewDidLoad() {
        super.viewDidLoad()
        makeDatas()
        makeUI()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tableView.reloadData()
    }
    func makeUI() {
        self.view.backgroundColor = .systemYellow
        /// Set navigation bar
        updateNavigationBar()
        let dragItem = UIBarButtonItem(image: LensResources.dragIcon, style: .plain, target: nil, action: nil)
        dragItem.isEnabled = false
        self.navigationItem.rightBarButtonItem = dragItem
        /// segment
        segment = UISegmentedControl(items: dataModels.compactMap({ $0.title }))
        segment.addTarget(self, action: #selector(onSegmentAction), for: .valueChanged)
        self.view.addSubview(segment)
        segment.selectedSegmentIndex = 0
        segment.translatesAutoresizingMaskIntoConstraints = false
        segment.topAnchor.constraint(equalTo: self.view.topAnchor, constant: self.navigationController?.navigationBar.height ?? 0).isActive = true
        segment.heightAnchor.constraint(equalToConstant: LensConst.toolViewHeight.rawValue).isActive = true
        segment.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        segment.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        /// table view
        self.view.addSubview(tableView)
        tableView.sectionHeaderHeight = LensConst.sectionHeaderHeight.rawValue
        tableView.sectionFooterHeight = LensConst.sectionFooterHeight.rawValue
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.topAnchor.constraint(equalTo: segment.bottomAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        tableView.backgroundColor = .clear
        self.tableView.register(LensCarousel.self, forHeaderFooterViewReuseIdentifier: Const.LensCarouselId)
        self.tableView.register(UINib(nibName: "LensInformationCell", bundle: Bundle(for: Self.self)), forCellReuseIdentifier: Const.LensInformationCellId)
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    func makeDatas() {
        makeSections()
    }
    func makeSections() {
        let reloadHandler: BlankHandler = {
            self.tableView.reloadData()
        }
        let scrollToBottomHandler: PageModelHandler = {
            self.tableView.scrollToRow(at: IndexPath(row: (($0.sectionItems.last?.cellModels.count ?? 1) - 1), section: ($0.sectionItems.count - 1)), at: .bottom, animated: true)
        }
        let refreshMITMHandler: MITMModelHandler = {
            for cell in self.tableView.visibleCells {
                guard let cell = cell as? LensInformationCell,
                      let model = cell.model as? LensBaseModelMITM else { return }
                if model.transaction.requestID == $0.requestID {
                    cell.feed(model)
                    cell.setNeedsLayout()
                    break
                }
            }
        }
        let handlers: [String: Any] = [
            LensFeedListActionHanderName.reloadHandler.rawValue: reloadHandler,
            LensFeedListActionHanderName.scrollToBottomHandler.rawValue: scrollToBottomHandler,
            LensFeedListActionHanderName.refreshMITMHandler.rawValue: refreshMITMHandler
        ]
        dataModels.append(LensPageMetaModel.shared.setAllFLHandlers(handlers))
        dataModels.append(LensPageViewModel.shared.setAllFLHandlers(handlers))
        dataModels.append(LensPageNetModel.shared.setAllFLHandlers(handlers))
        dataModels += LensManager.shared.pageModels.filter({ $0.visible }).compactMap({$0.setAllFLHandlers(handlers)})
        dataModels.append(LensPageAlertModel.shared.setAllFLHandlers(handlers))
    }
    func updateNavigationBar() {
        if let currentPageModel: LensPageModelProtocol = dataModels.filter({ return $0.selected }).first {
            self.navigationItem.leftBarButtonItems = currentPageModel.toolItems.compactMap {
                var barItem = UIBarButtonItem()
                switch $0 {
                case .close:
                    barItem = UIBarButtonItem(image: LensResources.closeIcon, style: .done, target: self, action: #selector(closeButtonClicked))
                    barItem.tintColor = .systemRed
                case .locate:
                    barItem = UIBarButtonItem(image: LensResources.locateIcon, style: .done, target: self, action: #selector(locateButtonClicked))
                    barItem.tintColor = .black
                case .debug:
                    barItem = UIBarButtonItem(image: LensResources.debugIcon, style: .done, target: self, action: #selector(debugButtonClicked))
                    barItem.tintColor = .cyan
                case .fold:
                    barItem = UIBarButtonItem(image: LensResources.foldIcon, style: .done, target: self, action: #selector(foldButtonClicked))
                    barItem.tintColor = .systemGreen
                case .now:
                    barItem = UIBarButtonItem(image: LensResources.nowUnselectedIcon, style: .done, target: self, action: #selector(nowButtonClicked(_:)))
                    barItem.tintColor = .systemBlue
                    updateNowButton(barItem)
                default:
                    break
                }
                return barItem
            }
        }
    }
    func currentSelectedPageModel() -> LensPageModelProtocol? {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first else { return nil }
        return currentPageModel
    }
    func updateNowButton(_ barButtonItem: UIBarButtonItem) {
        barButtonItem.image = currentSelectedPageModel()?.now ?? false ? LensResources.nowIcon : LensResources.nowUnselectedIcon
    }
    @objc func onSegmentAction() {
        _ = dataModels.compactMap { $0.selected = ($0.title == segment.titleForSegment(at: segment.selectedSegmentIndex)) }
        self.tableView.reloadData()
        LensViewInspectorManager.hideViewInspector()
        updateNavigationBar()
    }
    @objc func closeButtonClicked() {
        closeHandler?()
    }
    @objc func locateButtonClicked() {
//        closeButtonClicked()
        locateHandler?()
    }
    @objc func foldButtonClicked() {
        foldHandler?() 
    }
    @objc func debugButtonClicked() {
//        debugHandler?()
//        guard let configPage = UIStoryboard(name: "LensConfigurationPage", bundle: Bundle(for: Self.self)).instantiateInitialViewController() else {return}
//        self.navigationController?.pushViewController(configPage, animated: true)
        guard let configPage = UIStoryboard(name: "MockLensConfigurationPage", bundle: Bundle(for: Self.self)).instantiateInitialViewController() else {return}
        self.navigationController?.pushViewController(configPage, animated: true)
    }
    @objc func nowButtonClicked(_ barButtonItem: UIBarButtonItem) {
        currentSelectedPageModel()?.now = !(currentSelectedPageModel()?.now ?? false)
        updateNowButton(barButtonItem)
    }
}

extension LensInformationPageViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first else { return 0 }
        return currentPageModel.sectionItems.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first else { return 0 }
        let cellModels = currentPageModel.sectionItems[section].cellModels
        return cellModels.count
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first else { return nil }
        guard let sectionModel = currentPageModel.sectionItems[section].section, sectionModel.titles.count == 0 else { return nil }
        return currentPageModel.sectionItems[section].section?.titleText
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        guard let sectionModel = currentSelectedPageModel()?.sectionItems[section].section else { return 2.0 }
        return sectionModel.titleText?.count ?? 0 > 0 ? LensConst.sectionHeaderHeight.rawValue : LensConst.sectionHeaderFooterEmptyHeight.rawValue
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first,
              let model = currentPageModel.sectionItems[indexPath.section].cellModels[indexPath.row] else { return UITableViewCell(frame: .zero) }
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId, for: indexPath) as? LensCellFeedProtocol else { return UITableViewCell(frame: .zero) }
        cell.feed(model)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let cell = tableView.cellForRow(at: indexPath) as? LensInformationCellProtocol else { return }
        let model = currentSelectedPageModel()?.sectionItems[indexPath.section].cellModels[indexPath.row]
        if let model = model as? LensModelMITMProtocol {
            cell.onClick { [weak self] in
                guard let ss = self else { return }
                model.onClickeHandler?(ss)
            }
        } else {
            let content = model?.contentText
            let model = LensWebViewModel(OriginalText: content, image: model?.detaiImage)
            let vc = LensWebViewController().setModel(model)
            self.navigationController?.pushViewController(vc, animated: true)
        }
        tableView.reloadRows(at: [indexPath], with: .none)
    }
}
