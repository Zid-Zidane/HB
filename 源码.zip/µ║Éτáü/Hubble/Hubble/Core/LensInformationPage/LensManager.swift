//
//  LensManager.swift
//  demo
//
//  Created by hazhu1 on 2023/4/5.
//

import UIKit

class LensManager {
    private init() {
        do {
            try LensBaseModelFactory.defaultFactory.regist(type: LensPageStruct("view"), factory: LensViewFactor(), pageModel: LensPageViewModel.shared)
        } catch {}
    }
    static let shared = LensManager()
    var pageModels: [LensPageModelProtocol] = []
    
    static func lensInfoMainPage(closeHandler: BlankHandler? = nil,
                                 foldHandler: BlankHandler? = nil,
                                 debugHandler: BlankHandler? = nil) -> UIViewController {
        let rootViewController = LensInformationPageViewController.shared
        rootViewController.closeHandler = closeHandler
        rootViewController.locateHandler = {
            LensViewInspectorManager.switchVisible()
        }
        rootViewController.foldHandler = foldHandler
        rootViewController.debugHandler = debugHandler
        return UINavigationController(rootViewController: rootViewController)
    }
    
    func append(_ pageModel: LensPageModelProtocol) {
        pageModels.append(pageModel)
    }
}
