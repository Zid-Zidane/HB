//
//  LensWebViewController.swift
//  demo
//
//  Created by hazhu1 on 2023/4/15.
//

import UIKit
import WebKit

class LensWebViewController: UIViewController {
    var _model: LensWebViewModel?
    var model: LensWebViewModel? {
        get {
            _model
        }
        set {
            _model = newValue
            refresh()
        }
    }
    lazy var wkView: WKWebView = {
        let configuration = WKWebViewConfiguration()
        if #available(iOS 10, *) {
            configuration.dataDetectorTypes = .all
        }
        let wkView = WKWebView(frame: .zero, configuration: configuration)
        return wkView
    }()
    var imageShared = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeUI()
    }
    func makeUI() {
        // navigation bar
        let shareItem = UIBarButtonItem(image: LensResources.shareIcon, style: .done, target: self, action: #selector(shareButtonClicked))
        self.navigationItem.rightBarButtonItem = shareItem
        // web
        view.addSubview(wkView)
        wkView.translatesAutoresizingMaskIntoConstraints = false
        wkView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        wkView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        wkView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        wkView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
    }
    @objc func shareButtonClicked() {
        imageShared = false
        shareAction(.log)
    }
    func shareAction(_ type: LensShareType = .log) {
        var items: [Any] = []
        switch type {
        case .log:
            if var log = model?.OriginalText {
                log = Tools.stringByRemoveHTMLElement(log)
                log = "1> ISSUE LOG\n" + log
                let basic = HubbleManager.basicInfoString()
                if basic.count > 0 {
                    log += "\n·············\n" + basic
                }
                items.append(log)
            }
        case .image:
            if let image = self.model?.image {
                items.append(image)
            }
        }
        let activityVC = UIActivityViewController(activityItems: items, applicationActivities: nil)
        activityVC.excludedActivityTypes = [
            .copyToPasteboard, .mail, .addToReadingList, .saveToCameraRoll,
        ]
        present(activityVC, animated: true)
        activityVC.completionWithItemsHandler = { [weak self] _, complete, _, _ in
            guard let ss = self else { return }
            if complete, type != .image {
                if ss.imageShared == false,
                   let _ = ss.model?.image {
                    ss.shareAction(.image)
                }
            } else if complete, type == .image {
                ss.imageShared = true
            }
        }
    }
    func setModel(_ model: LensWebViewModel) -> LensWebViewController {
        self.model = model
        return self
    }
    
    
    func refresh() {
        var interpolationString = "Loading..."
        var html = "<head><style>:root{ color-scheme: light dark; }</style>" + "<meta name='viewport' content='initial-scale=1.0'></head><body><pre>\(interpolationString)</pre></body>"
        self.wkView.loadHTMLString(html, baseURL: nil)
        
        DispatchQueue.global().async { [weak self] in
            guard let ss = self else { return }
            // TODO: Replace HTML Entities
            interpolationString = ss.model?.OriginalText ?? ""
            html = "<head><style>:root{ color-scheme: light dark; }</style>" + "<meta name='viewport' content='width=device-width'></head><body>"
            if let image = ss.model?.image,
               let imageData = image.jpegData(compressionQuality: 1) {
                let imageBase64 = imageData.base64EncodedString()
                html += "<br><img src=\"data:image/jpg;base64,\(imageBase64)\"><br>"
            }
            html += "<pre>\(interpolationString)</pre></body>"
            DispatchQueue.main.async {
                ss.wkView.loadHTMLString(html, baseURL: nil)
            }
        }
    }
    
}
