//
//  LensWebViewModel.swift
//  Hubble
//
//  Created by hazhu1 on 2023/5/6.
//

import Foundation

struct LensWebViewModel {
    var OriginalText: String?
    var image: UIImage?
}
