//
//  LensDetailListPageViewController.swift
//  demo
//
//  Created by hazhu1 on 2023/4/13.
//

import UIKit

class LensDetailListPageViewController: UIViewController {
    var dataModels = [LensPageModelProtocol]()
    var segment: UISegmentedControl = UISegmentedControl(frame: .zero)
    let tableView: UITableView = UITableView(frame: .zero, style: .grouped)
    func refreshPageModel(_ dataModels: [LensPageModelProtocol]) -> LensDetailListPageViewController {
        self.dataModels = dataModels
        return self
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        makeDatas()
        makeUI()
    }
    func makeUI() {
        self.view.backgroundColor = .systemYellow
        
        let shareItem = UIBarButtonItem(image: LensResources.shareIcon, style: .done, target: self, action: #selector(shareButtonClicked))
        self.navigationItem.rightBarButtonItem = shareItem
        /// segment
        segment = UISegmentedControl(items: dataModels.compactMap({ $0.title }))
        segment.addTarget(self, action: #selector(onSegmentAction), for: .valueChanged)
        self.view.addSubview(segment)
        segment.selectedSegmentIndex = 0
        segment.translatesAutoresizingMaskIntoConstraints = false
        segment.topAnchor.constraint(equalTo: self.view.topAnchor, constant: self.navigationController?.navigationBar.height ?? 0).isActive = true
        segment.heightAnchor.constraint(equalToConstant: LensConst.toolViewHeight.rawValue).isActive = true
        segment.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        segment.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        /// table view
        self.view.addSubview(tableView)
        tableView.sectionHeaderHeight = LensConst.sectionHeaderHeight.rawValue
        tableView.sectionFooterHeight = LensConst.sectionFooterHeight.rawValue
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.topAnchor.constraint(equalTo: segment.bottomAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        tableView.backgroundColor = .clear
        self.tableView.register(LensCarousel.self, forHeaderFooterViewReuseIdentifier: Const.LensCarouselId)
        self.tableView.register(UINib(nibName: "LensInformationCell", bundle: Bundle(for: Self.self)), forCellReuseIdentifier: Const.LensInformationCellId)
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    @objc func shareButtonClicked() {
        let activityVC = UIActivityViewController(activityItems: [
            "Issue Log Share"
        ], applicationActivities: nil)
        activityVC.excludedActivityTypes = [
            .copyToPasteboard, .mail, .addToReadingList, .saveToCameraRoll,
        ]
        present(activityVC, animated: true)
        activityVC.completionWithItemsHandler = { _, _, _, _ in
            
        }
    }
    func makeDatas() {
        makeSections()
        tableView.reloadData()
    }
    func makeSections() {}
    @objc func onSegmentAction() {
        _ = dataModels.compactMap { $0.selected = ($0.title == segment.titleForSegment(at: segment.selectedSegmentIndex)) }
        self.tableView.reloadData()
    }
}

extension LensDetailListPageViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first else { return 0 }
        return currentPageModel.sectionItems.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first else { return 0 }
        let cellModels = currentPageModel.sectionItems[section].cellModels
        return cellModels.count
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first else { return nil }
        guard let sectionModel = currentPageModel.sectionItems[section].section, sectionModel.titles.count == 0 else { return nil }
        return currentPageModel.sectionItems[section].section?.titleText
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first,
              let model = currentPageModel.sectionItems[indexPath.section].cellModels[indexPath.row] else { return UITableViewCell(frame: .zero) }
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Const.LensInformationCellId, for: indexPath) as? LensCellFeedProtocol else { return UITableViewCell(frame: .zero) }
        cell.feed(model)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first,
              let model = currentPageModel.sectionItems[indexPath.section].cellModels[indexPath.row] else { return }
        if case .detailable(let allow) = model.actionType,
           allow == true,
           case .text(let content, _) = model.detailPageContent {
            let model = LensWebViewModel(OriginalText: content, image: model.detaiImage)
            let vc = LensWebViewController().setModel(model)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
//    /// There is too much text to display on detail page, and autolayout cost too much resource for small windown.
//    /// Thus AOT calculation is needed
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        guard let currentPageModel: LensPageModelProtocol  = dataModels.filter({ return $0.selected }).first,
//              let model = currentPageModel.sectionItems[indexPath.section].cellModels[indexPath.row] else { return 0.0 }
//        return model.cellHeight ?? 20
//    }
}
