//
//  LensConfigurationCell.swift
//  Hubble
//
//  Created by hazhu1 on 2023/4/25.
//

import Foundation

class LensConfigurationSwitchCell: UITableViewCell {
    static let cellID = "LensConfigurationSwitchCell"
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var switcher: UISwitch!
    /*
    func setModel(_ model: LensSwitchData) {
        guard let key = model.keys.first,
              let value = model[key] else { return }
        titleLabel.text = key
        switcher.isOn = value
    }
     */
    func setModel(_ model: LensConfigurationSectionModel) {
        self.titleLabel.text = model.title
        self.switcher.isOn = model.switchStatus
    }
}


class LensConfigurationSwitchTVCell: UITableViewCell {
    static let cellID = "LensConfigurationSwitchTVCell"
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var switcher: UISwitch!
    @IBOutlet weak var textView: UITextView!
    
    func setModel(_ model: LensConfigurationSectionModel) {
        self.titleLabel.text = model.title
        self.switcher.isOn = model.switchStatus
    }
}


class LensConfigurationSwitchMultiSelectCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate {
    static let cellID = "LensConfigurationSwitchMultiSelectCell"
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var switcher: UISwitch!
    @IBOutlet weak var collectionView: UICollectionView!
    var models: [LensSwitchData]? = []
    
    func setModel(_ model: LensConfigurationSectionModel) {
        self.titleLabel.text = model.title
        self.switcher.isOn = model.switchStatus
        self.models = model.data
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return models?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LensConfigurationSwitchMultiSelectItem.cellID, for: indexPath) as? LensConfigurationSwitchMultiSelectItem else { return LensConfigurationSwitchMultiSelectItem(frame: .zero) }
        cell.setModel(models?[indexPath.item])
        return cell
    }
}

class LensConfigurationSwitchMultiSelectItem: UICollectionViewCell {
    static let cellID = "LensConfigurationSwitchMultiSelectItem"
    @IBOutlet weak var titleLabel: UILabel!
    func setModel(_ model: LensSwitchData?) {
        guard let key = model?.keys.first else { return }
        self.titleLabel.text = key
    }
}
