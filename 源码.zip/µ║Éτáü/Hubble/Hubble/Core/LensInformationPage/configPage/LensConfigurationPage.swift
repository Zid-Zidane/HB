//
//  LensConfigurationPage.swift
//  Alamofire
//
//  Created by hazhu1 on 2023/4/25.
//

import UIKit

class LensConfigurationPage: UITableViewController {

    var datas: [LensConfigurationPageModel]? = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeDatas()
        self.tableView.reloadData()
    }
    func makeDatas() {
        makeSections()
    }
    func makeSections() {
        self.datas = LensConfigurationModel.shared.getData()
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return datas?.count ?? 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
//        return datas[section].first?.key
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    
}
