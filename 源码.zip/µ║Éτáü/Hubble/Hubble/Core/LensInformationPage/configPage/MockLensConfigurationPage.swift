//
//  MockLensConfigurationPage.swift
//  Hubble
//
//  Created by hazhu1 on 2023/4/27.
//

import UIKit

class MockLensConfigurationPage: UITableViewController {

    var specTag = [
    [
        "GW1",
        "GW2",
        "GW3",
        "GW4",
        "GW5"
    ],
    [
        "SHP1",
        "SHP2",
        "SHP3",
        "SHP4",
        "SHP5"
    ],
    [
        "SRP1",
        "SRP2",
        "SRP3",
        "SRP4",
        "SRP5"
    ],
    [
        "SDP1",
        "SDP2",
        "SDP3",
        "SDP4",
        "SDP5"
    ],
    [
        "Checkout1",
        "Checkout2",
        "Checkout3",
        "Checkout4",
        "Checkout5"
    ],
    ]
    var currentSpecTagIndex: [Int] = []
    var categoryAvalible = true
    var businessDomainAvalible = true
    var specTagAvalible = true
    
    var categorySwitcherAvalible = true
    var businessDomainSwitcherAvalible = true
    var specTagSwitcherAvalible = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeDatas()
    }
    
    func makeDatas() {
        let isOn = LensConfigurationManager.isON
        self.categoryAvalible = isOn
        self.businessDomainAvalible = isOn
        self.specTagAvalible = isOn
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Alert Configuration"
    }
 
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: MockLensConfigurationPageCellSwitch.cellID, for: indexPath) as? MockLensConfigurationPageCellSwitch else { return UITableViewCell(frame: .zero)}
            cell.switchCallbackHanler = { avalible in
                self.categoryAvalible = avalible
                self.businessDomainAvalible = avalible
                self.specTagAvalible = avalible
                self.tableView.reloadData()
            }
            cell.setModel(LensConfigurationSectionModel(title: "ON", cellID: "", switchStatus: LensConfigurationManager.isUIGuardON))
            return cell
        case 1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: MockLensConfigurationPageCellMultiSwitch.cellID, for: indexPath) as? MockLensConfigurationPageCellMultiSwitch else { return UITableViewCell(frame: .zero) }
            cell.addBlock { index, avalible in
                
            }
            cell.switchCallbackHanler = { avalible in
                self.categorySwitcherAvalible = avalible
                self.businessDomainAvalible = avalible
                self.specTagAvalible = avalible
                self.tableView.reloadData()
            }
            cell.switcher.isOn = self.categorySwitcherAvalible
            cell.avalible = self.categoryAvalible
            cell.titleLabel.text = "Category"
            cell.setItems(["Net", "Business"])
            return cell
        case 2:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: MockLensConfigurationPageCellMultiSwitch.cellID, for: indexPath) as? MockLensConfigurationPageCellMultiSwitch else { return UITableViewCell(frame: .zero) }
            cell.addBlock { index, avalible in
                if avalible {
                    if !self.currentSpecTagIndex.contains(where: { $0 == index }) {
                        self.currentSpecTagIndex.append(index)
                    }
                } else {
                    if self.currentSpecTagIndex.contains(where: { $0 == index }) {
                        self.currentSpecTagIndex.removeAll { $0 == index
                        }
                    }
                }
                self.tableView.reloadData()
            }
            cell.switchCallbackHanler = { avalible in
                self.businessDomainSwitcherAvalible = avalible
                self.specTagAvalible = avalible
                self.tableView.reloadData()
            }
            cell.switcher.isOn = self.businessDomainSwitcherAvalible
            cell.avalible = self.businessDomainAvalible
            cell.titleLabel.text = "Business Domain"
            cell.setItems(["GW", "SHP", "SRP", "SDP", "Checkout"])
            return cell
        case 3:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: MockLensConfigurationPageCellMultiSwitch.cellID, for: indexPath) as? MockLensConfigurationPageCellMultiSwitch else { return UITableViewCell(frame: .zero) }
            cell.addBlock { index, avalible in

            }
            cell.switchCallbackHanler = { avalible in
                self.specTagSwitcherAvalible = avalible
            }
            cell.switcher.isOn = self.specTagSwitcherAvalible
            cell.titleLabel.text = "Spec Tag"
            if self.currentSpecTagIndex.count == 0 {
                cell.setItems(["","","","",""])
            } else {
                for index in self.currentSpecTagIndex {
                    cell.setItems(self.specTag[index])
                }
            }
            cell.avalible = specTagAvalible
            return cell
        default:
            break
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        return cell
    }

}


class MockLensConfigurationPageCellSwitch: UITableViewCell {
    static let cellID = "MockLensConfigurationPageCellSwitch"
    var switchCallbackHanler: ((_ avalible: Bool)->Void)?
    @IBOutlet weak var switcher: UISwitch!
    
    @IBAction func switchAction(_ sender: Any) {
        switchCallbackHanler?(switcher.isOn)
    }
}

class MockLensConfigurationPageCellMultiSwitch: UITableViewCell {
    static let cellID = "MockLensConfigurationPageCellMultiSwitch"
    @IBOutlet weak var switcher: UISwitch!
    @IBOutlet weak var titleLabel: UILabel!
    
    var switchCallbackHanler: ((_ avalible: Bool)->Void)?
    var _avalible = true
    var avalible: Bool {
        set {
            self.isUserInteractionEnabled = newValue
            self.maskerView.isHidden = newValue
            _avalible = newValue
        }
        get {
            _avalible
        }
    }
    
    @IBOutlet var buttons: [LensSwitchButton]!
    @IBOutlet weak var maskerView: UIView!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    @IBAction func switchAction(_ sender: Any) {
        switchCallbackHanler?(switcher.isOn)
    }
    
    func addBlock(_ block: ((_ index: Int, _ avalible: Bool)->Void)?) {
        
        for button in buttons {
            button.addBlock(block)
        }
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setItems(_ items: [String?]) {
        for (index, button) in buttons.enumerated() {
            if index < items.count,
               let title = items[index] {
                buttons[index].setTitle(title, for: .normal)
            } else {
                buttons[index].setTitle(nil, for: .normal)
            }
        }
    }
}

class LensSwitchButton: UIButton {
    
    var block: BlankHandler?
    var outerBlock: ((_ index: Int, _ avalible: Bool)->Void)?
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.block = {
            self.isSelected = !self.isSelected
        }
        addInnerBlock()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.block = {
            self.isSelected = !self.isSelected
        }
        addInnerBlock()
    }
    
    func addInnerBlock() {
        self.addTarget(self, action: #selector(buttonAction(_:)), for: .touchUpInside)
    }
    
    func addBlock(_ block: ((_ index: Int, _ avalible: Bool)->Void)?) {
        outerBlock = block
    }
    
    @objc
    func buttonAction(_ button: LensSwitchButton) {
        block?()
        outerBlock?(self.tag, button.isSelected)
    }
    
}
