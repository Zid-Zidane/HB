//
//  LensConfigurationManager.swift
//  Alamofire
//
//  Created by hazhu1 on 2023/4/25.
//

import Foundation

class LensConfigurationManager {
    
    static let K = "LensConfigurationManager"
    
    static func saveData(_ datas: [LensConfigurationPageData]) {
        UserDefaults.standard.set(datas, forKey: K)
    }
    
    static func getData() -> [LensConfigurationPageData] {
        guard let result = UserDefaults.standard.object(forKey: K) as? [LensConfigurationPageData] else { return defalutValue() }
        return result
    }
    
    static func defalutValue() -> [LensConfigurationPageData] {
        let value: [LensConfigurationPageData] = [
            [
                [
                    "Alert": [
                        [
                            [
                                "switch": true,
                            ]
                        ],
                        [
                            [
                                "Domain": true,
                            ],
                            [
                                "items": [
                                    "GW": true
                                ]
                            ]
                        ],
                        [
                            [
                                "category": true,
                            ],
                            [
                                "items": [
                                    "Net": true,
                                    "Business": true
                                ]
                            ]
                        ],
                        [
                            [
                                "tag": true,
                            ],
                            [
                                "items": [
                                    "haibo": true,
                                    "tas": true,
                                    "GW Cell": true,
                                    "coupon": true,
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ]
        return value
    }
    
    static func enableClipTolerance() -> CGFloat? {
        return 2
    }
    
    static func enableOverlapTolerance() -> CGFloat? {
        return 2
    }
    
    static var isON: Bool {
        get {
            guard let value = UserDefaults.standard.object(forKey: Const.K_ISON) as? Bool else { return false }
            return value
        }
        set {
            UserDefaults.standard.set(newValue, forKey: Const.K_ISON)
        }
    }
    
    static var isUIGuardON: Bool {
        get {
            /*
            guard let on = UserDefaults.standard.object(forKey: Const.K_ISON) as? Bool,
                  on,
                  let uiguardOn = UserDefaults.standard.object(forKey: Const.K_UIGUARDISON) as? Bool,
                  uiguardOn else { return false }
            return uiguardOn
             */
            guard let on = UserDefaults.standard.object(forKey: Const.K_ISON) as? Bool,
                  on else {
                self.isUIGuardON = true
                return true
            }
            return on
        }
        set {
            UserDefaults.standard.set(newValue, forKey: Const.K_UIGUARDISON)
        }
    }
    
}
