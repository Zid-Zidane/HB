//
//  LensConfigurationModel.swift
//  Hubble
//
//  Created by hazhu1 on 2023/4/25.
//

import Foundation

class LensConfigurationModel {
    
    static let shared = LensConfigurationModel()
    private init() {}
    
    func getData() -> [LensConfigurationPageModel]? {
        let originalData = LensConfigurationManager.getData()
        let data = makeSectionData(originalData)
        return data
    }
    
    func updateData() {
        
    }

    func makeSectionData(_ data: [LensConfigurationPageData]?) -> [LensConfigurationPageModel]? {
        guard let data = data else { return nil }
        var resultData: [LensConfigurationPageModel] = []
        /*
        for item in data where item is [String: [LensSwitchData]] {
            if let valueCount = item.first?.value.count, valueCount > 0 {
                /// Cell Model
                /// 1. Single Switch - item is single
                /// 2. Multi Switch - item is multiple
                /// 3. Text View - item is multiple, support edit
                
                /// 1. make group model
                // TODO: - Page Model Should come from manager, here only control how data display, so cellID is decided here -
                let cellID = valueCount > 1 ? LensConfigurationSwitchCell.cellID : LensConfigurationSwitchCell.cellID
                let sectionModel = LensConfigurationSectionModel(title: item.first?.key, cellID: cellID, switchStatus: false, data: nil)
                for subItem in item.values where subItem is [LensSwitchData] {
                    // 2. make selection model
                    sectionModel.data = subItem
                }
            }
        }
         */
        return resultData
    }
    
}



class LensConfigurationPageModel {
    var title: String? = ""
}

class LensConfigurationSectionModel {
    var title: String? = ""
    var cellID: String = ""
    var switchStatus: Bool = false
    var data: [LensSwitchData]? = []
    init(title: String?, cellID: String, switchStatus: Bool, data: [LensSwitchData]? = nil) {
        self.title = title
        self.cellID = cellID
        self.switchStatus = switchStatus
        self.data = data
    }
    
    func appendData(_ data: LensSwitchData) {
        self.data?.append(data)
    }
}

class LensConfigurationSwitchModel {
    
}
