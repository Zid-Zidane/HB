//
//  LensViewInspectorViewController.h
//  demo
//
//  Created by hazhu1 on 2023/4/17.
//

#import <UIKit/UIKit.h>
@class LensViewInspectorViewController;

typedef NS_ENUM(NSUInteger, LensInspectorMode) {
    LensInspectorModeDefault,
    LensInspectorModeSelect,
};

NS_ASSUME_NONNULL_BEGIN

@protocol LensViewInspectorViewControllerDelegate <NSObject>
- (void)explorerViewControllerDidFinish:(LensViewInspectorViewController *)explorerViewController;
@end

@interface LensViewInspectorViewController : UIViewController

@property (nonatomic, weak) id <LensViewInspectorViewControllerDelegate> delegate;

- (void)updateState:(LensInspectorMode)state;

- (BOOL)shouldReceiveTouchAtWindowPoint:(CGPoint)pointInWindowCoordinates;
- (BOOL)wantsWindowToBecomeKey;

@end

NS_ASSUME_NONNULL_END
