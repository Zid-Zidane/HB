//
//  LensViewInspectorWindow.h
//  demo
//
//  Created by hazhu1 on 2023/4/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol LensViewInspectorWindowEventDelegate <NSObject>

- (BOOL)shouldHandleTouchAtPoint:(CGPoint)pointInWindow;
- (BOOL)canBecomeKeyWindow;

@end

@interface LensViewInspectorWindow : UIWindow

@property (nonatomic, weak) id <LensViewInspectorWindowEventDelegate> eventDelegate;
@property (nonatomic, readonly) UIWindow *previousKeyWindow;

@end

NS_ASSUME_NONNULL_END
