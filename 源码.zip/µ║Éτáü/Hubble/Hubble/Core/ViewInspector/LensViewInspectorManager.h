//
//  LensViewInspectorManager.h
//  demo
//
//  Created by hazhu1 on 2023/4/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LensViewInspectorManager : NSObject

+ (instancetype)sharedManager;

/// Automatic show or hide view inspector
+ (void)switchVisible;

+ (void)showViewInspector;
+ (void)hideViewInspector;

@end

NS_ASSUME_NONNULL_END
