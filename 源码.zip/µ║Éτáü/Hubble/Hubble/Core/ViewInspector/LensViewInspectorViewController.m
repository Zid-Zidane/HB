//
//  LensViewInspectorViewController.m
//  demo
//
//  Created by hazhu1 on 2023/4/17.
//

#import "LensViewInspectorViewController.h"
#import "OCTools.h"
#import "LensViewInspectorWindow.h"
#import <objc/runtime.h>

#if __has_include("Hubble-Swift.h")
#import "Hubble-Swift.h"
#else
#import <Hubble/Hubble-Swift.h>
#endif


static char const * const K_UIGUARDKEY = "K_UIGUARDKEY";

@interface UIView (UIGuard)
- (LensViewGuard *)guard;
@end

@implementation UIView (UIGuard)

- (LensViewGuard *)guard {
    id some = objc_getAssociatedObject(self, K_UIGUARDKEY);
    if ([some isKindOfClass:[LensViewGuard class]]) {
        return some;
    } else {
        LensViewGuard *guard = [LensViewGuard new];
        objc_setAssociatedObject(self, K_UIGUARDKEY, guard, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return guard;
    }
}

@end

@interface LensViewInspectorViewController ()
@property (nonatomic, assign) LensInspectorMode currentMode;
@property (nonatomic) NSDictionary<NSValue *, UIView *> *outlineViewsForVisibleViews;
@property (nonatomic) NSArray<UIView *> *viewsAtTapPoint;
@property (nonatomic) UIView *selectedView;
@property (nonatomic) NSMutableSet<UIView *> *observedViews;
@property (nonatomic) UIView *selectedViewOverlay;
@end

@implementation LensViewInspectorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *selectionTapGR = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                     action:@selector(handleSelectionTap:)];
    [self.view addGestureRecognizer:selectionTapGR];
}

- (void)handleSelectionTap:(UITapGestureRecognizer*)gesture {
    if (self.currentMode == LensInspectorModeSelect &&
        gesture.state == UIGestureRecognizerStateRecognized) {
        CGPoint tapPointInView = [gesture locationInView:self.view];
        CGPoint tapPointInWindow = [self.view convertPoint:tapPointInView toView:nil];
        [self updateOutlineViewsForSelectionPoint:tapPointInWindow];
    }
}

// MARK: - Public -

- (void)updateState:(LensInspectorMode)state {
    self.currentMode = state;
}

- (BOOL)shouldReceiveTouchAtWindowPoint:(CGPoint)pointInWindowCoordinates {
    CGPoint pointInLocalCoordinates = [self.view convertPoint:pointInWindowCoordinates fromView:nil];
    
    // exclude lens
    if (CGRectContainsPoint([EnvModePeep shared].frame, pointInLocalCoordinates)) {
        return NO;
    }
    
    // only state is select should response to this tap
    if (self.currentMode == LensInspectorModeSelect) {
        return YES;
    }
    return NO;
}

- (BOOL)wantsWindowToBecomeKey {
    return self.window.previousKeyWindow != nil;
}

// MARK: - Private Tools -

- (LensViewInspectorWindow *)window {
    return (id)self.view.window;
}

- (void)setSelectedView:(UIView *)targetView {
    UIView *selectedView = targetView;
    if (selectedView.tag == 4505) {
        selectedView = targetView.superview;
    }
    if (![_selectedView isEqual:selectedView]) {
        if (![self.viewsAtTapPoint containsObject:_selectedView]) {
            [self stopObservingView:_selectedView];
        }
        
        NSString *type = @"view";
        NSString *groupName = @"";
        NSString *title = [NSString stringWithFormat:@"%@ · %@", selectedView.class, selectedView.accessibilityLabel];
        NSString *subTitle = @"";
        __block NSString *content = [OCTools descriptionForView:selectedView includingFrame:true accessory:false];
        bool needsAlert = false;
        NSError *error = nil;
        [[LensBaseModelFactory defaultFactory] generateThenUpdateWithType:type groupName:groupName title:title subTitle:subTitle contentText:content snapshot:nil needsAlert:needsAlert error:&error];
        
        LensViewGuard *guard = [selectedView guard];
        if ([selectedView isKindOfClass:[UILabel class]]) {
            UILabel *label = (UILabel *)selectedView;
            [guard guardLabelContentWithLabel:label file:[[NSString stringWithUTF8String:__FILE__] lastPathComponent] funcName:@"" line:0 column:0 needsLayout:false highlight:false resultHandler:^(NSArray<LensViewGuardResult *> * results) {
                NSString __block *reason = @"";
                NSString __block *log = @"";
                [results enumerateObjectsUsingBlock:^(LensViewGuardResult * _Nonnull result, NSUInteger idx, BOOL * _Nonnull stop) {
                    if (result.typeOC != 0) {
                        reason = [NSString stringWithFormat:@"\n<UI Guard Issue>\n%@", [result reasonOC]];
                        content = [content stringByAppendingString:@"\n·············\n"];
                        content = [content stringByAppendingString:reason];
                        content = [content stringByAppendingString:log];
                    }
                }];
                NSError *error = nil;
                [[LensBaseModelFactory defaultFactory] generateThenUpdateWithType:type groupName:groupName title:title subTitle:subTitle contentText:content snapshot:nil needsAlert:needsAlert error:&error];
            }];
        } else if ([selectedView isKindOfClass:[UIView class]]) {
            dispatch_group_t group = dispatch_group_create();
            dispatch_group_enter(group);
            NSString __block *reason = @"";
            NSString __block *log = @"";
            [guard guardClipWithView:selectedView targetView:nil file:[[NSString stringWithUTF8String:__FILE__] lastPathComponent] funcName:@"" line:0 column:0 needsLayout:false highlight:false hideMask:false resultHandler:^(LensViewGuardResult * _Nonnull result) {
                reason = [NSString stringWithFormat:@"\n🚨<UI Guard Issue>\n%@", [result reasonOC]];
                if (result.typeOC != 0) {
                    content = [content stringByAppendingString:@"\n·············\n"];
                    content = [content stringByAppendingString:reason];
                    content = [content stringByAppendingString:log];
                }
                dispatch_group_leave(group);
            }]; 
            dispatch_group_enter(group);
            [guard guardOverlapWithView:selectedView targetView:nil file:[[NSString stringWithUTF8String:__FILE__] lastPathComponent] funcName:@"" line:0 column:0 needsLayout:false highlight:false hideMask:false resultHandler:^(LensViewGuardResult * _Nonnull result) {
                NSString __block *reason = @"";
                NSString __block *log = @"";
                reason = [NSString stringWithFormat:@"\n🚨<UI Guard Issue>\n%@", [result reasonOC]];
                if (result.typeOC != 0) {
                    content = [content stringByAppendingString:@"\n·············\n"];
                    content = [content stringByAppendingString:reason];
                    content = [content stringByAppendingString:log];
                }
                dispatch_group_leave(group);
            }];
            dispatch_group_notify(group, dispatch_get_main_queue(), ^{
                [[LensBaseModelFactory defaultFactory] generateThenUpdateWithType:type groupName:groupName title:title subTitle:subTitle contentText:content snapshot:nil needsAlert:needsAlert error:nil];
            });
        }
        
#ifdef DEBUG
        if (error) {
            NSLog(@"\n⚠️Start\n%@\n⚠️End\n", error);
        }
#endif
        
        _selectedView = selectedView;
        
        [self beginObservingView:selectedView];
        
        if (selectedView) {
            if (!self.selectedViewOverlay) {
                self.selectedViewOverlay = [UIView new];
                [self.view addSubview:self.selectedViewOverlay];
                self.selectedViewOverlay.layer.borderWidth = 1.0;
            }
            UIColor *outlineColor = [OCTools randomColorForObject:selectedView];
            self.selectedViewOverlay.backgroundColor = [outlineColor colorWithAlphaComponent:0.2];
            self.selectedViewOverlay.layer.borderColor = outlineColor.CGColor;
            self.selectedViewOverlay.frame = [self.view convertRect:selectedView.bounds fromView:selectedView];
            
            [self.view bringSubviewToFront:self.selectedViewOverlay];
        } else {
            [self.selectedViewOverlay removeFromSuperview];
            self.selectedViewOverlay = nil;
        }
    }
}

- (void)updateOutlineViewsForSelectionPoint:(CGPoint)selectionPointInWindow {
    // 1. remove old out line view
    [self removeAndClearOutlineViews];
    
    // Include hidden views in the "viewsAtTapPoint" array so we can show them in the hierarchy list.
    self.viewsAtTapPoint = [self viewsAtPoint:selectionPointInWindow skipHiddenViews:NO];
    
    // For outlined views and the selected view, only use visible views.
    // Outlining hidden views adds clutter and makes the selection behavior confusing.
    NSArray<UIView *> *visibleViewsAtTapPoint = [self viewsAtPoint:selectionPointInWindow skipHiddenViews:YES];
    NSMutableDictionary<NSValue *, UIView *> *newOutlineViewsForVisibleViews = [NSMutableDictionary new];
    for (UIView *view in visibleViewsAtTapPoint) {
        UIView *outlineView = [self outlineViewForView:view];
        [self.view addSubview:outlineView];
        NSValue *key = [NSValue valueWithNonretainedObject:view];
        [newOutlineViewsForVisibleViews setObject:outlineView forKey:key];
    }
    self.outlineViewsForVisibleViews = newOutlineViewsForVisibleViews;
    self.selectedView = [self viewForSelectionAtPoint:selectionPointInWindow];
}

- (UIView *)outlineViewForView:(UIView *)view {
    CGRect outlineFrame = [self frameInLocalCoordinatesForView:view];
    UIView *outlineView = [[UIView alloc] initWithFrame:outlineFrame];
    outlineView.backgroundColor = UIColor.clearColor;
    outlineView.layer.borderColor = [OCTools randomColorForObject:view].CGColor;
    outlineView.layer.borderWidth = 1.0;
    return outlineView;
}

- (CGRect)frameInLocalCoordinatesForView:(UIView *)view {
    // Convert to window coordinates since the view may be in a different window than our view
    CGRect frameInWindow = [view convertRect:view.bounds toView:nil];
    // Convert from the window to our view's coordinate space
    return [self.view convertRect:frameInWindow fromView:nil];
}

- (UIView *)viewForSelectionAtPoint:(CGPoint)tapPointInWindow {
    // Select in the window that would handle the touch, but don't just use the result of
    // hitTest:withEvent: so we can still select views with interaction disabled.
    // Default to the the application's key window if none of the windows want the touch.
    UIWindow *windowForSelection = UIApplication.sharedApplication.keyWindow;
    for (UIWindow *window in OCTools.allWindows.reverseObjectEnumerator) {
        if (window != self.view.window && window != [EnvModePeep shared]) {
            if ([window hitTest:tapPointInWindow withEvent:nil]) {
                windowForSelection = window;
                break;
            }
        }
    }
    
    // Select the deepest visible view at the tap point. This generally corresponds to what the user wants to select.
    return [self recursiveSubviewsAtPoint:tapPointInWindow inView:windowForSelection skipHiddenViews:NO].lastObject;
}

- (void)removeAndClearOutlineViews {
    for (NSValue *key in self.outlineViewsForVisibleViews) {
        UIView *outlineView = self.outlineViewsForVisibleViews[key];
        [outlineView removeFromSuperview];
    }
    self.outlineViewsForVisibleViews = nil;
}

- (void)setViewsAtTapPoint:(NSArray<UIView *> *)viewsAtTapPoint {
    if (![_viewsAtTapPoint isEqual:viewsAtTapPoint]) {
        for (UIView *view in _viewsAtTapPoint) {
            if (view != self.selectedView) {
                [self stopObservingView:view];
            }
        }
        
        _viewsAtTapPoint = viewsAtTapPoint;
        
        for (UIView *view in viewsAtTapPoint) {
            [self beginObservingView:view];
        }
    }
}

- (void)stopObservingView:(UIView *)view {
    if (!view) {
        return;
    }
    
    for (NSString *keyPath in self.viewKeyPathsToTrack) {
        [view removeObserver:self forKeyPath:keyPath];
    }
    
    [self.observedViews removeObject:view];
}

- (NSArray<NSString *> *)viewKeyPathsToTrack {
    static NSArray<NSString *> *trackedViewKeyPaths = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *frameKeyPath = NSStringFromSelector(@selector(frame));
        trackedViewKeyPaths = @[frameKeyPath];
    });
    return trackedViewKeyPaths;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
                        change:(NSDictionary<NSString *, id> *)change
                       context:(void *)context {
    [self updateOverlayAndDescriptionForObjectIfNeeded:object];
}

- (void)updateOverlayAndDescriptionForObjectIfNeeded:(id)object {
    NSUInteger indexOfView = [self.viewsAtTapPoint indexOfObject:object];
    if (indexOfView != NSNotFound) {
        UIView *view = self.viewsAtTapPoint[indexOfView];
        NSValue *key = [NSValue valueWithNonretainedObject:view];
        UIView *outline = self.outlineViewsForVisibleViews[key];
        if (outline) {
            outline.frame = [self frameInLocalCoordinatesForView:view];
        }
    }
    if (object == self.selectedView) {
        CGRect selectedViewOutlineFrame = [self frameInLocalCoordinatesForView:self.selectedView];
        self.selectedViewOverlay.frame = selectedViewOutlineFrame;
    }
}

- (void)beginObservingView:(UIView *)view {
    // Bail if we're already observing this view or if there's nothing to observe.
    if (!view || [self.observedViews containsObject:view]) {
        return;
    }
    
    for (NSString *keyPath in self.viewKeyPathsToTrack) {
        [view addObserver:self forKeyPath:keyPath options:0 context:NULL];
    }
    
    [self.observedViews addObject:view];
}

- (NSArray<UIView *> *)viewsAtPoint:(CGPoint)tapPointInWindow skipHiddenViews:(BOOL)skipHidden {
    NSMutableArray<UIView *> *views = [NSMutableArray new];
    for (UIWindow *window in OCTools.allWindows) {
        // Don't include the explorer's own window or subviews or lens window.
        if (window != self.view.window && [window pointInside:tapPointInWindow withEvent:nil] && window != [EnvModePeep shared]) {
            [views addObject:window];
            [views addObjectsFromArray:[self
                recursiveSubviewsAtPoint:tapPointInWindow inView:window skipHiddenViews:skipHidden
            ]];
        }
    }
    return views;
}

- (NSArray<UIView *> *)recursiveSubviewsAtPoint:(CGPoint)pointInView
                                         inView:(UIView *)view
                                skipHiddenViews:(BOOL)skipHidden {
    NSMutableArray<UIView *> *subviewsAtPoint = [NSMutableArray new];
    for (UIView *subview in view.subviews) {
        BOOL isHidden = subview.hidden || subview.alpha < 0.01;
        if (skipHidden && isHidden) {
            continue;
        }
        
        BOOL subviewContainsPoint = CGRectContainsPoint(subview.frame, pointInView);
        if (subviewContainsPoint) {
            [subviewsAtPoint addObject:subview];
        }
        
        // If this view doesn't clip to its bounds, we need to check its subviews even if it
        // doesn't contain the selection point. They may be visible and contain the selection point.
        if (subviewContainsPoint || !subview.clipsToBounds) {
            CGPoint pointInSubview = [view convertPoint:pointInView toView:subview];
            [subviewsAtPoint addObjectsFromArray:[self
                recursiveSubviewsAtPoint:pointInSubview inView:subview skipHiddenViews:skipHidden
            ]];
        }
    }
    return subviewsAtPoint;
}

@end
