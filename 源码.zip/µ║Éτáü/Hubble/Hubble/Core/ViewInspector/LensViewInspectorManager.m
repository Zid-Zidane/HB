//
//  LensViewInspectorManager.m
//  demo
//
//  Created by hazhu1 on 2023/4/17.
//

#import "LensViewInspectorManager.h"
#import "LensViewInspectorViewController.h"
#import "LensViewInspectorWindow.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import "OCTools.h"

@interface LensViewInspectorManager () <LensViewInspectorWindowEventDelegate, LensViewInspectorViewControllerDelegate>

@property (nonatomic, strong) LensViewInspectorWindow *explorerWindow;
@property (nonatomic, strong) LensViewInspectorViewController *explorerViewController;

@end

@implementation LensViewInspectorManager

+ (instancetype)sharedManager {
    static LensViewInspectorManager *sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [self new];
    });
    return sharedManager;
}

+ (void)switchVisible {
    if ([LensViewInspectorManager sharedManager].explorerWindow.hidden) {
        [self showViewInspector];
    } else {
        [self hideViewInspector];
    }
}

+ (void)showViewInspector {
    UIWindow *window = [LensViewInspectorManager sharedManager].explorerWindow;
    window.hidden = NO;
    if (@available(iOS 13.0, *)) {
        if (!window.windowScene) {
            window.windowScene = OCTools.appKeyWindow.windowScene;
        }
    }
    
    [[LensViewInspectorManager sharedManager].explorerViewController updateState:LensInspectorModeSelect];
}

+ (void)hideViewInspector {
    [LensViewInspectorManager sharedManager].explorerWindow.hidden = YES;
    
    [[LensViewInspectorManager sharedManager].explorerViewController updateState:LensInspectorModeDefault];
}

- (LensViewInspectorWindow *)explorerWindow {
#ifdef DEBUG
    NSAssert(NSThread.isMainThread, @"You must use %@ from the main thread only.", NSStringFromClass([self class]));
#endif
    
    if (!_explorerWindow) {
        _explorerWindow = [[LensViewInspectorWindow alloc] initWithFrame:OCTools.appKeyWindow.bounds];
        _explorerWindow.eventDelegate = self;
        _explorerWindow.rootViewController = self.explorerViewController;
    }
    
    return _explorerWindow;
}

- (LensViewInspectorViewController *)explorerViewController {
    if (!_explorerViewController) {
        _explorerViewController = [LensViewInspectorViewController new];
        _explorerViewController.delegate = self;
    }

    return _explorerViewController;
}

#pragma MARK: - LensViewInspectorWindowEventDelegate, LensViewInspectorViewControllerDelegate -
- (BOOL)shouldHandleTouchAtPoint:(CGPoint)pointInWindow {
    return [self.explorerViewController shouldReceiveTouchAtWindowPoint:pointInWindow];
}

- (BOOL)canBecomeKeyWindow {
    return self.explorerViewController.wantsWindowToBecomeKey;
}

- (void)explorerViewControllerDidFinish:(LensViewInspectorViewController *)explorerViewController {
    [LensViewInspectorManager hideViewInspector];
}

@end
