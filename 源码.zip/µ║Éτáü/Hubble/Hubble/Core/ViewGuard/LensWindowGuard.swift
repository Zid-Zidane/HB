//
//  LensWindowGuard.swift
//  Hubble
//
//  Created by hazhu1 on 2023/5/8.
//

import Foundation

public class LensWindowGuard {
    
    struct Const {
        static let interval = 7.0
        static let subviewMaxCount = 20
        static let recursiveMaxCount = 20
        static let branchDeepthMaxCount = 5
        static let subviewDeepthMaxCount = 5
    }
    
    public static let shared = LensWindowGuard()
    private init() {}
    private var _isOn = false
    public var isOn: Bool {
        get {
            _isOn
        }
    }
    var timer: Timer? = nil
    let detectQueue = DispatchQueue(label: "com.tz.LensWindowGuard")
    
    public func start() {
        if !_isOn {
            _isOn = true
            timer = Timer.scheduledTimer(timeInterval: Const.interval, target: self, selector: #selector(detectEntrance), userInfo: nil, repeats: true)
            timer?.fire()
        }
    }
    
    public func stop() {
        _isOn = false
        timer?.invalidate()
        timer = nil
        MaskCache.shared.purgeAll()
    }
    
    @objc func detectEntrance() {
        detectQueue.sync {
            DispatchQueue.main.async {
                self.detect()
            }
        }
    }
    
    /// Current Page Content View Type
    /// TableView
    ///     1. Cell `Overlap` && `Clip`
    ///     2. Subview branch detect
    /// CollecitonView
    ///     1. Cell `Overlap` && `Clip`
    ///     2. Subview branch detect
    /// View
    ///     1. Subview branch detect
    func detect() {
        if let currentPage = HubbleManager.shared.currentViewPageHanler?() {
            if let tab = currentPage.view as? UITableView {
                for cell in tab.visibleCells {
                    (cell as UIView).uiGuard.guardOverlap(view: cell, targetView: nil, needsLayout: false, highlight: true).guardClip(view: cell, targetView: nil, needsLayout: false, highlight: true)
                    singleBranchDetect(deepth: 0, view: cell)
                }
            } else if let col = currentPage.view as? UICollectionView {
                for cell in col.visibleCells {
                    (cell as UIView).uiGuard.guardOverlap(view: cell, targetView: nil, needsLayout: false, highlight: true).guardClip(view: cell, targetView: nil, needsLayout: false, highlight: true)
                    singleBranchDetect(deepth: 0, view: cell)
                }
            } else if let view = currentPage.view {
                singleBranchDetect(deepth: 0, view: view)
            }
        }
    }
    
    /// Every branch can detach new branch, every branch has its own deepth index.
    ///     Forked branch deepth index is different with super branch, start from 0.
    func singleBranchDetect(deepth: Int, view: AnyObject) {
        singleBranchStartPoint(deepth: deepth, view: view)
    }
    
    func singleBranchStartPoint(deepth: Int, view: AnyObject) {
        guard let view = view as? UIView, view.tag != AssociatedKeyLens.tag else { return }
        
        /// When
        ///     `subviews == 0` || `subviews > 1` || `deepth >= Const.recursiveMaxCount
        /// Then self
        ///     `subviews == 0`  NO overlap, detect current view `truncate` / `clip`
        ///     `subviews == 1`  Countinue recursive, cause most of them is just dummy view or desired superView
        ///     `subviews > 1`  Detect for `truncate` / `clip`, overlap is disired so no need guard
        ///         Then subview Sibling `truncate` / `overlap` / `clip`
        guard deepth < Const.recursiveMaxCount else {
            return
        }
        if view.subviews.count == 0 {
            certainViewDetect(view: view)
        } else if view.subviews.count == 1 {
            if view.bounds == view.subviews.first?.bounds {
                if let subView = view.subviews.first {
                    singleBranchStartPoint(deepth: deepth + 1, view: subView)
                }
            } else {
                certainViewDetect(view: view)
                if let subView = view.subviews.first {
                    singleBranchStartPoint(deepth: deepth + 1, view: subView)
                }
            }
        } else if view.subviews.count > 1 {
            // self view
            certainViewDetect(view: view, types: [.truncate, .clip])
            // subview sibling
            siblingviewDetect(superView: view)
        } else {
            
        }
    }
    
    func siblingviewDetect(superView: AnyObject?, maxWidth: Int = Const.recursiveMaxCount, singleLayer: Bool = true) {
        guard superView?.subviews.count ?? 0 > 1, let subViews = superView?.subviews else { return }
        for siblingView in subViews {
            // Fork new branch
            singleBranchDetect(deepth: 0, view: siblingView)
        }
    }
    
    func certainViewDetect(view: AnyObject?, types: [LensUIGuardType]? = nil) {
        guard let view = view else { return }
        
        let guardHandler: (UIView)->Void = { view in
            guard let types = types else {
                // Default check all guard
                if let view = view as? UILabel{
                    view.uiGuard.guardLabelContent(label: view, needsLayout: false, highlight: true)
                } else {
                    view.uiGuard.guardClip(view: view, targetView: nil, needsLayout: false, highlight: true).guardOverlap(view: view, targetView: nil, needsLayout: false, highlight: true)
                }
                return
            }
            for type in types {
                switch type {
                case .clip:
                    view.uiGuard.guardClip(view: view, targetView: nil, highlight: true)
                case .overlap:
                    view.uiGuard.guardOverlap(view: view, targetView: nil, highlight: true)
                case .truncate:
                    if let view = view as? UILabel {
                        view.uiGuard.guardLabelContent(label: view, needsLayout: false, highlight: true)
                    }
                case .labelContent:
                    if let view = view as? UILabel {
                        view.uiGuard.guardLabelContent(label: view, needsLayout: false, highlight: true)
                    }
                case .none:
                    break
                }
            }
        }
        
        if let view = view as? UILabel {
            guardHandler(view)
        } else if let view = view as? UIImageView {
            guardHandler(view)
        } else if let view = view as? UIButton {
            guardHandler(view)
        } else if let view = view as? UIStackView {
            guardHandler(view)
        } else if let view = view as? UIView {
            guardHandler(view)
        }
    }
    
}


extension UIView {
    // MARK: - Private -
    
    enum AssociatedKey {
        static var key: String = "AssociatedKey"
    }
    
    var uiGuard: LensViewGuard {
        get {
            guard let objc = objc_getAssociatedObject(self, &AssociatedKey.key) as? LensViewGuard else {
                let item = LensViewGuard()
                objc_setAssociatedObject(self, &AssociatedKey.key, item, .OBJC_ASSOCIATION_COPY_NONATOMIC)
                return item
            }
            return objc
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKey.key, newValue, .OBJC_ASSOCIATION_COPY_NONATOMIC)
        }
    }
}
