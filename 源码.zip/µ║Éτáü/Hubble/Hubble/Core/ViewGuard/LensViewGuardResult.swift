//
//  LensViewGuardResult.swift
//  Hubble
//
//  Created by hazhu1 on 2023/5/14.
//

import Foundation

@objc
public

class LensViewGuardResult: NSObject {
    
    var view: UIView
    var image: UIImage?
    var pageName: String
    var otherView: UIView?
    var relationShip: String?
    var type: LensUIGuardType
    
    init(view: UIView,
         image: UIImage?,
         pageName: String,
         otherView: UIView?,
         relationShip: String?,
         type: LensUIGuardType) {
        self.type = type
        self.view = view
        self.image = image
        self.pageName = pageName
        self.otherView = otherView
        self.relationShip = relationShip
    }
    
    func reasonString() -> String {
        switch type {
        case .none: break
        case .truncate:
            return "\(pageName)\nUILable truncated"
        case .overlap:
            guard let otherView = otherView else { return "-"}
            let overlapedClassName = String(describing: Swift.type(of: view).self)
            let overlapClassName = String(describing: Swift.type(of: otherView).self)
            return "\(pageName)\n\(overlapedClassName) overlaped by \(overlapClassName)"
        case .clip:
            guard let otherView = otherView else { return "-"}
            let clipedClassName = String(describing: Swift.type(of: view).self)
            let clipClassName = String(describing: Swift.type(of: otherView).self)
            return "\(pageName)\n\(clipedClassName) cliped by \(clipClassName)"
        default:
            break
        }
        return ""
    }
    
    func subTitleString() -> String {
        let viewTypeName = String(describing: Swift.type(of: view).self)
        switch type {
        case .none: break
        case .truncate:
            return "\(pageName) · \(viewTypeName)\nTruncated"
        case .overlap:
            return "\(pageName) · \(viewTypeName)\nOverlap"
        case .clip:
            return "\(pageName) · \(viewTypeName)\nClip"
        default:
            break
        }
        return ""
    }
    
    func LogString() -> String {
        switch type {
        case .none: break
        case .truncate:
            return "\(pageName)\nUILable truncated"
        case .overlap:
            return "Overlap"
        case .clip:
            guard let relationShip = relationShip,
                  let otherView = otherView else { return "-" }
            let origin  = view.frame.origin
            let size    = view.frame.size
            let viewLog = "<b>cliped View Frame:</b>\nx: \(origin.x) y: \(origin.y) width: \(size.width) height: \(size.height)"
            let clipViewOrigin  = otherView.frame.origin
            let clipViewSize    = otherView.frame.size
            let clipViewLog = "<b>clip View Frame:</b>\nx: 0.0 y: 0.0 width: \(clipViewSize.width) height: \(clipViewSize.height)"
            return "<b>Relationship</b>\n\(relationShip)\n" + viewLog + "\n" + clipViewLog
        default:
            break
        }
        return ""
    }
    
    
    
    @objc public
    func typeOC() -> Int {
        return type.rawValue
    }
    
    @objc public
    func reasonOC() -> NSString {
        return reasonString() as NSString
    }
    
    @objc public
    func logOC() -> NSString {
        return "" as NSString
        /*
        var log = ""
        switch type {
        case .none: break
        case .truncate:
            log = "\(pageName)\nUILable truncated"
        case .overlap:
            log = "Overlap"
        case .clip:
            guard let relationShip = relationShip,
                  let otherView = otherView else { return "-" }
            let origin  = view.frame.origin
            let size    = view.frame.size
            let viewLog = "cliped View Frame:x: \(origin.x) y: \(origin.y) width: \(size.width) height: \(size.height)"
            let clipViewOrigin  = otherView.frame.origin
            let clipViewSize    = otherView.frame.size
            let clipViewLog = "clip View Frame:x: \(clipViewOrigin.x) y: \(clipViewOrigin.y) width: \(clipViewSize.width) height: \(clipViewSize.height)"
            log = "Relationship\n\(relationShip)\n" + viewLog + "\n" + clipViewLog
        default:
            break
        }
        return log as NSString
         */
    }
}
