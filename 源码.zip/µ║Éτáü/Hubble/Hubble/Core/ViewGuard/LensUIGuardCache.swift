//
//  LensUIGuardCache.swift
//  Hubble
//
//  Created by hazhu1 on 2023/5/11.
//

import Foundation

class MaskCache {
    static let shared = MaskCache()
    private init(){}
    private var maskCache: NSCache<NSString, UIView> = {
        let cache = NSCache<NSString, UIView>()
        cache.totalCostLimit = 50 * 1024 * 1024
        return cache
    }()
    private var keys: [NSString] = []
    
    func setObject(_ object: UIView) {
        let key = object.description as NSString
        keys.append(key)
        maskCache.setObject(object, forKey: key)
    }
    
    func purge(_ key: String) {
        if let item = maskCache.object(forKey: key as NSString) {
            item.removeFromSuperview()
        }
    }
    
    func purgeAll() {
        for key in keys {
            if let item = maskCache.object(forKey: key) {
                if let superView = item.superview {
                    superView.hideMaskView()
                }
            }
        }
        MaskCache.shared.maskCache.removeAllObjects()
    }
}
