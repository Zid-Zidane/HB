//
//  LensViewGuard.swift
//  Hubble
//
//  Created by hazhu1 on 2023/5/3.
//

import UIKit

enum UILabelHublleError {
    case noText
    case truncated
    case untruncated
    case noAttributedString
}

fileprivate struct Constant {
#if DEBUG
    static let KSubviewCountThreshold = 20
#else
    static let KSubviewCountThreshold = 10
#endif
    static let defaultFont = UIFont.systemFont(ofSize: 17)    // default is nil (system font 17 plain)
}

@objc public class LensViewGuard: NSObject, NSCopying {
    public func copy(with zone: NSZone? = nil) -> Any {
    let copy = LensViewGuard()
        return copy
    }
    
    // MARK: - Public -
    
    public override init() {}
    
    /// Monitor for Truncated & Clip & Overlap
    @objc
    public func guardLabelContent(label: UILabel, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column, needsLayout: Bool = true, highlight: Bool = false, resultHandler: (([LensViewGuardResult])->Void)? = nil)
    {
        var results: [LensViewGuardResult] = []
        let group = DispatchGroup()
        group.enter()
        guardLabelTruncated(label: label, file: file, funcName: funcName, line: line, column: column, needsLayout: needsLayout ?? true, highlight: true, hideMask: false) { result in
            results.append(result)
            group.leave()
        }
        group.enter()
        guardClip(view: label, targetView: nil, file: file, funcName: funcName, line: line, column: column, needsLayout: false, highlight: true, hideMask: false) { result in
            results.append(result)
            group.leave()
        }
        group.enter()
        guardOverlap(view: label, targetView: nil, file: file, funcName: funcName, line: line, column: column, needsLayout: false, highlight: true, hideMask: false) { result in
            results.append(result)
            group.leave()
        }
        group.notify(queue: DispatchQueue.main) {
            resultHandler?(results)
            let filterdResult = results.filter { $0.type != .none }
            if filterdResult.count == 0 {
                label.hideMaskView()
            }
        }
    }
    
    @discardableResult @objc
    public func guardLabelTruncated(label: UILabel, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column, needsLayout: Bool = true, highlight: Bool = false, hideMask: Bool = false, resultHandler: ((_ result: LensViewGuardResult)->Void)? = nil) -> Self {
        DispatchQueue.main.async {[weak self] in
            guard let ss = self else { return }
            if ss.isTruncated(label: label, needsLayout: needsLayout) {
                Tools.getCurrentPageNameHandler { name in
                    let image = Tools.getSnapshot(label)
                    let result = LensViewGuardResult(view: label, image: image, pageName: name, otherView: nil, relationShip: nil, type: .truncate)
                    LensViewGuardLogFactory.shared.generateThenUpdate(reason: result.reasonString(), subTitle: result.subTitleString(), log: result.LogString(), snapshot: image, alert: true, expandable: false, pageName: name, file: file, funcName: funcName, line: line, column: column)
                    resultHandler?(result)
                }
                label.showMaskView(targetView: label, highlight: highlight)
            } else {
                if hideMask {
                    label.hideMaskView()
                }
                let result = LensViewGuardResult(view: label, image: nil, pageName: "", otherView: nil, relationShip: nil, type: .none)
                resultHandler?(result)
            }
        }
        return self
    }
    
    @discardableResult @objc
    public func guardClip(view: UIView, targetView: UIView?, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column, needsLayout: Bool = true, highlight: Bool = false, hideMask: Bool = false, resultHandler: ((LensViewGuardResult)->Void)? = nil) -> Self {
        DispatchQueue.main.async {[weak self] in
            guard let ss = self else { return }
            var clipView: UIView?
            var relationship: String = ""
            if ss.isClip(view: view, targetView: targetView, needsLayout: needsLayout, handler: { _clipView, relationshipstring in
                clipView = _clipView
                relationship = relationshipstring
            }) {
                Tools.getCurrentPageNameHandler { name in
                    guard let clipView = clipView else { return }
                    let image = Tools.getSnapshot(view)
                    let result = LensViewGuardResult(view: view, image: image, pageName: name, otherView: clipView, relationShip: relationship, type: .clip)
                    LensViewGuardLogFactory.shared.generateThenUpdate(reason: result.reasonString(), subTitle: result.subTitleString(), log: result.LogString(), snapshot: image, alert: true, expandable: false, pageName: name, file: file, funcName: funcName, line: line, column: column)
                    resultHandler?(result)
                }
                view.showMaskView(targetView: view, highlight: highlight)
            } else {
                if hideMask {
                    view.hideMaskView()
                }
                let result = LensViewGuardResult(view: view, image: nil, pageName: "", otherView: nil, relationShip: nil, type: .none)
                resultHandler?(result)
            }
        }
        return self
    }
    
    @discardableResult @objc
    public func guardOverlap(view: UIView, targetView: UIView?, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column, needsLayout: Bool = true, highlight: Bool = false, hideMask: Bool = false, resultHandler: ((LensViewGuardResult)->Void)? = nil) -> Self {
        DispatchQueue.main.async { [weak self] in
            guard let ss = self else { return }
            var overlapView: UIView = UIView()
            if ss.isOverlap(originView: view, targetView: targetView, needsLayout: needsLayout, handler: { view in
                overlapView = view
            }) {
                Tools.getCurrentPageNameHandler { name in
                    let image = Tools.getSnapshot(view)
                    let result = LensViewGuardResult(view: view, image: image, pageName: name, otherView: overlapView, relationShip: nil, type: .overlap)
                    LensViewGuardLogFactory.shared.generateThenUpdate(reason: result.reasonString(), subTitle: result.subTitleString(), log: result.LogString(), snapshot: image, alert: true, expandable: false, pageName: name, file: file, funcName: funcName, line: line, column: column)
                    resultHandler?(result)
                }
                view.showMaskView(targetView: view, highlight: highlight)
            } else {
                if hideMask {
                    view.hideMaskView()
                }
                let result = LensViewGuardResult(view: view, image: nil, pageName: "", otherView: nil, relationShip: nil, type: .none)
                resultHandler?(result)
            }
            
        }
        return self
    }
    
    
    
    // MARK: - Private -
    
    private func isTruncated(label: UILabel, needsLayout: Bool = true) -> Bool {
        guard let superView = label.superview, isVisible(label), isVisible(superView) else { return false }
        if needsLayout {
            label.layoutIfNeeded()
        }
        
        guard let labelText = label.text, labelText.count > 0 else {
            return false
        }
        
        let labelTextSize = (labelText as NSString).boundingRect(
            with: CGSize(width: label.frame.size.width, height: .greatestFiniteMagnitude),
            options: .usesLineFragmentOrigin,
            attributes: [.font: label.font ?? Constant.defaultFont],
            context: nil).size
        
        return labelTextSize.height > label.bounds.size.height
    }
    
    private func isClip(view: UIView, targetView: UIView?, needsLayout: Bool, handler: (UIView?, _ relationship: String)->Void) -> Bool {
        guard let superView = view.superview, isVisible(view), isVisible(superView) else { return false }
        if needsLayout {
            view.layoutIfNeeded()
        }
        var _view: UIView?
        var relationship = ""
        if let targetView = targetView,
           isVisible(targetView) {
            // Compare with given view
            _view = targetView
            relationship = "Clip View is Pass parameter, please check business code"
        } else  {
            // Compare with super view
            _view = superView
            relationship = "super view"
        }
        
        guard let targetView = _view else { return false }
        var rectTarget = targetView.frame
        rectTarget.origin.x = 0
        rectTarget.origin.y = 0
        let rectSelf = view.frame
        let unionRect = rectTarget.union(rectSelf)
        if rectTarget.equalTo(unionRect) {
            return false
        }
        handler(_view, relationship)
        return true
    }
    
    /// Detect current view with target view overlap, if interset exist then overlap.
    /// If target view is nil then will detect current view and its `sibling view.
    /// Will not detect its `child view`, cause child view is overlap as desired.
    /// Will not detect `different superview`, cause view hierarchy may deep, it may reduce performance.
    /// - Parameter targetView: designated target view
    /// - Returns: Does current view is overlap
    private func isOverlap(originView: UIView, targetView: UIView?, needsLayout: Bool, handler: (UIView)->Void) -> Bool {
        guard let superView = originView.superview, isVisible(originView), isVisible(superView) else { return false }
        if needsLayout {
            originView.layoutIfNeeded()
        }
        
        var views: [UIView] = []
        if let targetView = targetView,
           isVisible(targetView) {
            views.append(targetView)
        } else {
            /// Lower the cost
            ///     `Debug   20
            ///     `Release 10
            if superView.subviews.count > Constant.KSubviewCountThreshold {
                return false
            } else {
                views = superView.subviews
            }
        }
        
        for view in views {
            if !isVisible(view) {
                continue
            }
            let rectTarget = view.frame
            let rectSelf = originView.frame
            // intersection / 交集
            let intersect = rectTarget.intersection(rectSelf)
            if intersect != CGRectNull,
               intersect.height != 0,
               intersect.width != 0 {
                if let superviewTarget = view.superview,
                   superView == superviewTarget,
                   view != originView {
                    /// Sibling view should detect view hierarchy
                    ///     `Above view` not overlap
                    ///     `Below view` overlap
                    if let indexSelf = superView.subviews.firstIndex(of: originView),
                       let indexTarget = superView.subviews.firstIndex(of: view) {
                        handler(view)
                        return indexSelf < indexTarget
                    }
                } else if let _ = view.superview {
                    /// No super view, view is invisible, so there is no overlap.
                    /// Continue to check.
                }
            }
        }
        return false
    }
    
    private func isVisible(_ view: UIView) -> Bool {
        guard let superview = view.superview,
              superview.isHidden == false,
              view.alpha > 0,
              view.isHidden == false else { return false}
        return true
    }
    
}




public enum AssociatedKeyLens {
    static var key: String = "AssociatedKey_Mask"
    static var tagKey: String = "AssociatedKey_tagKey"
    static var tag: Int = 4505
}

extension UIView {
    
    func showMaskView(targetView: AnyObject, highlight: Bool = false) {
        guard targetView.tag != AssociatedKeyLens.tag, highlight else { return }
        let hasMask = self.hasMask
        guard let targetView = targetView as? UIView,
              let mask = targetView.maskTag else { return }
        if !hasMask {
            objc_setAssociatedObject(self, &AssociatedKeyLens.tagKey, true, .OBJC_ASSOCIATION_ASSIGN)
            targetView.insertSubview(mask, at: 0)
        }
    }
    
    func hideMaskView() {
        let hasMask = self.hasMask
        guard let mask = self.maskTag else { return }
        if hasMask {
            objc_setAssociatedObject(self, &AssociatedKeyLens.tagKey, false, .OBJC_ASSOCIATION_ASSIGN)
            mask.removeFromSuperview()
            self.maskTag = nil
        }
    }
    
    var hasMask: Bool {
        guard let result = objc_getAssociatedObject(self, &AssociatedKeyLens.tagKey) as? Bool else { return false }
        print("result \(result)")
        return result
    }
    
    var maskTag: UIView? {
        get {
            guard let objc = objc_getAssociatedObject(self, &AssociatedKeyLens.key) as? UIView else {
                let item = UIView()
                item.frame = self.bounds
                item.layer.contents = LensResources.lines
                item.layer.borderColor = UIColor.systemBlue.cgColor
                item.layer.borderWidth = 0.5
                item.backgroundColor = UIColor.red.withAlphaComponent(0.5)
                item.isUserInteractionEnabled = false
                item.tag = AssociatedKeyLens.tag
                objc_setAssociatedObject(self, &AssociatedKeyLens.key, item, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                MaskCache.shared.setObject(item)
                return item
            }
            return objc
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeyLens.key, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
}
