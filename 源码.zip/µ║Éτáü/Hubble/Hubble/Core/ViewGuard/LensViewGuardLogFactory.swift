//
//  LensViewGuardLogFactory.swift
//  Hubble
//
//  Created by hazhu1 on 2023/5/5.
//

import Foundation

class LensViewGuardLogFactory: LensBaseModelFactory {
    static let title = "viewGuard"
    public static let shared: LensViewGuardLogFactory = LensViewGuardLogFactory()
    private override init() {
        super.init()
        self.title = LensViewGuardLogFactory.title
    }
}
