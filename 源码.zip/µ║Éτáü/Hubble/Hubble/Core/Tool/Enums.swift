//
//  Enums.swift
//  demo
//
//  Created by hazhu1 on 2023/4/3.
//

import UIKit

public struct LensPageStruct: Hashable {
    var type = ""
    init(_ type: String) {
        self.type = type
    }
}

public enum LensDetailPageContentType {
    case none
    case text(_ text: String?, _ containerHeight: CGFloat? = nil)     // content with height
    case image(_ image: UIImage?)
    func height() -> CGFloat {
        switch self {
        case .none:
            return 0.0
        case .text(let content, let value):
            return value ?? Tools.getCellHeight(content, width: Tools.screenWidth().orZero - 4).orZero
        case .image(let image):
            return (image?.size.height).orZero
        }
    }
    func needsDisplayWK() -> Bool {
        guard case .text(_, let height) = self else { return false }
        return height ?? 0 > 900.0
    }
}

/// Cell Id
enum Const {
    static let LensCarouselId = "LensCarouselId"
    static let LensCarouselCellId = "LensCarouselCellId"
    static let LensInformationCellId = "LensInformationCellId"
}

// cell action
public enum LensCellActionType {
    case plate
    case expandable(_ allow: Bool)
    case detailable(_ allow: Bool)
}

public enum LensCellAccessoryInfo {
    case none
    case accessory((UIImage?, UIColor?), (String?, UIColor?))
}

public enum LensUIGuardType: Int {
    case none
    case clip
    case overlap
    case truncate
    case labelContent
}

enum LensConst: CGFloat {
    case toolViewHeight = 25.0
    case sectionHeaderHeight = 24.0
    case sectionFooterHeight = 0.0
    case sectionHeaderFooterEmptyHeight = 2.0
}

public enum LensToolItemType {
    case locate
    case close
    case debug
    case fold
    case now
}

enum LensShareType {
    case log
    case image
}

enum LensFeedListActionHanderName: String {
    case reloadHandler = "reloadHandler"
    case refreshMITMHandler = "refreshMITMHandler"
    case scrollToBottomHandler = "scrollToBottomHandler"
}

enum LensNetworkTransactionState: Int {
    case lensNetworkTransactionStateUnknown = -1 // default state currently no scenario to use, because MITM start from resume
    case lensNetworkTransactionStateAwaitingResponse = 0
    case lensNetworkTransactionStateReceivingData
    case lensNetworkTransactionStateFinished
    case lensNetworkTransactionStateFailed
}

public enum LensFactorError: Error {
    case errorType
    case confilctType
    case generateFatel
    case errorpageModel
    case needsRegistPageModel
    case needsReigstSubFactory
}

enum LensResources {
    static let lines = image("line.3.horizontal")
    
    // bar
    static let locateIcon = image("scope")
    static let dragIcon = image("hand.draw")
    static let debugIcon = image("info.circle")
    static let foldIcon = image("minus.circle")
    static let closeIcon = image("xmark.circle")
    static let nowUnselectedIcon = image("clock.arrow.2.circlepath")
    static let nowIcon = image("platter.filled.bottom.and.arrow.down.iphone")
    static let shareIcon = image("square.and.arrow.up.circle")
    
    // cell
    static let cellDetailPlateIcon = image("nosign")
    static let cellCircleIcon = image("circle.fill")
    static let cellDetailFoldIcon = image("arrow.down.circle.fill")
    static let cellDetailExpandIcon = image("arrow.up.circle.fill")
    static let cellDetailDetailableIcon = image("arrow.right.circle")
    
    // network transaction
    static let jsIcon = image("function")
    static let htmlIcon = image("safari")
    static let textIcon = image("text.quote")
    static let textPlainIcon = image("doc.text")
    static let videoIcon = image("video.circle")
    static let xmlIcon = image("lessthan.circle")
    static let audioIcon = image("headphones.circle")
    static let plistIcon = image("list.bullet.rectangle")
    static let binaryIcon = image("square.grid.3x3.middleleft.filled")
    static let jsonIcon = image("chevron.left.forwardslash.chevron.right")
    
    static func image(_ name: String) -> UIImage? {
        if #available(iOS 13, *) {
            return UIImage(systemName: name)
        } else {
            return UIImage(named: name, in: Bundle(for: LensManager.self), compatibleWith: nil)
        }
    }
    
}
 
public typealias FromViewControllerHandler = (UIViewController) -> Void
public typealias PageModelHandler = (LensPageModelProtocol) -> Void
public typealias BlankHandler = () -> Void
public typealias StringHandler = (String) -> Void

typealias LensConfigurationPageData = [[String: [LensConfigurationSectionData]]]
typealias LensConfigurationSectionData = LensConfigurationData
typealias MITMModelHandler = (MITMTransaction) -> Void
typealias LensConfigurationData = [[String: Any]] // [string: bool] or [string: bool, [string: bool, string: bool,]]
typealias LensSwitchData = [String: Bool]

extension Notification.Name {
    static let kLensNetworkRecorderNewTransactionNotification = Notification.Name(rawValue: "kLensNetworkRecorderNewTransactionNotification")
    static let kLensNetworkRecorderUpdatedNotification = Notification.Name(rawValue: "kLensNetworkRecorderUpdatedNotification")
    static let kLensAlertNotification = Notification.Name(rawValue: "kLensAlertNotification")
    static let kLensGetCurentPageNameNotification = Notification.Name(rawValue: "kLensGetCurentPageNameNotification")
    static let kLensPostCurentPageNameNotification = Notification.Name(rawValue: "kLensPostCurentPageNameNotification")
}

extension String {
    static let kLensNetworkRecorderUserInfoTransactionKey = "kLensNetworkRecorderUserInfoTransactionKey"
    static let kLensPageNameKey = "kLensPageNameKey"
}
