//
//  Tools.swift
//  demo
//
//  Created by hazhu1 on 2023/4/10.
//

import UIKit

class Tools {
    static let shared = Tools()
    private init() {
        NotificationCenter.default.addObserver(self, selector: #selector(getPageName(noti:)), name: NSNotification.Name.kLensGetCurentPageNameNotification, object: nil)
    }
    private var getPageNameHandler: StringHandler?
    // MARK: - Meta Info -
    static func getFormattedMapString(_ map: [String: Any]) -> String {
        return map.compactMap {
            return "\($0)      \($1)"
        }.reduce("") { result, value in
            return result + "\n" + value
        }
    }
    static func getBasicAppInfo() -> [String: String] {
        return [
            "Version": getAPPVersion(),
            "Name": getAPPName(),
        ]
    }
    static func getBasicDeviceInfo() -> [String: Any] {
        var map: [String: Any] = [
            "LateralResolution": getLateralResolution(),
            "VerticalResolution": getVerticalResolution(),
            "DeviceName": getDeviceName(),
            "SystemName": getDeviceSystemName(),
            "SystemVersion": getDeviceSystemVersion(),
            "DeviceModel": getDeviceModel(),
            "isSimulator": isSimulator()
        ]
        if !isSimulator() {
            map["JailBroke"] = getJailBroken()
        }
        return map
    }
    static func getBasicDeviceInfoString() -> String {
        var string = "Resolution: \(getLateralResolution()) * \(getVerticalResolution())\nDeviceName: \(getDeviceName())\nSystemName: \(getDeviceSystemName())\nSystemVersion: \(getDeviceSystemVersion())\nDeviceModel: \(getDeviceModel())\nisSimulator: \(isSimulator())"
        if !isSimulator() {
            string += "\nJailBroke: \(getJailBroken())"
        }
        return string
    }
    static func getBasicAppInfoString() -> String {
        return "Version: \(getAPPVersion())\nName: \(getAPPName())"
    }
    // https://stackoverflow.com/a/65474393
    static func thumbnailedImage(maxPixelDimension: Int64, fromImageData: NSData?) -> UIImage? {
        guard let fromImageData = fromImageData else { return nil }
        let thumbnail: UIImage
        let options = [
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 100
        ] as CFDictionary
        
        guard let imageSource = CGImageSourceCreateWithData(fromImageData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options) else { return nil }
        
        thumbnail = UIImage(cgImage: image)
        return thumbnail
    }
    // MARK:  - Tools -
    static func convertCookiesToString(_ cookies: [HTTPCookie], leading: String = "") -> String {
        let leadingString = leading.count == 0 ? "" : leading + " "
        var cookieString: String = ""
        for cookie in cookies {
            cookieString += leadingString + cookie.name + " · " + cookie.value + "\n"
        }
        return cookieString
    }
    static func convertMapToFormatString(_ map: [String : String]?, leading: String = "") -> String? {
        guard let map = map else { return nil }
        let leadingString = leading.count == 0 ? "" : leading + " "
        var string = ""
        for item in map {
            string += leadingString + item.key + " · " + item.value + "\n"
        }
        return string
    }
    static func decodeBase64(_ data: Data) -> String? {
        if let data = Data(base64Encoded: data) {
            return String(data: data, encoding: .utf8)
        }
        return nil
    }
    static func isValidJSONData(_ data: Data) -> Bool {
        var result = false
        do {
            _ = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
            result = true
        } catch {}
        
        return result
    }
    static func getPrettyJSONString(_ data: Data) -> String? {
        var prettyString: String? = nil
        
        do {
            let jsonObjC = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
            if JSONSerialization.isValidJSONObject(jsonObjC) {
                let prettyStringData = try JSONSerialization.data(withJSONObject: jsonObjC, options: .prettyPrinted)
                prettyString = String(data: prettyStringData, encoding: .utf8)
            } else {
                prettyString = String(data: data, encoding: .utf8)
            }
        } catch {}
        
        return prettyString
    }
    static func getPlistString(_ data: Data) -> String? {
        var plistString = ""
        do {
            if let plist = try PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil) as? [[String: String]] {
                let string = plist.reduce("") { partialResult, map in
                    if let result = Tools.convertMapToFormatString(map, leading: "*") {
                        return partialResult + result + "\n"
                    } else {
                        return partialResult
                    }
                }
                plistString = string
            } else if let plist = try PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil) as? [String] {
                let string = plist.reduce("") { partialResult, value in
                        return partialResult + value + "\n"
                }
                plistString = string
            } else if let map = try PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil) as? [String: String] {
                if let result = Tools.convertMapToFormatString(map, leading: "*") {
                    return result + "\n"
                }
            }
        } catch {}
        
        return plistString
    }
    static func interceptionDecimal(float: Float?, base: Int) -> String? {
        guard let float = float else { return nil }
        let format = NumberFormatter.init()
        format.numberStyle = .decimal
        format.minimumFractionDigits = 0
        format.maximumFractionDigits = base
        format.formatterBehavior = .default
        format.roundingMode = .down
        format.groupingSeparator = ""
        return format.string(from: NSNumber(value: float)) ?? ""
    }
    static func getCellHeight(_ text: String?, width: CGFloat) -> CGFloat? {
        guard let text = text else { return nil }
        
        let sizeLimit = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingRect = text.boundingRect(with: sizeLimit, options: .usesLineFragmentOrigin, context: nil)
        return ceil(boundingRect.height)
    }
    static func screenWidth() -> CGFloat? {
        return currentWindow()?.bounds.width
    }
    static func screenHeight() -> CGFloat? {
        return currentWindow()?.bounds.height
    }
    static func currentWindow() -> UIWindow? {
        UIApplication.shared.windows.first {
            return $0 is EnvModePeep
        }
    }
    static func getCurrentPageNameNotification(handler:@escaping (String)->Void) {
        Tools.shared.getPageNameHandler = handler
        NotificationCenter.default.post(name: NSNotification.Name.kLensPostCurentPageNameNotification, object: nil)
    }
    static func getCurrentPageNameHandler(handler:@escaping (String)->Void) {
        let name: String = HubbleManager.shared.viewPageNameHanler?() ?? ""
        handler(name)
    }
    @objc func getPageName(noti: Notification) {
        if let info = noti.userInfo {
            if let name = info[String.kLensPageNameKey] as? String {
                getPageNameHandler?(name)
            }
        }
    }
    /// https://stackoverflow.com/a/25607542
    /// TC Input: The Weeknd <em>&#8216;King Of The Fall&#8217;</em>
    /// TC Output: The Weeknd ‘King Of The Fall’
    static func stringByEscapingHTMLEntitiesInString(_ string: String?) -> String {
        guard let string = string,
            let data = Tools.htmlEncodedString(string)?.data(using: .utf8) else {
            return ""
        }

        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]

        guard let attributedString = try? NSAttributedString(data: data, options: options, documentAttributes: nil) else {
            return ""
        }

        // The Weeknd ‘King Of The Fall’
        let decodedString = attributedString.string
        return decodedString
    }
    static func stringByRemoveHTMLElement(_ htmlString: String, _ elements: [String]? = nil) -> String {
        var htmlString = htmlString
        if let elements = elements, elements.count > 0 {
            for element in elements {
                htmlString = htmlString.replacingOccurrences(of: element, with: "")
            }
        } else {
            htmlString = htmlString.replacingOccurrences(of: "<b>", with: "")
            htmlString = htmlString.replacingOccurrences(of: "</b>", with: "")
        }
        return htmlString
    }
     /*
    static func stringByEscapingHTMLEntitiesInString(_ string: String?) -> String {
        guard let string = string else { return "" }
        
        var result = ""
        let escapingDictionary: [String: String] = [
            " ": "&nbsp;",
            ">": "&gt;",
            "<": "&lt;",
            "&": "&amp;",
            "'": "&apos;",
            "\"": "&quot;",
            "«": "&laquo;",
            "»": "&raquo;"
        ]
        do {
            let regex: NSRegularExpression = try NSRegularExpression(pattern: "(&|>|<|'|\"|«|»)")
            
            var resultString = string
            let matches: [NSTextCheckingResult] = regex.matches(in: resultString, range: NSRange(location: 0, length: resultString.count))
            
            for (_, result) in matches.reversed().enumerated() {
                guard let range: Range = Range(result.range) as? Range<String.Index> else { return ""}
                let catchString = resultString.substring(with: range)
                let replacementString = escapingDictionary[catchString]
                if replacementString != nil {
                    resultString.replacechara
                }
            }
        } catch {}
        return result
    }
    */
    /// https://stackoverflow.com/a/25607542
    /// TC: let encodedString = "The Weeknd <em>&#8216;King Of The Fall&#8217;</em>"
    /// TC: let decodedString = String(htmlEncodedString: encodedString)
    static func htmlEncodedString(_ string: String) -> String? {
        guard let data = string.data(using: .utf8) else {
            return nil
        }
        
        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]
        
        guard let attributedString = try? NSAttributedString(data: data, options: options, documentAttributes: nil) else {
            return nil
        }
        
        return attributedString.string
    }
    static func splitString(_ target: String, component: String) -> String {
        let array = target.components(separatedBy: component)
        let result = array.reduce("") { partialResult, string in
            partialResult + string + "\n"
        }
        return result
    }
    
}

extension Tools {
    static func getAPPInfo() -> [String: Any] {
        return Bundle.main.infoDictionary ?? [:]
    }
    static func getAPPVersion() -> String {
        return (getAPPInfo()["CFBundleShortVersionString"] as? String) ?? ""
    }
    static func getAPPName() -> String {
        return (getAPPInfo()["CFBundleName"] as? String) ?? (getAPPInfo()["CFBundleDisplayName"] as? String) ?? ""
    }
    static func getDeviceName() -> String {
        return UIDevice.current.name
    }
    static func getDeviceSystemName() -> String {
        return UIDevice.current.systemName
    }
    static func getDeviceSystemVersion() -> String {
        return UIDevice.current.systemVersion
    }
    /*
    static func getDeviceModel() -> String {
        return UIDevice.current.model
    }
     */
    static func getLateralResolution() -> String {
        return String(Int(UIScreen.main.bounds.size.width * UIScreen.main.scale))
    }
    static func getVerticalResolution() -> String {
        return String(Int(UIScreen.main.bounds.size.height * UIScreen.main.scale))
    }
    static func isSimulator() -> Bool {
#if targetEnvironment(simulator)
        return true
#else
        return false
#endif
    }
    static func getJailBroken() -> Bool {
        return jailbreakFileExists()
        || sandboxBreached()
        || evidenceOfSymbolLinking()
    }
    static func evidenceOfSymbolLinking() -> Bool {
        var s = stat()
        guard lstat("/Applications", &s) == 0 else { return false }
        return (s.st_mode & S_IFLNK == S_IFLNK)
    }
    static func sandboxBreached() -> Bool {
        guard (try? " ".write(
            toFile: "/private/jailbreak.txt",
            atomically: true, encoding: .utf8)) == nil else {
            return true
        }
        return false
    }
    static func jailbreakFileExists() -> Bool {
        let jailbreakFilePaths = [
            "/Applications/Cydia.app",
            "/Library/MobileSubstrate/MobileSubstrate.dylib",
            "/bin/bash",
            "/usr/sbin/sshd",
            "/etc/apt",
            "/private/var/lib/apt/"
        ]
        let fileManager = FileManager.default
        return jailbreakFilePaths.contains { path in
            if fileManager.fileExists(atPath: path) {
                return true
            }
            if let file = fopen(path, "r") {
                fclose(file)
                return true
            }
            return false
        }
    }
    static func getSnapshot(_ view: UIView) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(view.size, false, UIScreen.main.scale)
        let emptyImage = LensResources.closeIcon ?? UIImage()
        guard let currentContext = UIGraphicsGetCurrentContext() else { return emptyImage }
        view.layer.render(in: currentContext)
        let image = UIGraphicsGetImageFromCurrentImageContext() ?? emptyImage
        UIGraphicsEndImageContext()
        return image
    }
    static func getSnapshot(_ view: UIView, complete: @escaping (UIImage)->Void) {
        DispatchQueue.main.async {
            UIGraphicsBeginImageContextWithOptions(view.size, false, UIScreen.main.scale)
            let emptyImage = LensResources.closeIcon ?? UIImage()
            guard let currentContext = UIGraphicsGetCurrentContext() else { complete(emptyImage)
                return }
            view.layer.render(in: currentContext)
            let image = UIGraphicsGetImageFromCurrentImageContext() ?? emptyImage
            UIGraphicsEndImageContext()
            complete(image)
        }
    }
    static func getDeviceModel() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        func mapToDevice(identifier: String) -> String { // swiftlint:disable:this cyclomatic_complexity
#if os(iOS)
            switch identifier {
            case "iPod5,1":                                       return "iPod touch (5th generation)"
            case "iPod7,1":                                       return "iPod touch (6th generation)"
            case "iPod9,1":                                       return "iPod touch (7th generation)"
            case "iPhone3,1", "iPhone3,2", "iPhone3,3":           return "iPhone 4"
            case "iPhone4,1":                                     return "iPhone 4s"
            case "iPhone5,1", "iPhone5,2":                        return "iPhone 5"
            case "iPhone5,3", "iPhone5,4":                        return "iPhone 5c"
            case "iPhone6,1", "iPhone6,2":                        return "iPhone 5s"
            case "iPhone7,2":                                     return "iPhone 6"
            case "iPhone7,1":                                     return "iPhone 6 Plus"
            case "iPhone8,1":                                     return "iPhone 6s"
            case "iPhone8,2":                                     return "iPhone 6s Plus"
            case "iPhone9,1", "iPhone9,3":                        return "iPhone 7"
            case "iPhone9,2", "iPhone9,4":                        return "iPhone 7 Plus"
            case "iPhone10,1", "iPhone10,4":                      return "iPhone 8"
            case "iPhone10,2", "iPhone10,5":                      return "iPhone 8 Plus"
            case "iPhone10,3", "iPhone10,6":                      return "iPhone X"
            case "iPhone11,2":                                    return "iPhone XS"
            case "iPhone11,4", "iPhone11,6":                      return "iPhone XS Max"
            case "iPhone11,8":                                    return "iPhone XR"
            case "iPhone12,1":                                    return "iPhone 11"
            case "iPhone12,3":                                    return "iPhone 11 Pro"
            case "iPhone12,5":                                    return "iPhone 11 Pro Max"
            case "iPhone13,1":                                    return "iPhone 12 mini"
            case "iPhone13,2":                                    return "iPhone 12"
            case "iPhone13,3":                                    return "iPhone 12 Pro"
            case "iPhone13,4":                                    return "iPhone 12 Pro Max"
            case "iPhone14,4":                                    return "iPhone 13 mini"
            case "iPhone14,5":                                    return "iPhone 13"
            case "iPhone14,2":                                    return "iPhone 13 Pro"
            case "iPhone14,3":                                    return "iPhone 13 Pro Max"
            case "iPhone14,7":                                    return "iPhone 14"
            case "iPhone14,8":                                    return "iPhone 14 Plus"
            case "iPhone15,2":                                    return "iPhone 14 Pro"
            case "iPhone15,3":                                    return "iPhone 14 Pro Max"
            case "iPhone8,4":                                     return "iPhone SE"
            case "iPhone12,8":                                    return "iPhone SE (2nd generation)"
            case "iPhone14,6":                                    return "iPhone SE (3rd generation)"
            case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":      return "iPad 2"
            case "iPad3,1", "iPad3,2", "iPad3,3":                 return "iPad (3rd generation)"
            case "iPad3,4", "iPad3,5", "iPad3,6":                 return "iPad (4th generation)"
            case "iPad6,11", "iPad6,12":                          return "iPad (5th generation)"
            case "iPad7,5", "iPad7,6":                            return "iPad (6th generation)"
            case "iPad7,11", "iPad7,12":                          return "iPad (7th generation)"
            case "iPad11,6", "iPad11,7":                          return "iPad (8th generation)"
            case "iPad12,1", "iPad12,2":                          return "iPad (9th generation)"
            case "iPad13,18", "iPad13,19":                        return "iPad (10th generation)"
            case "iPad4,1", "iPad4,2", "iPad4,3":                 return "iPad Air"
            case "iPad5,3", "iPad5,4":                            return "iPad Air 2"
            case "iPad11,3", "iPad11,4":                          return "iPad Air (3rd generation)"
            case "iPad13,1", "iPad13,2":                          return "iPad Air (4th generation)"
            case "iPad13,16", "iPad13,17":                        return "iPad Air (5th generation)"
            case "iPad2,5", "iPad2,6", "iPad2,7":                 return "iPad mini"
            case "iPad4,4", "iPad4,5", "iPad4,6":                 return "iPad mini 2"
            case "iPad4,7", "iPad4,8", "iPad4,9":                 return "iPad mini 3"
            case "iPad5,1", "iPad5,2":                            return "iPad mini 4"
            case "iPad11,1", "iPad11,2":                          return "iPad mini (5th generation)"
            case "iPad14,1", "iPad14,2":                          return "iPad mini (6th generation)"
            case "iPad6,3", "iPad6,4":                            return "iPad Pro (9.7-inch)"
            case "iPad7,3", "iPad7,4":                            return "iPad Pro (10.5-inch)"
            case "iPad8,1", "iPad8,2", "iPad8,3", "iPad8,4":      return "iPad Pro (11-inch) (1st generation)"
            case "iPad8,9", "iPad8,10":                           return "iPad Pro (11-inch) (2nd generation)"
            case "iPad13,4", "iPad13,5", "iPad13,6", "iPad13,7":  return "iPad Pro (11-inch) (3rd generation)"
            case "iPad14,3", "iPad14,4":                          return "iPad Pro (11-inch) (4th generation)"
            case "iPad6,7", "iPad6,8":                            return "iPad Pro (12.9-inch) (1st generation)"
            case "iPad7,1", "iPad7,2":                            return "iPad Pro (12.9-inch) (2nd generation)"
            case "iPad8,5", "iPad8,6", "iPad8,7", "iPad8,8":      return "iPad Pro (12.9-inch) (3rd generation)"
            case "iPad8,11", "iPad8,12":                          return "iPad Pro (12.9-inch) (4th generation)"
            case "iPad13,8", "iPad13,9", "iPad13,10", "iPad13,11":return "iPad Pro (12.9-inch) (5th generation)"
            case "iPad14,5", "iPad14,6":                          return "iPad Pro (12.9-inch) (6th generation)"
            case "AppleTV5,3":                                    return "Apple TV"
            case "AppleTV6,2":                                    return "Apple TV 4K"
            case "AudioAccessory1,1":                             return "HomePod"
            case "AudioAccessory5,1":                             return "HomePod mini"
            case "i386", "x86_64", "arm64":                       return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "iOS"))"
            default:                                              return identifier
            }
#elseif os(tvOS)
            switch identifier {
            case "AppleTV5,3": return "Apple TV 4"
            case "AppleTV6,2": return "Apple TV 4K"
            case "i386", "x86_64": return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "tvOS"))"
            default: return identifier
            }
#endif
        }
        
        return mapToDevice(identifier: identifier)
        
    }
}
