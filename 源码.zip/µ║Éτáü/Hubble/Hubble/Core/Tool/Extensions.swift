import Foundation

extension DispatchQueue {
    private static var _onceTracker = [String]()
    /**
     Executes a block of code, associated with a unique token, only once.  The code is thread safe and will
     only execute the code once even in the presence of multithreaded calls.
     - parameter token: A unique reverse DNS style name such as com.vectorform.<name> or a GUID
     - parameter block: Block to execute once
     */
    public class func _once(token: String, block: ()->Void) {
        objc_sync_enter(self);
        defer { objc_sync_exit(self) }
        if _onceTracker.contains(token) {
            return
        }
        _onceTracker.append(token)
        block()
    }
}


extension Bundle {
    var isAppExtension: Bool {
        return bundlePath.hasSuffix(".appex")
    }
}

extension NSDate {
    var lensFormattedString: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM HH:mm:ss"
        let dateStr = dateFormatter.string(from: self as Date)
        return dateStr
    }
}

extension Optional where Wrapped == String {
    var lensOrEmpty: String {
        or("")
    }
    
    func or(_ value: String) -> String {
        if let unwrappedValue = self {
            return unwrappedValue
        } else {
            return value
        }
    }
}
