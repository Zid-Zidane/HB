//
//  OCTools.h
//  demo
//
//  Created by hazhu1 on 2023/4/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OCTools : NSObject

+ (UIColor *)randomColorForObject:(id)object;

+ (UIWindow *)appKeyWindow;
+ (NSArray<UIWindow *> *)allWindows;

+ (NSString *)descriptionForView:(UIView *)view includingFrame:(BOOL)includeFrame accessory:(BOOL)accessory;

+ (void)setNetworkObserverEnabled:(BOOL)value;
+ (BOOL)getNetworkObserverEnabled;

+ (UIViewController *)viewControllerForView:(UIView *)view;

+ (UIImage *)thumbnailedImageWithMaxPixelDimension:(NSInteger)dimension fromImageData:(NSData *)data;

+ (SEL)swizzledSelectorForSelector:(SEL)selector;
+ (BOOL)instanceRespondsButDoesNotImplementSelector:(SEL)selector class:(Class)cls;
+ (void)replaceImplementationOfKnownSelector:(SEL)originalSelector onClass:(Class)cls withBlock:(id)block swizzledSelector:(SEL)swizzledSelector;
+ (void)replaceImplementationOfSelector:(SEL)selector withSelector:(SEL)swizzledSelector forClass:(Class)cls withMethodDescription:(struct objc_method_description)methodDescription implementationBlock:(id)implementationBlock undefinedBlock:(id)undefinedBlock;

NSArray<Class> *LensGetAllSubclasses(Class cls, BOOL includeSelf);

@end

NS_ASSUME_NONNULL_END
