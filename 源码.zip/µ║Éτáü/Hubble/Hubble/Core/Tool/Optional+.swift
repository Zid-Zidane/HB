//
//  Optional+.swift
//  EatsFoundation
//
//  Created by ohr478 on 04/06/2020.
//  Copyright © 2020. All rights reserved.
//

import UIKit

extension Collection {
    var isNotEmpty: Bool { return !isEmpty }
}

extension Optional where Wrapped: Collection {
    var isNotEmpty: Bool {
        guard let self = self else { return false }
        return self.isEmpty == false
    }
}

extension Optional {
    func or(_ defaultValue: Wrapped) -> Wrapped {
        if let unwrappedValue = self {
            return unwrappedValue
        }
        return defaultValue
    }
    
    func or(_ defaultValue: Wrapped?) -> Wrapped? {
        if let unwrappedValue = self {
            return unwrappedValue
        }
        return defaultValue
    }
}

extension Optional where Wrapped: SignedNumeric {
    var orZero: Wrapped {
        or(0)
    }
}

extension Optional where Wrapped == Bool {
    var orFalse: Bool {
        or(false)
    }
    var orTrue: Bool {
        or(true)
    }
}

extension Optional where Wrapped == String {
    var orEmpty: String {
        or("")
    }
}
