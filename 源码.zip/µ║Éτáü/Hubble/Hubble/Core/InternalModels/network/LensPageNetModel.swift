//
//  LensPageNetModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/7.
//

import Foundation

class LensPageNetModel: LensBasePageMITMModel {
    
    static let shared = LensPageNetModel()
    private init() {
        super.init(type: LensPageStruct("net"), title: "Net", selected: false, toolItems: [.close, .debug, .fold, .now])
        registNotifications()
    }
    
    let consumptionQueue = DispatchQueue.main // for reload UI
    var httpDataSource = LensMITMDataSource<LensHTTPTransaction> {
        LensNetworkRecorder.defaultRecord.orderedHttpTransactions
    }
    // WS ...
    
    func registNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleNewTransactionRecordedNotification(_:)), name: .kLensNetworkRecorderNewTransactionNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleUpdateTransactionRecordedNotification(_:)), name: .kLensNetworkRecorderUpdatedNotification, object: nil)
    }
    
    @objc func handleNewTransactionRecordedNotification(_ notificate: Notification) {
        let currentRowCount = self.httpDataSource.allTransactions.count
        httpDataSource.reloadData(consumptionQueue) {
            let newRowCount = self.httpDataSource.allTransactions.count
            let diff = newRowCount - currentRowCount
            guard diff > 0 else { return }
            _ = self.httpDataSource.allTransactions[max(0, (currentRowCount))..<currentRowCount + diff].compactMap { MITMTransaction in
                LensBaseModelMITM(transaction: MITMTransaction, titles: [], time: MITMTransaction.startTime, titleText: MITMTransaction.mainMessage(), subtitleText: MITMTransaction.subMessage(), contentText: MITMTransaction.contentMessage(), isExpanded: false, cellIdentity: "", accessoryInfo: .none, needsAlert: MITMTransaction.state == .lensNetworkTransactionStateFailed, actionType: .detailable(true)) { fromVC in
                        var vc = LensDetailListPageViewController()
                        vc = vc.refreshPageModel(MITMTransaction.detailProtocol().compactMap({ return $0 }))
                        fromVC.navigationController?.pushViewController(vc, animated: true)
                }
            }.compactMap {
                LensPageNetModel.shared.append($0)
            }
        }
    }
    
    @objc func handleUpdateTransactionRecordedNotification(_ notificate: Notification) {
        // TODO: refresh received data count
        guard let transaction = notificate.userInfo?[String.kLensNetworkRecorderUserInfoTransactionKey] as? LensHTTPTransaction,
              let updateMITMHandler = allFLHandlers?[LensFeedListActionHanderName.refreshMITMHandler.rawValue] as? MITMModelHandler else { return }
        // 1. Refresh Model
        transaction.onRefreshHandler?()
        // 2. Refresh Feed List
        updateMITMHandler(transaction)
    }
    
}
