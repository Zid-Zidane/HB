//
//  LensNetworkRecorder.swift
//  demo
//
//  Created by hazhu1 on 2023/4/11.
//

import UIKit

public class LensNetworkRecorder: NSObject {

    private override init() {}
    @objc public static let defaultRecord = LensNetworkRecorder()
    
    // DispatchQueue defaults to a serial queue
    let queue = DispatchQueue(label: "com.Hubble.LensNetworkRecorder")
    
    var enableHostBlackList: Bool? = true       // black is the first filter
    var enableHostWhiteList: Bool? = true       // white is the second filter
    var hostBlackList: [String] = []            // those host will be blocked
    var hostWhiteList: [String] = []                // TBU: only those host will be monitor
    
    lazy var restCache: NSCache<NSString, AnyObject> = {
        let cache = NSCache<NSString, AnyObject>()
        cache.totalCostLimit = 50 * 1024 * 1024 // limit to 50MB, this also can verify based on different device
        return cache
    }()
    var orderedHttpTransactions: [LensHTTPTransaction] = []
    var requestIDsToTransactions: [String: LensHTTPTransaction] = [:]
    
    // MARK: - Tool
    func getResponseBody(transaction: MITMTransaction) -> Data? {
        guard let requestID = transaction.requestID as? NSString else { return nil }
        return restCache.object(forKey: (requestID)) as? Data
    }
    
    // MARK: - Record Transaction

    @objc
    public func recordRequestWillBeSent(requestID: String, request: URLRequest, task: URLSessionTask, redirectResponse: URLResponse?) {
        if let enableHostBlackList = enableHostBlackList,
           enableHostBlackList,
           hostBlackList.count > 0 {
            for host in hostBlackList {
                if request.url?.host?.hasSuffix(host) ?? false { return }
            }
        }
        
        if let enableHostWhiteList = enableHostWhiteList,
           enableHostWhiteList,
           hostWhiteList.count > 0 {
            let targetHost = (request.url?.host).lensOrEmpty
            if false == hostWhiteList.contains(targetHost) {
                return
            }
        }
        
        let transaction = LensHTTPTransaction(requestID: requestID,
                                              request: request,
                                              task: task,
                                              response: nil)
//        transaction.state = .lensNetworkTransactionStateAwaitingResponse
        // Before async block to keep times accurate
        if redirectResponse != nil {
            self.recordResponseReceived(requestID: requestID, response: redirectResponse)
            self.recordLoadingFinished(requestID: requestID, responseBody: nil)
        }
        
        queue.async { [weak self] in
            guard let ss = self else { return }
            // insert new translaction at tail
            ss.orderedHttpTransactions.append(transaction)
            ss.requestIDsToTransactions[requestID] = transaction
            
            ss.postNewTransactionNotificationWithTransaction(transaction)
        }
    }
    
    @objc
    public func recordDataReceived(requestID: String, dataLength: Int64) {
        queue.async { [weak self] in
            guard let ss = self else { return }
            guard let transaction: LensHTTPTransaction = ss.requestIDsToTransactions[requestID] else { return }
            
            transaction.receivedDataLength = transaction.receivedDataLength ?? 0 + dataLength
            ss.postUpdateNotificationForTransaction(transaction)
        }
    }
    
    @objc
    public func recordResponse(requestID: String, response: URLResponse) {
        let responseDate: NSDate = NSDate()
        
        queue.async { [weak self] in
            guard let ss = self else { return }
            guard let transaction: LensHTTPTransaction = ss.requestIDsToTransactions[requestID] else { return }
            transaction.response = response
            transaction.state = .lensNetworkTransactionStateReceivingData
            if let startData = transaction.startTime {
                transaction.latency = -startData.timeIntervalSince(responseDate as Date)
            }
            ss.postUpdateNotificationForTransaction(transaction)
        }
    }
    
    @objc
    public func recordLoadingFailed(requestID: String, error: Error) {
        queue.async { [weak self] in
            guard let ss = self else { return }
            guard let transaction = ss.requestIDsToTransactions[requestID] else { return }
            transaction.state = .lensNetworkTransactionStateFailed
            if let startData = transaction.startTime {
                transaction.duration = -startData.timeIntervalSinceNow
            }
            transaction.error = error
            
            ss.postUpdateNotificationForTransaction(transaction)
        }
    }
    
    @objc
    public func recordLoadingFinished(requestID: String, responseBody: NSData?) {
        let finishedDate = NSDate()
        
        queue.async { [weak self] in
            guard let ss = self else { return }
            guard let transaction: LensHTTPTransaction = ss.requestIDsToTransactions[requestID] else { return }
            
            transaction.state = .lensNetworkTransactionStateFinished
            if let startData = transaction.startTime {
                transaction.duration = -startData.timeIntervalSince(finishedDate as Date)
            }
            
            // do not cache media responseBody audio \ image \ video
            var shouldCache = responseBody?.length ?? 0 > 0
            
            if let response = transaction.response {
                shouldCache = nil == ["audio", "video"].first {
                    response.mimeType.lensOrEmpty.hasPrefix($0)
                }
            }
            
            if shouldCache,
               let responseBody = responseBody{
                ss.restCache.setObject(responseBody, forKey: requestID as NSString)
            }
            
            if let mimeType = transaction.response?.mimeType {
                if mimeType.hasPrefix("image/") && responseBody?.length ?? 0 > 0 {
                    // decode thumbmail
                    DispatchQueue.global().async {
                        let maxPixelDimension = Int64(UIScreen.main.scale * 32.0)
                        transaction.thumbnail = Tools.thumbnailedImage(maxPixelDimension: maxPixelDimension,
                                                                       fromImageData: responseBody)
                        ss.postUpdateNotificationForTransaction(transaction)
                    }
                } else if mimeType == "application/json" {
                    transaction.thumbnail = LensResources.jsonIcon
                } else if mimeType == "text/plain" {
                    transaction.thumbnail = LensResources.textPlainIcon
                } else if mimeType == "text/html" {
                    
                    transaction.thumbnail = LensResources.htmlIcon
                } else if mimeType == "application/x-plist" {
                    transaction.thumbnail = LensResources.plistIcon
                } else if mimeType == "application/octet-stream" || mimeType == "application/binary" {
                    transaction.thumbnail = LensResources.binaryIcon
                } else if mimeType == "javascript" || mimeType == "application/javascript" {
                    transaction.thumbnail = LensResources.jsIcon
                } else if mimeType == "xml" || mimeType == "application/xml" {
                    transaction.thumbnail = LensResources.xmlIcon
                } else if mimeType == "audio" {
                    transaction.thumbnail = LensResources.audioIcon
                } else if mimeType == "video" {
                    transaction.thumbnail = LensResources.videoIcon
                } else if mimeType == "text" {
                    transaction.thumbnail = LensResources.textIcon
                }
                
                ss.postUpdateNotificationForTransaction(transaction)
            }
        }
    }
    
    @objc
    public func recordResponseReceived(requestID: String, response: URLResponse?) {
        let responseDate = NSDate()
        
        queue.async { [weak self] in
            guard let ss = self else { return }
            guard let transaction: LensHTTPTransaction = ss.requestIDsToTransactions[requestID] else { return }

            transaction.response = response
            transaction.state = .lensNetworkTransactionStateReceivingData
            if let startData = transaction.startTime {
                transaction.latency = -startData.timeIntervalSince(responseDate as Date)
            }
            
            ss.postUpdateNotificationForTransaction(transaction)
        }
    }
    
    // MARK: - Post Notify -
    func postNewTransactionNotificationWithTransaction(_ transaction: LensHTTPTransaction?) {
        notify(.kLensNetworkRecorderNewTransactionNotification, transaction)
    }
    
    func postUpdateNotificationForTransaction(_ transaction: LensHTTPTransaction?) {
        notify(.kLensNetworkRecorderUpdatedNotification, transaction)
    }
    
    func notify(_ name: Notification.Name, _ transaction: LensHTTPTransaction?) {
        var userInfo: [String: LensHTTPTransaction?] = [:]
        if transaction != nil {
            userInfo = [.kLensNetworkRecorderUserInfoTransactionKey: transaction]
        }
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: name, object: self, userInfo: userInfo as [AnyHashable : Any])
        }
    }
    
}
