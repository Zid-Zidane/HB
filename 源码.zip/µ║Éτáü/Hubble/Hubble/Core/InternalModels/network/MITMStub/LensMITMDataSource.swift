//
//  LensMITMDataSource.swift
//  demo
//
//  Created by hazhu1 on 2023/4/12.
//

import Foundation

class LensMITMDataSource<Transaction: MITMTransaction> {
    
    var fetchAllTransactionsHandler: (() -> [Transaction])
    var allTransactions: [Transaction] = []
    var bytesReceived: Int64 = 0
    var successTransactionCount: Int64 = 0
    var failureTransactionCount: Int64 = 0
    var suspendTransactionCount: Int64 = 0
    var allTransactioncount: Int64 = 0
    var failureRate: CFloat = 0.0
    
    init(fetchAllTransactionsHandler: @escaping () -> [Transaction]) {
        self.fetchAllTransactionsHandler = fetchAllTransactionsHandler
    }
    
    static func dataSourceWithProvider(_ hander: @escaping ()->[Transaction]) -> LensMITMDataSource {
        let instance = LensMITMDataSource(fetchAllTransactionsHandler: hander)
        return instance
    }
    func reloadData(_ queue: DispatchQueue, hander: @escaping BlankHandler) {
        allTransactions = fetchAllTransactionsHandler()
        updateBytesReceived(allTransactions)
        updateSuccessTransactionCount(allTransactions)
        updateFailureTransactionCount(allTransactions)
        updateSuspendTransactionCount(allTransactions)
        updateAllTransactioncount(allTransactions)
        updateFailureRate()
        queue.async {
            hander()
        }
    }
    
    // TODO: Those function shall be refactor, used Transaction should not use again
    func updateBytesReceived(_ allTransations: [Transaction]) {
        bytesReceived = allTransations.reduce(0, { partialResult, transaction in
            return partialResult + (transaction.receivedDataLength ?? 0)
        })
    }
    
    // TODO: Those function shall be refactor, used Transaction should not use again
    func updateSuccessTransactionCount(_ allTransations: [Transaction]) {
        successTransactionCount = allTransations.reduce(0, { partialResult, transaction in
            return partialResult + (transaction.state == .lensNetworkTransactionStateFinished ? 1 : 0)
        })
    }
    
    // TODO: Those function shall be refactor, used Transaction should not use again
    func updateFailureTransactionCount(_ allTransations: [Transaction]) {
        failureTransactionCount = allTransations.reduce(0, { partialResult, transaction in
            return partialResult + (transaction.state == .lensNetworkTransactionStateFailed ? 1 : 0)
        })
    }
    
    // TODO: Those function shall be refactor, used Transaction should not use again
    func updateSuspendTransactionCount(_ allTransations: [Transaction]) {
        suspendTransactionCount = allTransations.reduce(0, { partialResult, transaction in
            return partialResult + (transaction.state == .lensNetworkTransactionStateFailed ? 1 : 0)
        })
    }
    
    func updateAllTransactioncount(_ allTransations: [Transaction]) {
        allTransactioncount = successTransactionCount + failureTransactionCount + suspendTransactionCount
    }
    
    func updateFailureRate() {
        failureRate = CFloat(CGFloat(failureTransactionCount) / CGFloat(allTransactioncount))
    }
    
}
