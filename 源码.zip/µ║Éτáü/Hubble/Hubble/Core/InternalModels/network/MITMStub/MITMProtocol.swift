//
//  MITMProtocol.swift
//  demo
//
//  Created by hazhu1 on 2023/4/12.
//

import UIKit

protocol MITMTransaction {
    var requestID: String   { get }
    var receivedDataLength: Int64?  { get }
    var state: LensNetworkTransactionState? { get }
    var startTime: NSDate?  { get }
    var displayAsError: Bool    { get }
    var thumbnail: UIImage? { get }
    
    var latency: TimeInterval?  { get }
    var duration: TimeInterval? { get }
    var error: Error?   { get }
    var onRefreshHandler: BlankHandler? { get set }             // to refresh model content to display new data when transaction refreshed
    var onStateChangeHandler: MITMModelHandler? { get set }      // to add model to alert page when state change to failure
    
    func mainMessage() -> String
    func subMessage() -> String
    func contentMessage() -> String
    func detailProtocol() -> [LensPageModelMITMProtocol?]    // detail page datas
}

protocol HTTPTransaction: MITMTransaction {
    var task: URLSessionTask { get set }
}
