//
//  LensMITNTransaction.swift
//  demo
//
//  Created by hazhu1 on 2023/4/12.
//

import UIKit

class LensMITNTransaction: NSObject {
    var requestID: String
    var receivedDataLength: Int64?
    var state: LensNetworkTransactionState?
    var startTime: NSDate?
    var displayAsError: Bool = false
    var thumbnail: UIImage?
    
    var latency: TimeInterval?          // watv / TTFB
    var duration: TimeInterval?         // totv
    var error: Error?
    
    init(requestID: String, receivedDataLength: Int64? = nil, state: LensNetworkTransactionState? = nil, startTime: NSDate? = nil, displayAsError: Bool, thumbnail: UIImage? = nil, latency: TimeInterval? = nil, duration: TimeInterval? = nil, error: Error? = nil) {
        self.requestID = requestID
        self.receivedDataLength = receivedDataLength
        self.state = state
        self.startTime = startTime
        self.displayAsError = displayAsError
        self.thumbnail = thumbnail
        self.latency = latency
        self.duration = duration
        self.error = error
    }
    
}
