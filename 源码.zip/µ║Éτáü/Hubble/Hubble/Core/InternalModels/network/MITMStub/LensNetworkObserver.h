//
//  LensNetworkObserver.h
//  demo
//
//  Created by hazhu1 on 2023/4/11.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXTERN NSString *const kLensNetworkObserverEnabledStateChangedNotification;

/// This class is for swizzle NSURLConnection and NSURLSession delegate methods to observe events in the URL loading system.
@interface LensNetworkObserver : NSObject
@property (nonatomic, class, getter=isEnabled) BOOL enabled;
@end
