//
//  LensHTTPTransaction.swift
//  demo
//
//  Created by hazhu1 on 2023/4/11.
//

import UIKit

class LensHTTPTransaction: NSObject, HTTPTransaction {
    
    var task: URLSessionTask
    var receivedDataLength: Int64?
    var startTime: NSDate?
    var displayAsError: Bool = false
    var thumbnail: UIImage?
    
    var requestID: String
    var request: URLRequest?
    var response: URLResponse?
    var latency: TimeInterval?          // watv / TTFB
    var duration: TimeInterval?         // totv
    var error: Error?
    var onRefreshHandler: BlankHandler?
    var onStateChangeHandler: MITMModelHandler?
    
    var _state: LensNetworkTransactionState?
    var state: LensNetworkTransactionState? {
        get {
            return _state
        }
        set {
            _state = newValue
            if newValue == .lensNetworkTransactionStateFailed {
                onStateChangeHandler?(self)
            }
        }
    }
    
    init(requestID: String, request: URLRequest? = nil, task: URLSessionTask, response: URLResponse? = nil) {
        self.task = task
        self.startTime = NSDate()
        self.requestID = requestID
        self.request = request
        self.response = response
    }
    
    func mainMessage() -> String {
        return (request?.httpMethod).or("-") + " · " + (request?.url?.absoluteString).or("-1")
    }
    
    func subMessage() -> String {
        if let httpUrlResponse = response as? HTTPURLResponse {
            return (startTime?.lensFormattedString).lensOrEmpty + " · ✅ \(httpUrlResponse.statusCode) · \((request?.httpMethod).lensOrEmpty) · " + (response?.mimeType).lensOrEmpty + "\n" + self.requestID
        } else if let error = error as? NSError {
            return (startTime?.lensFormattedString).lensOrEmpty + " · 🚫 \(error.code) · " + (response?.mimeType).lensOrEmpty + "\n" + self.requestID
        }else {
            return (startTime?.lensFormattedString).lensOrEmpty + "\n" + self.requestID
        }
    }
    
    /// By default HTTP can only see detail on detail page so do return empty for title
    func contentMessage() -> String {
        return ""
    }
    
    // MARK: - MITM Detail Page Model -
    func detailProtocol() -> [LensPageModelMITMProtocol?] {
        // 详情页数据，需要符合详情页协议
        let overviewProtocol = overViewHTTP()
        let requestHTTP = requestHTTP()
        let responseHTTP = responseHTTP()
        let waterfallHTTP = waterfallHTTP()
        return [
            overviewProtocol,
            requestHTTP,
            responseHTTP,
            waterfallHTTP
        ]
    }
    
    func overViewHTTP() -> LensPageModelMITMProtocol {
        let pageModel = LensBasePageMITMModel(type: LensPageStruct("net"), title: "overview", selected: true, toolItems: [])
        pageModel.sectionItems = overViewHTTPInformatins().compactMap({ (key: String, value: [LensDetailPageContentType]) in
            LensBaseGroupModel(section: LensBaseModel(titleText: key, cellIdentity: Const.LensInformationCellId), cellModels: value.compactMap({ value in
                LensBaseModel(contentText: nil, isExpanded: true, cellIdentity: Const.LensInformationCellId, actionType: .expandable(true), detailPageContent: value, cellHeight: value.height())
            }), priproty: 0)
        })
        return pageModel
    }
    
    func requestHTTP() -> LensPageModelMITMProtocol {
        let pageModel = LensBasePageMITMModel(type: LensPageStruct("net"), title: "request", selected: true, toolItems: [])
        pageModel.sectionItems = requestHTTPInformatins().compactMap({ (key: String, value: [LensDetailPageContentType]) in
            LensBaseGroupModel(section: LensBaseModel(titleText: key, cellIdentity: Const.LensInformationCellId), cellModels: value.compactMap({ value in
                let actionType: LensCellActionType = value.needsDisplayWK() ? .detailable(true) : .expandable(true)
                return LensBaseModel(contentText: nil, isExpanded: true, cellIdentity: Const.LensInformationCellId, actionType: actionType, detailPageContent: value, cellHeight: value.height())
            }), priproty: 0)
        })
        return pageModel
    }
    
    func responseHTTP() -> LensPageModelMITMProtocol? {
        guard let _ = response else { return nil }
        let pageModel = LensBasePageMITMModel(type: LensPageStruct("net"), title: "response", selected: true, toolItems: [])
        pageModel.sectionItems = responseHTTPInformatins().compactMap({ (key: String, value: [LensDetailPageContentType]) in
            LensBaseGroupModel(section: LensBaseModel(titleText: key, cellIdentity: Const.LensInformationCellId), cellModels: value.compactMap({ value in
                let actionType: LensCellActionType = value.needsDisplayWK() ? .detailable(true) : .expandable(true)
                return LensBaseModel(contentText: nil, isExpanded: true, cellIdentity: Const.LensInformationCellId, actionType: actionType, detailPageContent: value, cellHeight: value.height())
            }), priproty: 0)
        })
        return pageModel
    }
    
    // TODO: waterfall, this needs hook datatask, currently only hook urlsession
    func waterfallHTTP() -> LensPageModelMITMProtocol? {
        return nil
    }
    
    // MARK: - TOOLS -
    func getBody(_ withData: Data?) -> LensDetailPageContentType {
        guard let data = withData else { return .text("NO Data", 20) }
        
        let mimeType = (self.response?.mimeType).lensOrEmpty
        var bodyContent: LensDetailPageContentType = .text("Can not Encode", 20)
        if Tools.isValidJSONData(data) {
            let jsonString = Tools.getPrettyJSONString(data).lensOrEmpty
            bodyContent = .text(jsonString, Tools.getCellHeight(jsonString, width: Tools.screenWidth().orZero - 4).orZero)
        } else if mimeType.hasPrefix("image/") {
            let image = UIImage(data: data)
            bodyContent = .image(image)
        } else if mimeType == "application/x-plist" {
            let content = Tools.getPlistString(data)
            bodyContent = .text(content, Tools.getCellHeight(content, width: Tools.screenWidth().orZero - 4).orZero)
        } else if let content = String(data: data, encoding: .utf8) {
            bodyContent = .text(content, Tools.getCellHeight(content, width: Tools.screenWidth().orZero - 4).orZero)
        }
        
        return bodyContent
    }
    
    func getDetailContentText(_ content: String?) -> LensDetailPageContentType {
        return .text(content, Tools.getCellHeight(content, width: Tools.screenWidth().orZero - 4).orZero)
    }
    
    // MARK: - generate MITM INFORMATION -
    
    func overViewHTTPInformatins() -> [String: [LensDetailPageContentType]] {
        let durationHandler: () -> String = {
            guard let durationString = Tools.interceptionDecimal(float: Float((self.duration ?? 0.0) * 1000), base: 2) else { return "" }
            return durationString + " ms"
        }
        var content = (request?.url?.absoluteString).lensOrEmpty
        let url: LensDetailPageContentType = getDetailContentText(content)
        content = (request?.url?.host).lensOrEmpty
        let host: LensDetailPageContentType = getDetailContentText(content)
        content = (request?.httpMethod).lensOrEmpty
        let method: LensDetailPageContentType = getDetailContentText(content)
        content = String(((response as? HTTPURLResponse)?.statusCode) ?? -1)
        let responseCode: LensDetailPageContentType = getDetailContentText(content)
        content = String(self.receivedDataLength.orZero) + " Byte"
        let bytesReceived: LensDetailPageContentType = getDetailContentText(content)
        content = durationHandler()
        let duration: LensDetailPageContentType = getDetailContentText(content)
        let result: [String: [LensDetailPageContentType]] = [
            "Url": [url],
            "Host": [host],
            "Method": [method],
            "Response Code": [responseCode],
            "Bytes Received": [bytesReceived],
            "Duration": [duration]
        ]
        return result
    }
    
    func requestHTTPInformatins() -> [String: [LensDetailPageContentType]] {
        let cookieHandler: ()->String = { [weak self] in
            guard let ss = self,
                  let request = ss.request?.url,
                  let cookies = HTTPCookieStorage.shared.cookies(for: request.absoluteURL) else { return "-" }
            return Tools.convertCookiesToString(cookies, leading: "*")
        }
        let bodyHandler: () -> String = {
            guard let data = self.request?.httpBody else { return "" }
            var resultString = ""
            if let bodyString = Tools.getPrettyJSONString(data) {
                resultString = bodyString
            } else if let bodyString = String(data: data, encoding: String.Encoding.utf8) {
                resultString = bodyString
            } else if let bodyString = Tools.decodeBase64(data) {
                resultString = bodyString
                resultString = Tools.splitString(resultString, component: "&")
            }
            return resultString
        }
        var content = (request?.url?.absoluteString).lensOrEmpty
        let url: LensDetailPageContentType = getDetailContentText(content)
        content = (request?.url?.path).lensOrEmpty
        let path: LensDetailPageContentType = getDetailContentText(content)
        content = (request?.url?.query).lensOrEmpty
        let query: LensDetailPageContentType = getDetailContentText(content)
        content = bodyHandler()
        let body: LensDetailPageContentType = getDetailContentText(content)
        content = cookieHandler()
        let cookie: LensDetailPageContentType = getDetailContentText(content)
        content = Tools.convertMapToFormatString(request?.allHTTPHeaderFields, leading: "*").lensOrEmpty
        let header: LensDetailPageContentType = getDetailContentText(content)
        let result: [String: [LensDetailPageContentType]] = [
            "Url": [url],
            "Path": [path],
            "Query": [query],
            "Cookie": [cookie],
            "Body": [body],
            "Header": [header]
        ]
        return result
    }
    
    func responseHTTPInformatins() -> [String: [LensDetailPageContentType]] {
        let cookieHandler: ()->String = { [weak self] in
            guard let ss = self,
                  let url = ss.response?.url,
                  let httpResponse = ss.response as? HTTPURLResponse,
                  let fields = httpResponse.allHeaderFields as? [String: String] else { return "-" }
            let cookies = HTTPCookie.cookies(withResponseHeaderFields: fields, for: url)
            HTTPCookieStorage.shared.setCookies(cookies, for: url, mainDocumentURL: nil)
            return Tools.convertCookiesToString(cookies, leading: "*")
        }

        var content = String((response as? HTTPURLResponse)?.statusCode ?? 0)
        let stausCode: LensDetailPageContentType = getDetailContentText(content)
        content = cookieHandler()
        let cookie: LensDetailPageContentType = getDetailContentText(content)
        let headerMap = (response as? HTTPURLResponse)?.allHeaderFields as? [String: String]
        content = Tools.convertMapToFormatString(headerMap, leading: "*").lensOrEmpty
        let header: LensDetailPageContentType = getDetailContentText(content)
        content = (response?.mimeType).lensOrEmpty
        let mimeType: LensDetailPageContentType = getDetailContentText(content)
        let body: LensDetailPageContentType = self.getBody(LensNetworkRecorder.defaultRecord.getResponseBody(transaction: self))
        let result: [String: [LensDetailPageContentType]] = [
            "Staus Code": [stausCode],
            "Cookie": [cookie],
            "Header": [header],
            "MimeType": [mimeType],
            "Body": [body]
        ]
        return result
    }
    
    func waterfallHTTPInformatins() -> [String: [LensDetailPageContentType]] {
        return ["": []]
    }
    
}
