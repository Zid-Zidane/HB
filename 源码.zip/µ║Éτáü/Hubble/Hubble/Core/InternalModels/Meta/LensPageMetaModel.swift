//
//  LensPageMetaModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/5.
//

import Foundation

class LensPageMetaModel: LensPageModelProtocol {
    
    static let shared = LensPageMetaModel()
    private init() {}
    var visible: Bool = true
    var type: LensPageStruct = LensPageStruct("meta")
    var title: String = "Basic"
    var selected: Bool = true
    var now: Bool = false
    var toolItems: [LensToolItemType] = [.close, .debug, .fold]
    var reload: BlankHandler?
    var scrollToBottom: PageModelHandler?
    var allFLHandlers: [String : Any]?
    
    lazy var sectionItems: [LensGroupModelProtocol] = {
        let sectionItems = [
            LensGroupMetaModel.shared
        ]
        return sectionItems
    }()
    
    func setMetaData(_ metaData: [String: String]?) {
        LensGroupMetaModel.shared.setMetaData(metaData)
        if let updateHandler = allFLHandlers?[LensFeedListActionHanderName.reloadHandler.rawValue] as? BlankHandler {
            updateHandler()
        }
    }
    
}
