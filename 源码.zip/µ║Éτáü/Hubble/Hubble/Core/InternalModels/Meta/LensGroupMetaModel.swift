//
//  LensGroupMetaModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/5.
//

import Foundation

class LensGroupMetaModel: LensGroupModelProtocol {
    
    static let shared = LensGroupMetaModel()
    private init() {}

    lazy var section: LensModelProtocol? = {
        let section = LensBaseModel(titleText: "Meta", cellIdentity: Const.LensCarouselId)
        return section
    }()
    lazy var cellModels: [LensModelProtocol?] = {
        let cells = makeSections()
        return cells
    }()
    private var basicInfoString: String = ""
    var priproty: Int = 0

    func makeSections() -> [LensModelProtocol?] {
        var models: [LensModelProtocol?] = []
        models.append(
            LensBaseModel(titleText: "APP Infos", subtitleText: nil, contentText: Tools.getBasicAppInfoString(), isExpanded: true, cellIdentity: Const.LensInformationCellId, actionType: .detailable(true))
        )
        models.append(
            LensBaseModel(titleText: "Device Infos", subtitleText: nil, contentText: Tools.getBasicDeviceInfoString(), isExpanded: true, cellIdentity: Const.LensInformationCellId, actionType: .detailable(true))
        )
        return models
    }

    func append(_ item: LensModelProtocol) {
        cellModels.append(item)
    }
    
    func setMetaData(_ metaData: [String: String]?) {
        guard let metaData = metaData else { return }
        
        for item in metaData {
            let model = LensBaseModel(titleText: item.key, subtitleText: nil, contentText: item.value, isExpanded: true, cellIdentity: Const.LensInformationCellId, actionType: .detailable(true))
            cellModels.append(model)
            basicInfoString += item.key + " · " + item.value + "\n"
        }
    }
    
    func basicInfo() -> String {
        var basicInfo = "ℹ️APP Infos" + "\n" + Tools.getBasicAppInfoString() + "\n" + "·············\n"
        basicInfo += "ℹ️Device Infos" + "\n" + Tools.getBasicDeviceInfoString() + "\n" + "·············\n"
        basicInfo += "ℹ️Basic Infos" + "\n" + basicInfoString
        return basicInfo
    }
    
}
