//
//  LensPageAlertModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/8.
//

import Foundation

class LensPageAlertModel: LensBasePageModel {
    
    static let shared = LensPageAlertModel()
    private init() { super.init(type: LensPageStruct("alert"), title: "🚨", selected: false, toolItems: [.close, .debug, .fold, .now]) }
    
    func appendAlertItem(_ item: LensModelProtocol) {
        // 1 add alert item
        if LensPageAlertModel.shared.sectionItems.count == 0 {
            LensPageAlertModel.shared.sectionItems.append(LensBaseGroupModel(cellModels: [], priproty: 0))
        }
        LensPageAlertModel.shared.sectionItems.first?.append(item)
        // 2. refresh table view
        if LensInformationPageViewController.shared.viewIfLoaded?.window != nil {
            if LensPageAlertModel.shared.selected {
                LensPageAlertModel.shared.reload?()
                // 3. scroll to bottom
                if LensPageAlertModel.shared.now {
                    LensPageAlertModel.shared.scrollToBottom?(self)
                }
            }
        }
        NotificationCenter.default.post(name: .kLensAlertNotification, object: self, userInfo: nil)
    }
    
}
