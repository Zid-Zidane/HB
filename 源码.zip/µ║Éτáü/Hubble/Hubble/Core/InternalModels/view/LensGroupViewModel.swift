//
//  LensGroupViewModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/6.
//

import Foundation
 
class LensGroupViewModel: LensBaseGroupModel {
    /*
    lazy var section: LensModelProtocol? = {
        let section = LensBaseModel(titleText: "View", cellIdentity: Const.LensCarouselId)
        return section
    }()
    lazy var cellModels: [LensModelProtocol?] = {
        let cells = makeSections()
        return cells
    }()
    
    var priproty: Int = 0
    
    func makeSections() -> [LensModelProtocol?] {
        // test
        var models: [LensModelProtocol?] = []
        models.append(
            LensBaseModel(titleText: "View Infos", subtitleText: nil, contentText: "UIImageView frame: (100, 100, 20 30)", isExpanded: true, cellIdentity: Const.LensInformationCellId, actionType: .expandable(true))
        )
        // test
        return models
    }
    
    func foo() {
        
    }
*/
}
