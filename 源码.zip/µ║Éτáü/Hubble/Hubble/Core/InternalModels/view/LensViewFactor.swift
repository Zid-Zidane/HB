//
//  LensViewFactor.swift
//  demo
//
//  Created by hazhu1 on 2023/4/17.
//

import UIKit

class LensViewFactor: LensBaseModelFactory {
    
    override func generate(type: LensPageStruct!, groupName: String?, title: String, subTitle: String, contentText: String, snapshot: UIImage?, needsAlert: Bool, expandable: Bool) throws -> LensModelProtocol? {
        let model = LensBaseModel(titles: [], time: NSDate(), titleText: title, subtitleText: subTitle, contentText: contentText, isExpanded: true, cellIdentity: Const.LensInformationCellId, accessoryInfo: .none, actionType: .expandable(expandable), needsAlert: needsAlert, leadingImage: nil, detailPageContent: nil, cellHeight: nil)
        return model
    }
    
    public override func update(type: LensPageStruct!, model: LensModelProtocol) throws {
        guard let pageModel = LensBaseModelFactory.defaultFactory.pageModels[type] else { throw LensFactorError.needsRegistPageModel }
        guard let firstSection = pageModel.sectionItems.first,
              let cellModel = firstSection.cellModels.first as? LensModelProtocol else {
            pageModel.append(model)
            return
        }
        guard let refreshHandler = pageModel.allFLHandlers?[LensFeedListActionHanderName.reloadHandler.rawValue] as? BlankHandler else { return }
        cellModel.titleText = model.titleText
        cellModel.subtitleText = model.subtitleText
        cellModel.contentText = model.contentText
        refreshHandler()
    }
    
}
