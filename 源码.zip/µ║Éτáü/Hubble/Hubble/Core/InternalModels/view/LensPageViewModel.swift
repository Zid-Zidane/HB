//
//  LensPageViewModel.swift
//  demo
//
//  Created by hazhu1 on 2023/4/6.
//

import Foundation

class LensPageViewModel: LensPageModelProtocol {
    
    static let shared = LensPageViewModel()
    private init() {}
    var visible: Bool = true
    var type: LensPageStruct = LensPageStruct("meta")
    var title: String = "View"
    var selected: Bool = true
    var now: Bool = false
    var toolItems: [LensToolItemType] = [.close, .debug, .fold, .locate]
    var reload: BlankHandler?
    var scrollToBottom: PageModelHandler?
    var allFLHandlers: [String : Any]?
    
    lazy var sectionItems: [LensGroupModelProtocol] = {
        let sectionItems = [
            LensGroupViewModel(cellModels: [], priproty: 0)
        ]
        return sectionItems
    }()
}
