//
//  LensModelFactory.swift
//  demo
//
//  Created by hazhu1 on 2023/4/17.
//

import UIKit

open class LensBaseModelFactory: NSObject, LensPageGeneratorProtocol {
    public var visible: Bool = false
    public var title: String = ""
    @objc public static let defaultFactory: LensBaseModelFactory = LensBaseModelFactory()
    private var collections: [LensPageStruct: LensPageGeneratorProtocol] = [:]
    internal var pageModels: [LensPageStruct: LensPageModelProtocol] = [:]
    
    func pageModel(_ title: String, visible: Bool) -> LensPageModelProtocol? {
        let type = LensPageStruct(title)
        return LensBasePageModel(type: type, title: title, selected: false, toolItems: [.close, .debug, .fold], visible: visible)
    }
    
    func regist(type: LensPageStruct, factory: LensPageGeneratorProtocol, pageModel: LensPageModelProtocol) throws {
        guard nil == collections[type] else { throw LensFactorError.errorType }
        guard nil == pageModels[type] else { throw LensFactorError.errorpageModel }
        collections[type] = factory
        pageModels[type] = pageModel
    }
    
    public func generate(type: LensPageStruct!, groupName: String?, title: String, subTitle: String, contentText: String, snapshot: UIImage? = nil, needsAlert: Bool, expandable: Bool = true) throws -> LensModelProtocol? {
        let model: LensModelProtocol? = LensBaseModel(titles: [], time: NSDate(), detaiImage: snapshot, titleText: title, subtitleText: subTitle, contentText: contentText, isExpanded: expandable, cellIdentity: Const.LensInformationCellId, accessoryInfo: .none, actionType: .detailable(true), needsAlert: needsAlert, leadingImage: nil, detailPageContent: .text(contentText), cellHeight: nil)
        return model
    }
    
    public func update(type: LensPageStruct!, model: LensModelProtocol) throws {
        guard let pageModel = LensBaseModelFactory.defaultFactory.pageModels[type] else { throw LensFactorError.needsRegistPageModel }
        guard let firstSection = pageModel.sectionItems.first,
              let cellModel = firstSection.cellModels.first as? LensModelProtocol else {
            pageModel.append(model)
            return
        }
        guard let refreshHandler = pageModel.allFLHandlers?[LensFeedListActionHanderName.reloadHandler.rawValue] as? BlankHandler else { return }
        cellModel.titleText = model.titleText
        cellModel.subtitleText = model.subtitleText
        cellModel.contentText = model.contentText
        refreshHandler()
    }
    
    @objc public func generateThenUpdate(type: String!, groupName: String?, title: String, subTitle: String, contentText: String, snapshot: UIImage? = nil, needsAlert: Bool) throws {
        try generateThenUpdate_(type: type, groupName: groupName, title: title, subTitle: subTitle, contentText: contentText, snapshot: snapshot, needsAlert: needsAlert, needsCodeInfo: false)
    }
    
    public func generateThenUpdate_(type: String!, groupName: String?, title: String, subTitle: String, contentText: String, snapshot: UIImage? = nil, needsAlert: Bool, needsCodeInfo: Bool = true, file: String = #file, func: String = #function, line: Int = #line, column: Int = #column) throws {
        let type = LensPageStruct(type)
        guard let factory = collections[type] else { throw LensFactorError.needsReigstSubFactory }
        guard let model = try factory.generate(type: type, groupName: groupName, title: title, subTitle: subTitle, contentText: contentText, snapshot: snapshot, needsAlert: needsAlert, expandable: false) else { throw LensFactorError.generateFatel }
        try factory.update(type: type, model: model)
    }
    
    open func generateThenUpdate(reason: String, subTitle: String? = nil, log: String, snapshot: UIImage? = nil, alert: Bool, expandable: Bool = true, pageName: String?, tag: Bool = false, needsCodeInfo: Bool = true, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column) {
        let type = LensPageStruct(self.title)
        guard let factory = LensBaseModelFactory.defaultFactory.collections[type] else { return }
        do {
            var contentText = log
            if needsCodeInfo {
                let fileName = file.components(separatedBy: "/").last.lensOrEmpty
                var meta = "<b>Version: </b>\(Tools.getAPPVersion())\n"
                if let pageName = pageName {
                    let _pageName = "<b>page: </b>\(pageName)"
                    meta = meta + _pageName
                }
                contentText = "<b>Function: </b>\(funcName)\n<b>Line: </b>\(fileName):\(line):\(column)\n·············\n<b>reason</b>\n\(reason)\n·············\n<b>log</b>\n\(log)"
                contentText = meta + "\n·············\n" + contentText
            }
            guard let model = try LensBaseModelFactory.defaultFactory.generate(type: type, groupName: nil, title: title, subTitle: subTitle.or(reason), contentText: contentText, snapshot: snapshot, needsAlert: alert, expandable: expandable) else { return }
            try factory.update(type: type, model: model)
        } catch{}
    }
    
}
