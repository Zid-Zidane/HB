![](https://github.com/TomZid/Hubble/assets/7844886/04e27b58-8590-4f49-8eae-1ae06d109925)

# Hubble
Hubble is a tool to help Developer / UX / QA to automatic detect and identify potential issue. Lens is a window for display information and long press it you can view the panel which contains all the debug tool. For more information please refer 

## Usage
```
        // 1. Enable Hubble
        HubbleCoordinator.shared.setOn(true)

        // 2. Configuration
        HubbleCoordinator.shared.setLensData(["Version" : "1.0"])
        HubbleCoordinator.shared.viewPageNameHanler = {
            let currentViewControllerName = Project Current View Controller Name
            return currentViewControllerName
        }
        HubbleCoordinator.shared.currentViewPageHanler = {
            let currentViewController = Project Current View Controller
            return currentViewController
        }
        
        // 3. Show Lens
        HubbleCoordinator.shared.show()
```

## Feature
### Net
Net tab displays all http / https (ws to be implement) requests under NSURLSession. Each row displays the requested resource type, link, request date and status code. Further details of the request and response are shown on the Details page.

### UI Inspector
Click to Check information of view.

### Business Inspector
Click to Check business information of view. (Belongs to [HubbleCoordinator](https://github.com/TomZid/HubbleCoordinator))

### Business Issue Alert
Business issue will tip in hub, domain issue gather together which is filterable.

### UI Issue Alert
Overlap / Truncate / Clip issue is detected automatic. Without business code intrusion.

### Business / UI Issue Share
Log is show in alert Tab, there you can check for detail. Every detail log can share with your own mail / IM tool

![image-2023-4-23_16-30-44](https://github.com/TomZid/Hubble/assets/7844886/2c9016f9-2890-4d08-8e3a-51df10a00328)
<img width="300" alt="image-2023-5-7_19-16-35" src="https://github.com/TomZid/Hubble/assets/7844886/adba4920-d596-4a3c-8d84-4fe0240c83b2">
![image-2023-4-25_0-25-31](https://github.com/TomZid/Hubble/assets/7844886/200cae1f-3f8e-41b0-98ab-d30d1f28bf8c)



## Note
Suggest Business Project dependency [HubbleCoordinator](https://github.com/TomZid/HubbleCoordinator), not suggest Business Project dependency Hubble module directly.

