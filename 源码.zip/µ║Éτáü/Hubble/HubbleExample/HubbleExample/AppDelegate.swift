//
//  AppDelegate.swift
//  HubbleExample
//
//  Created by hazhu1 on 2023/4/6.
//

import UIKit
import HubbleCoordinator

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        if let superView = window?.rootViewController?.view {
            HelpTipView.show(superView)
        }
        
        /// 1. Enable Hubble
        HubbleCoordinator.shared.setOn(true)
        /// 2. Configuration
        HubbleCoordinator.shared.viewPageNameHanler = {
            guard let currentViewController = self.window?.rootViewController else { return "" }
            return String(describing: type(of: currentViewController).self)
        }
        HubbleCoordinator.shared.currentViewPageHanler = {
            guard let currentViewController = self.window?.rootViewController else { return nil }
            return currentViewController
        }
        HubbleCoordinator.shared.setLensData(["Version" : "1.0"])
        return true
    }

}

