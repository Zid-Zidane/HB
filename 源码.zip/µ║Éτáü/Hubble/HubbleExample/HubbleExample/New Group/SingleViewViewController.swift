//
//  SingleViewViewController.swift
//  HubbleExample
//
//  Created by hazhu1 on 2023/5/8.
//

import UIKit
import HubbleCoordinator

class SingleViewViewController: UIViewController {

    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        HubbleCoordinator.shared.setOn(true)
        HubbleCoordinator.shared.viewPageNameHanler = {
            return "TableViewController"
        }
        HubbleCoordinator.shared.currentViewPageHanler = {
            return self
        }
        
        HubbleCoordinator.shared.show()
    }
    

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        count += 1
        if count % 2 == 0 {
            HubbleCoordinator.shared.close()
        } else {
            HubbleCoordinator.shared.show()
        }
    }
        
}
