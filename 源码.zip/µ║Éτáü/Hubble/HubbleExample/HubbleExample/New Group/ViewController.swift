//
//  ViewController.swift
//  HubbleExample
//
//  Created by hazhu1 on 2023/4/6.
//

import UIKit
import Alamofire
import HubbleCoordinator

class ViewController: UIViewController {

    struct Const {
        static var count = 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        HubbleCoordinator.shared.setOn(true)
        HubbleCoordinator.shared.viewPageNameHanler = {
            return "TableViewController"
        }
        HubbleCoordinator.shared.currentViewPageHanler = {
            return self
        }
        
        HubbleCoordinator.shared.show()
    }
    
    @IBAction func hubbleClick(_ some: UIButton) {
        HubbleCoordinator.shared.show()
    }
    
    @IBAction func netClicked(_ sender: Any) {
        let xml = "https://www.w3.org/1999/xhtml/"
        let image = "https://ts1.cn.mm.bing.net/th?id=OIP-C.2bJ9_f9aKoGCME7ZIff-ZwHaJ4&w=154&h=206&c=8&rs=1&qlt=90&o=6&dpr=2&pid=3.1&rm=2"
        let html = "https://iqiyi.com"
        let js = "https://g.csdnimg.cn/common/csdn-login-box/csdn-login-box.js"
        let txt = "https://filesamples.com/samples/document/txt/sample3.txt"
        let json = "https://ifunwidget.com/ifun-api/remix/favouritepage/default/favourite"
        let xxx = "https://ifunwidget.com/ifun-api/remix/favouritepage/default"
        let urls = [
            xml,
            image,
            html,
            js,
            txt,
            json,
            xxx
        ]
        // Get
        for url in urls {
            access(url)
        }
        
        // Post
        postRequest()
    }
    
    func access(_ url: String) {
        if let url = URL(string: url) {
            URLSession(configuration: .ephemeral).dataTask(with: URLRequest(url: url)) { data, response, error in
                if let error = error {
                    
                }
            }.resume()
        }
    }
    
    func postRequest() {
        let url = "https://test.shop.com/user?login"
        Alamofire.AF.request(url, method: .post, parameters: [
            "name": "jack",
            "password": "123456",
            "name1": "123456123456123456123456123456123456123456",
            "password1": "123456123456123456123456123456123456123456",
        ]).responseJSON { (response) in
            switch response.result {
            case .success(let json):
                print("json: \(json)")
            case .failure(let error):
                print("error: \(error)")
            }
        }
    }
    
}

