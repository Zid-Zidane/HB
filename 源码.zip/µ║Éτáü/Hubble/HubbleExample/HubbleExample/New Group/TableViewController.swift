//
//  TableViewController.swift
//  HubbleExample
//
//  Created by hazhu1 on 2023/5/8.
//

import UIKit
import HubbleCoordinator

class TableViewController: UITableViewController {

    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        HubbleCoordinator.shared.setOn(true)
        HubbleCoordinator.shared.viewPageNameHanler = {
            return "TableViewController"
        }
        HubbleCoordinator.shared.currentViewPageHanler = {
            return self
        }
        HubbleCoordinator.shared.show()
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        count += 1
        if count % 2 == 0 {
            HubbleCoordinator.shared.close()
        } else {
            HubbleCoordinator.shared.show()
        }
    }
}
