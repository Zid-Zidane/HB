//
//  HelpTipView.swift
//  HubbleExample
//
//  Created by hazhu1 on 2023/5/16.
//

import UIKit

class HelpTipView: UIView {
    
    struct Const {
        static let tipHeight: CGFloat = 19.0 + 3.0
        static let splitViewWidth: CGFloat = 150.0
        static let splitViewHeight: CGFloat = 1.0
    }
    
    @IBOutlet var label: UILabel!
    @IBOutlet weak var statusImageView: UIImageView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var splitViewWidth: NSLayoutConstraint!
    @IBOutlet weak var splitViewHeight: NSLayoutConstraint!
    var isExpand = false
    var constraint: NSLayoutConstraint?
    
    static let shard: HelpTipView? = {
        guard let instance = Bundle.main.loadNibNamed("HelpTipView", owner: nil)?.first as? HelpTipView else { return nil }
        instance.constraint = instance.label.bottomAnchor.constraint(equalTo: instance.bottomView.topAnchor, constant: 0)
        instance.constraint?.isActive = true
        return instance
    }()
    
    static func show(_ superView: UIView) {
        guard let helpView = HelpTipView.shard else { return }
        superView.addSubview(helpView)
        helpView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            helpView.topAnchor.constraint(equalTo: superView.topAnchor, constant: 80),
            helpView.centerXAnchor.constraint(equalTo: superView.centerXAnchor),
            helpView.widthAnchor.constraint(equalToConstant: 180),
            helpView.heightAnchor.constraint(equalToConstant: 35)
        ])
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    @IBAction func tapAction() {
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(animationAction), object: nil)
        self.perform(#selector(animationAction), with: nil, afterDelay: 0.2)
    }
    
    @objc func animationAction() {
        if isExpand {
            isExpand = false
            statusImageView.image = UIImage(systemName: "chevron.down")
            UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 10, options: .curveEaseInOut) {
                self.constraint?.constant = self.isExpand == true ? Const.tipHeight : 0.0
                self.layoutIfNeeded()
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, usingSpringWithDamping: 0.8, initialSpringVelocity: 10, options: .curveEaseInOut) {
                self.splitViewWidth.constant = self.isExpand == true ? Const.splitViewWidth : 0.0
                self.splitViewHeight.constant = self.isExpand == true ? Const.splitViewHeight : 3.0
                self.layoutIfNeeded()
            }
            UIView.animate(withDuration: 0.2, delay: 0.4, usingSpringWithDamping: 0.8, initialSpringVelocity: 10, options: .curveEaseInOut) {
                self.bottomView.backgroundColor = self.isExpand == true ? UIColor.lightGray : UIColor.clear
                self.layoutIfNeeded()
            }
        } else {
            isExpand = true
            statusImageView.image = UIImage(systemName: "chevron.up")
            UIView.animate(withDuration: 0.2, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 10, options: .curveEaseInOut) {
                self.bottomView.backgroundColor = self.isExpand == true ? UIColor.lightGray : UIColor.clear
                self.layoutIfNeeded()
            }
            
            UIView.animate(withDuration: 0.2, delay: 0.1, usingSpringWithDamping: 0.8, initialSpringVelocity: 10, options: .curveEaseInOut) {
                self.splitViewWidth.constant = self.isExpand == true ? Const.splitViewWidth : 0.0
                self.splitViewHeight.constant = self.isExpand == true ? Const.splitViewHeight : 3.0
                self.layoutIfNeeded()
            }
            
            UIView.animate(withDuration: 0.3, delay: 0.4, usingSpringWithDamping: 0.8, initialSpringVelocity: 10, options: .curveEaseInOut) {
                self.constraint?.constant = self.isExpand == true ? Const.tipHeight : 0.0
                self.layoutIfNeeded()
            }
        }
    }
    
}
