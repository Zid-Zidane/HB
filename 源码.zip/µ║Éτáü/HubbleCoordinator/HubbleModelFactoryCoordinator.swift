//
//  HubbleModelFactoryCoordinator.swift
//  HubbleCoordinator
//
//  Created by hazhu1 on 2023/5/5.
//

import Foundation
import Hubble

open class HubbleModelFactoryCoordinator: LensBaseModelFactory {
    open override func generateThenUpdate(reason: String, subTitle: String? = nil, log: String, snapshot: UIImage? = nil, alert: Bool, expandable: Bool = true, pageName: String?, tag: Bool = false, needsCodeInfo: Bool = true, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column) {
        if HubbleCoordinator.shared.workable() {
            self.generateThenUpdate(reason: reason, subTitle: subTitle, log: log, snapshot: snapshot, alert: alert, expandable: expandable, pageName: pageName, tag: tag, needsCodeInfo: needsCodeInfo, file: file, funcName: funcName, line: line, column: column)
        }
    }
}
