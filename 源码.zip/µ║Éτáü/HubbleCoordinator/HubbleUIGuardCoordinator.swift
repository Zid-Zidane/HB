//
//  HubbleUIGuardCoordinator.swift
//  HubbleCoordinator
//
//  Created by hazhu1 on 2023/5/6.
//

import Foundation
import Hubble

public extension UILabel {
    
    
    /// Monitor for Truncated & Clip & Overlap
    @discardableResult
    func guardLabelContent(file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column) -> Self {
        if HubbleCoordinator.shared.workable() {
            uiGuard.guardLabelContent(label: self, file: file, funcName: funcName, line: line, column: column)
        }
        return self
    }
    
    @discardableResult
    func guardLabelTruncated(file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column, needsLayout: Bool = true) -> Self {
        if HubbleCoordinator.shared.workable() {
            uiGuard.guardLabelTruncated(label: self, file: file, funcName: funcName, line: line, column: column)
        }
        return self
    }
    
    // MARK: - Private -
    
    private struct AssociatedKey {
        static var key: String = "AssociatedKey"
    }
    
    private var uiGuard: LensViewGuard {
        get {
            guard let objc = objc_getAssociatedObject(self, &AssociatedKey.key) as? LensViewGuard else {
                let item = LensViewGuard()
                objc_setAssociatedObject(self, &AssociatedKey.key, item, .OBJC_ASSOCIATION_COPY_NONATOMIC)
                return item
            }
            return objc
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKey.key, newValue, .OBJC_ASSOCIATION_COPY_NONATOMIC)
        }
    }
}

public extension UIView {
    
    @discardableResult
    func guardClip(view targetView: UIView?, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column, needsLayout: Bool = true) -> Self {
        if HubbleCoordinator.shared.workable() {
            uiGuard.guardClip(view: self, targetView: targetView, file: file, funcName: funcName, line: line, column: column)
        }
        return self
    }
    
    @discardableResult
    func guardOverlap(view targetView: UIView?, file: String = #file, funcName: String = #function, line: Int = #line, column: Int = #column, needsLayout: Bool = true) -> Self {
        if HubbleCoordinator.shared.workable() {
            uiGuard.guardOverlap(view: self, targetView: targetView, file: file, funcName: funcName, line: line, column: column)
        }
        return self
    }
    
    // MARK: - Private -
    
    enum AssociatedKey {
        static var key: String = "AssociatedKey"
    }
    
    private var uiGuard: LensViewGuard {
        get {
            guard let objc = objc_getAssociatedObject(self, &AssociatedKey.key) as? LensViewGuard else {
                let item = LensViewGuard()
                objc_setAssociatedObject(self, &AssociatedKey.key, item, .OBJC_ASSOCIATION_COPY_NONATOMIC)
                return item
            }
            return objc
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKey.key, newValue, .OBJC_ASSOCIATION_COPY_NONATOMIC)
        }
    }
    
}
