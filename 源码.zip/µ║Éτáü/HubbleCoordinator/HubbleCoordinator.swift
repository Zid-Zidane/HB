//
//  HubbleCoordinator.swift
//  EatsUtilityExt
//
//  Created by hazhu1 on 2023/5/4.
//

import Foundation
import Hubble

// MARK: - Business Project need internal class as corrdinator to decouple with Hubble
// MARK: HubbleCoordinator work status should control by Business Project -

public class HubbleCoordinator {
    private init() {}
    public static let shared = HubbleCoordinator()
    var isOn: Bool = true
    public var viewPageNameHanler: (()->String)? {
        get {
            if self.isOn {
                return HubbleManager.shared.viewPageNameHanler
            }
            return nil
        }
        set {
            if self.isOn {
                HubbleManager.shared.viewPageNameHanler = newValue
            }
        }
    }
    public var currentViewPageHanler: (()->UIViewController?)? {
        get {
            if self.isOn {
                return HubbleManager.shared.currentViewPageHanler
            }
            return nil
        }
        set {
//            if self.isOn {
                HubbleManager.shared.currentViewPageHanler = newValue
//            }
        }
    }
    
    public func regist(_ factories: [LensBaseModelFactory]) {
        if self.isOn {
            HubbleManager.shared.regist(factories)
        }
    }
    
    public static func logFactory(_ type: String) -> LensBaseModelFactory? {
        if HubbleCoordinator.shared.isOn {
            return HubbleManager.logFactory(type)
        }
        return nil
    }
    
    public func show(_ lensData: [String: String]? = nil, _ metaData: [String: String]? = nil) {
        if self.isOn {
            startWindowDetect()
            HubbleManager.shared.show(lensData, metaData)
        }
    }
    
    public func fold() {
        if self.isOn {
            HubbleManager.shared.fold()
        }
    }
    
    public func close() {
        if self.isOn {
            stopWindowDetect()
            HubbleManager.shared.close()
        }
    }
    
    public func avalible() -> Bool {
        if self.isOn {
            return HubbleManager.shared.avalible()
        }
        return false
    }
    
    public func setAvalible(_ status: Bool) {
        if self.isOn {
            HubbleManager.shared.setAvalible(status)
        }
    }
    
    public func setLensData(_ lensData: [String: String]?) {
        if self.isOn {
            HubbleManager.shared.setLensData(lensData)
        }
    }
    
    public func setMetaData(_ lensData: [String: String]?) {
        if self.isOn {
            HubbleManager.shared.setMetaData(lensData)
        }
    }
    
    /// Business Must First call this first, otherwish other function not workable
    /// - Parameter on: enable Hubble
    public func setOn(_ on: Bool) {
        self.isOn = on
    }
    
    func workable() -> Bool {
        if HubbleCoordinator.shared.isOn {
            return HubbleManager.shared.isShown()
        }
        return false
    }
    
    public func startWindowDetect() {
        if HubbleCoordinator.shared.isOn {
            LensWindowGuard.shared.start()
        }
    }

    public func stopWindowDetect() {
        if HubbleCoordinator.shared.isOn {
            LensWindowGuard.shared.stop()
        }
    }
    
    public func onClickHandler(_ handler: @escaping BlankHandler) {
        if HubbleCoordinator.shared.isOn {
            HubbleManager.shared.clickHandler = handler
        }
    }
    
}
